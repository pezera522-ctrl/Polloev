# RUCALETA original + V16 · QA

Base recuperada: pezera522-ctrl/Polloev, commit c86c807b54085ab18845248b6d4cc500c42c7e2e.
Destino exclusivo: RUCALETA-QA, xpkzzmnwzodikygfsdkp.

## Subida manual

Sube **el contenido de `site/`** a la raíz del repositorio cuando decidas hacerlo. No subas tests, SQL ni documentación como parte del sitio. Mantén los nombres de los PNG exactamente, incluido `iniciar-sesión.PNG`.

El sitio es estático: no necesita compilación ni npm en producción. Usa HTTPS. Ya contiene la URL y la clave **pública publishable** de QA. No contiene claves privadas. No hay pantalla para pegar credenciales de Supabase ni ruta de Edge Functions activa.

**No se publicó nada ni se modificó GitHub.** Las adiciones del backend ya están aplicadas en QA. No vuelvas a ejecutar los SQL de instalación sobre ese proyecto: no son scripts idempotentes. No son una migración de producción ni de una base vacía; parten del esquema V15 de QA.

## Contenido

- `site/`: HTML original adaptado, CSS original intacto, cinco PNG originales, sonidos y transiciones originales, integración V16.
- `sql/`: cambios exactos de QA y plantilla no ejecutada para asignar al propietario como administrador.
- `tests/`: verificaciones SQL con rollback, estáticas, DOM con API simulada y prueba visual pendiente.
- `AUDITORIA.md`: resultados, riesgos y pendientes, diferenciando pruebas reales y simuladas.
- `COMANDOS.md`: terminal en pasos separados.
- `docs/`: evidencia SQL y del asesor de seguridad.

## Funciones integradas

Auth con correo/contraseña, registro con teléfono como dato de contacto no verificado, recuperación de contraseña, persistencia, cierre de sesión; reglas y créditos en PostgreSQL; cinco resultados iniciales; señales simultáneas; un crédito por grupo; ventana de 30 giros desde 0/00; historial; premium ilimitado de $199 MXN/mes con vigencia controlada por servidor; panel administrativo, bloqueo de acceso a la app, vigencias QA, códigos, descuentos mensuales recurrentes, comisiones y estadísticas de QA.

El panel requiere pertenecer a `rucaleta_v16.admins`. Está vacío: no se adivinó quién es el dueño ni se elevaron cuentas existentes. La plantilla `sql/bootstrap_admin_MANUAL.sql` permite asignar un UUID verificado desde SQL Editor. Esto es distinto de crear usuarios Auth; el panel no puede cambiar contraseñas ni borrar usuarios Auth.

Los cobros están desactivados. Las suscripciones administrativas son concesiones manuales QA, no pagos cobrados. El registro privado de comisiones acepta únicamente importes coherentes y referencias únicas, y no está disponible para el navegador ni `service_role`. Conectar un proveedor de pagos, cobrar y renovar automáticamente queda fuera de esta entrega por la prohibición indicada.
