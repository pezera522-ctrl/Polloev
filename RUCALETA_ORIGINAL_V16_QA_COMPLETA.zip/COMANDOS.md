# Comandos de terminal · separados
Ejecutar desde la carpeta raíz descomprimida, donde están `index.html`, `tests` y `package.json`.
Estos comandos no modifican GitHub ni Supabase.

## 1. Revisar archivos y sintaxis
```bash
python3 tests/static_checks.py
```

## 2. Instalar solo dependencias de pruebas
```bash
npm ci
```

## 3. Ejecutar prueba DOM con API simulada
```bash
npm test
```

## 4. Abrir la copia local
```bash
npm run serve
```
Abrir http://127.0.0.1:8767. Mantener esta terminal abierta.

## 5. Preparar navegadores, en otra terminal
```bash
npx playwright install chromium webkit
```
Si el sistema carece de bibliotecas, debe resolverlas el administrador del equipo. Esta instalación no funcionó en el entorno de entrega.

## 6. Prueba visual móvil pendiente
```bash
npm run test:mobile
```

## 7. SQL QA
Los cambios de instalación **ya están aplicados**. No ejecutar nuevamente `qa_additive_v16.sql`, `qa_commission_ledger.sql` ni `qa_api_hardening.sql` sobre el proyecto actual.

Las aserciones pueden reproducirse en SQL Editor de **xpkzzmnwzodikygfsdkp**, copiando cada archivo completo con su BEGIN y ROLLBACK. No ejecutarlas fragmentadas ni en producción. La asignación del administrador es un paso distinto: `sql/bootstrap_admin_MANUAL.sql` requiere el UUID real verificado del propietario. Nunca poner claves privadas o contraseñas en el frontend ni en un comando compartido.

## 8. Subida manual
Copiar y reemplazar los archivos web que están directamente en la raíz del ZIP y ponerlos directamente en la raíz del repositorio. Comprueba que `index.html` quede junto a `style.css`, `java.js`, `logo-rucaleta.PNG` y `js/`, no dentro de una subcarpeta. No se proporcionan comandos de push ni de publicación porque están fuera de lo autorizado.
