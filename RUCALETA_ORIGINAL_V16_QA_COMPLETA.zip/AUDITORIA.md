# Auditoría · RUCALETA original + V16
Fecha: 18 de octubre de 2026. Entorno: exclusivamente RUCALETA-QA.

## Resultado y alcance

Se recuperó el repositorio original y la V16 actual entregada en ZIP. Se integró sobre `index.html`, `style.css`, `java.js` y los PNG originales, sin sustituir la identidad por una interfaz nueva. SHA-256 del CSS y los cinco PNG coincide con el repositorio; se preservaron las funciones originales de sonidos, ruleta y transiciones. No se ha certificado igualdad visual píxel a píxel ni el funcionamiento en un iPhone físico.

La imagen original que dice diez números se conserva en los archivos, pero su encabezado visible se sustituyó por texto de cinco resultados para cumplir la regla aprobada. El login conserva su panel y recibe correo, registro y recuperación. Cuenta y administración son controles adicionales con fondo negro. Se retiraron las cuentas/contraseñas incrustadas y el motor cliente antiguo. El navegador solo proyecta el estado autorizado por PostgreSQL.

## Cambios realizados en QA

1. Esquema nuevo `rucaleta_v16`: copia exacta de los 3 streams, 122 eventos, 12 señales y 9 intentos. Créditos copiados desde los derechos existentes.
2. Motor V16 corregido: cinco entradas exactas; señales solo con ventana abierta; el giro 30 resuelve el intento pendiente y cierra la ventana sin crear otra señal; 0/00 pierde los intentos confirmados y reinicia la ventana. Los verdes son neutrales para las ausencias, no suman ni reinician sus contadores.
3. Cinco créditos gratuitos por cuenta, uno por conjunto de señales generado en un giro. Nuevas sesiones no reponen créditos. Sin saldo se sigue registrando historial. Premium vigente permite señales sin débito.
4. Roles administrativos en tabla privada, controles en servidor y bloqueo de acceso. La suscripción expirada deja de otorgar premium en la siguiente operación. Precio base 19,900 centavos MXN al mes.
5. Códigos con porcentajes validados. Al vincular un código se conserva el descuento y la comisión pactados para mensualidades siguientes; cambiar el código después no cambia retroactivamente vínculos existentes. No se permite autorreferencia.
6. Comisiones privadas: importe mensual esperado, cálculo sobre importe neto, referencia única e idempotencia. Ninguna comisión de pago real registrada.
7. RLS de denegación explícita y sin permisos directos de tablas para clientes; implementaciones privilegiadas en esquema privado y wrappers públicos `SECURITY INVOKER`. `search_path` fijo. Sin autorización basada en metadata editable.
8. La escritura V15 se revocó en QA para impedir consumir dos saldos independientes. Sus datos y funciones de lectura siguen intactos. Los clientes QA antiguos ya no pueden escribir mediante V15.

No se alteraron registros existentes de V15, producción, Mikosmetics, pagos reales ni Edge Functions. No se hizo push, commit, PR ni despliegue. Las pruebas insertaron solo fixtures nuevos dentro de transacciones que acabaron en rollback; se verificó que no quedaron usuarios de prueba. No hay administradores asignados.

## Pruebas ejecutadas

| Tipo | Resultado y alcance |
|---|---|
| PostgreSQL real, rol authenticated/anon, rollback | Pasaron cinco entradas exactas, grupos de tres señales cobrados una sola vez, replay idempotente, UUID reutilizado con payload distinto, revisión obsoleta, 0/00, progresión de apuestas y cuarto intento. |
| PostgreSQL real | Pasaron cierre en giro 30, ausencia de nuevas señales fuera de ventana, integridad del historial, créditos cero, no reposición por nueva sesión, premium con saldo cero y expiración. |
| Seguridad SQL | Pasaron denegación de lectura cruzada, tablas privadas, panel para no administrador, usuario bloqueado y acceso anónimo. |
| Códigos/comisiones SQL | Descuento recurrente 20%: $159.20/mes. Comisión 10% sobre neto: $15.92. Deduplificación, dos mensualidades, rechazo de importe incorrecto y de invocación desde cliente: pasaron con fixtures, sin cobros. |
| HTTP real a QA | `/auth/v1/settings`: 200. Lectura V16 y administración sin sesión: 401, permiso denegado. |
| DOM con API simulada (jsdom) | Pasaron arranque, navegación de login/instrucciones, cinco resultados iniciales, envío de semilla, rechazo de 37, conservación de 00, limpieza de outbox y escape de HTML en administración. **No equivale a Auth real ni renderizado móvil.** |
| Archivos | JavaScript sintácticamente válido, IDs únicos, recursos presentes, cinco casillas, sin credenciales incrustadas ni claves privadas, uso de textContent para datos externos. |
| Datos originales | Comparación `EXCEPT` con la copia: cero diferencias en streams, eventos, señales e intentos. Fixtures restantes: cero. |
| Navegador visual | **Bloqueado/no aprobado**. Chromium no se pudo descargar; WebKit se descargó pero faltan bibliotecas del sistema y su instalación falló por permisos. El navegador remoto no alcanza localhost. |

Las pruebas de UUID/revisión se ejecutaron secuencialmente; no se ha hecho una prueba simultánea de carga. El bloqueo por fila serializa operaciones por usuario en el motor, pero eso no sustituye evidencia de carga.

## Seguridad revisada

El asesor final tras endurecer V16 no reportó nuevos avisos sobre sus tablas ni wrappers. Persistieron los avisos de los objetos heredados (RLS sin políticas en siete tablas y funciones privilegiadas V15/legales) y la protección de contraseñas filtradas desactivada en Auth. Estos objetos originales no se reescribieron. La evidencia del asesor fue capturada antes de revocar la escritura V15; esa revocación se verificó por separado.

- Asesor RLS: https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy
- Funciones privilegiadas: https://supabase.com/docs/guides/database/database-linter?lint=0029_authenticated_security_definer_function_executable
- Contraseñas: https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection

La CSP permite únicamente scripts propios y conexiones a QA; se incluyen meta CSP y `_headers`. GitHub Pages no aplica `_headers`, por lo que los encabezados HTTP adicionales requieren un hosting que los respete. Las sesiones se almacenan en localStorage; proteger el origen frente a XSS sigue siendo necesario. El historial se devuelve completo por RPC y se verifica al leer: con muchas operaciones puede requerir paginación y optimización antes de producción.

## Pendientes reales

1. **Cuenta propietaria:** verificar su UUID Auth y asignarlo con la plantilla administrativa. No se conoce una identidad verificable para otorgar privilegios automáticamente.
2. **Auth de extremo a extremo:** probar registro, confirmación de email, login, renovación y recuperación con una cuenta QA y correo accesibles. No se crearon cuentas persistentes ni se fingió una sesión real. Configurar Site URL y redirect URLs para el origen final; ese dominio aún no existe porque no se publicó.
3. **Móvil/visual/audio:** ejecutar el script de navegador y verificar Safari/iPhone físico, teclado, scroll, modales, carga y sonidos. La conservación de archivos no demuestra fidelidad visual completa.
4. **Pagos:** proveedor, cobros, renovación/cancelación automática, webhooks, reembolsos y reversión de comisiones requieren un trabajo posterior autorizado. En esta entrega no se hacen cargos ni se simulan ingresos reales. Premium y suscripciones QA sí están implementados en servidor.
5. **Legal:** los tres documentos actuales son textos QA. No se sustituyeron por contratos de producción ni se certificó su adecuación legal.
6. **Producción:** carga/concurrencia real, MFA para administrador, protección de contraseñas filtradas y revisión de los RPC heredados antes de autorizar salida. El paquete está destinado a QA, no se declara listo para explotación comercial.

## Reproducción

`tests/qa_assertions.sql` y `tests/commission_assertions.sql` contienen las aserciones exactas y el rollback. `tests/dom_integration.cjs` declara explícitamente sus dobles de API. `tests/browser_mobile.cjs` queda preparado, pero no se etiqueta como aprobado.
