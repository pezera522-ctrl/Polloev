// Optional rendered test. Run after npm ci and npx playwright install chromium webkit.
// Tests the public cover/login only. It does not create users or accept agreements.
const {chromium,webkit}=require('playwright');const assert=require('node:assert/strict');
(async()=>{for(const [name,type] of Object.entries({chromium,webkit})){
 const b=await type.launch({headless:true});
 for(const width of [375,390,430]){const p=await b.newPage({viewport:{width,height:844},isMobile:true,hasTouch:true});const errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto(process.env.RUCALETA_TEST_URL||'http://127.0.0.1:8767');await p.locator('#boton-iniciar').click();await p.locator('#pantalla-login').waitFor({state:'visible'});await p.waitForTimeout(1200);
 assert.equal(await p.locator('#login-usuario').isVisible(),true);assert.deepEqual(errors,[]);
 assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 assert.equal(await p.locator('img').evaluateAll(images=>images.every(i=>i.complete&&i.naturalWidth>0)),true);
 await p.close();console.log(`PASS ${name} width ${width}: cover, roulette transition, login, images, no horizontal overflow`);}
 await b.close();}})().catch(e=>{console.error(e);process.exitCode=1});
