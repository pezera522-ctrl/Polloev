// DOM-only integration with explicit API doubles. Does NOT certify layout or live Auth.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {JSDOM}=require(process.env.JSDOM_PATH||'jsdom');
(async()=>{
 const site=path.join(__dirname,'..');const dom=new JSDOM(fs.readFileSync(path.join(site,'index.html'),'utf8'),{url:'http://localhost:8767',runScripts:'outside-only'});const w=dom.window;
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};w.HTMLElement.prototype.scrollIntoView=function(){};
 const timer=w.setTimeout.bind(w);w.setTimeout=(fn,ms)=>timer(fn,Math.min(ms,1));
 let calls=[],r={admin:true,state:{results:[],seq:0,sessionStartSeq:0,signals:[],attempts:[],window:{endSeq:null}},revision:0,free_credits_remaining:5,premium_active:false};
 const clone=x=>JSON.parse(JSON.stringify(x));let logged=false;const user={id:'test-user',email:'qa@example.invalid'};
 w.API={userInfo:async()=>logged?user:null,receiveAuthLink:async()=>false,signIn:async()=>{logged=true},getLegal:async()=>({ready:true,required_documents:[{id:1,title:'Documento QA',content_md:'Texto QA'}]}),analysisApi:async(action,payload)=>{if(action){calls.push([action,payload]);r.revision++;if(action==='seed_history')r.state.results=payload.values.map((value,i)=>({value,seq:i+1}));if(action==='spin')r.state.results.push({value:payload.value,seq:r.state.results.length+1});if(action==='new_session'){r.state.sessionStartSeq=r.state.seq;r.state.signals=[];}r.state.seq=r.state.results.length;}return clone(r)},rpc:async(name)=>{if(name==='rucaleta_v16_admin')return {users:[{id:'x',email:'<img src=x onerror=alert(1)>',credits:5}],codes:[],commissions:[],audit:[],offset:0,statistics:{users:1,premium_active:0,groups:0,credits_used:0,collected_cents:0,commissions_cents:0}};if(name==='rucaleta_v16_read')return {events:[]};return {discount_pct:20,monthly_cents:15920}}};
 w.normalizeNumber=x=>{if(!/^(00|0|[1-9]|[12][0-9]|3[0-6])$/.test(x))throw Error('INVALID');return x};w.friendly={red:'Rojo',black:'Negro',even:'Par',odd:'Impar',low:'1–18',high:'19–36'};
 let code=fs.readFileSync(path.join(site,'java.js'),'utf8').replace(/^import .*;\n/gm,'');
 code+='\nwindow.TEST={intentarLogin,continuarDesdeInstrucciones,iniciarSesionActiva,agregarNumeroSesion,renderAdmin,add:agregarNumeroInicial,render:renderRemote,confirm:confirmSignal};';
 await w.eval('(async()=>{'+code+'})()');const $=id=>w.document.getElementById(id);
 assert.equal($('pantalla-inicio').hidden,false);$('login-usuario').value='qa@example.invalid';$('login-clave').value='test-only-not-a-real-password';await w.TEST.intentarLogin();assert.equal($('pantalla-instrucciones').hidden,false);
 $('check-instrucciones').checked=true;await w.TEST.continuarDesdeInstrucciones();assert.equal($('pantalla-sesion').hidden,false);
 for(const v of ['0','1','2','3','4']){$('numero-ruleta').value=v;w.TEST.add();}assert.equal($('contador-inicial').textContent,'5/5');await w.TEST.iniciarSesionActiva();assert.equal($('pantalla-sesion-activa').hidden,false);assert.equal(calls[0][1].values.length,5);
 $('numero-sesion').value='37';await w.TEST.agregarNumeroSesion();assert.equal(calls.length,1);
 $('numero-sesion').value='00';await w.TEST.agregarNumeroSesion();assert.equal(calls.length,2);assert.equal(calls[1][1].value,'00');assert.equal(w.localStorage.getItem('rucaleta-v16-outbox-test-user'),null);
 await w.TEST.renderAdmin();assert.equal($('admin-users').querySelector('img'),null);assert.match($('admin-users').textContent,/<img/);
 console.log('PASS: DOM startup, login flow mock, legal navigation, 5 seed inputs, seed submission, invalid spin rejection, 00 preservation, outbox cleanup, admin XSS escaping');dom.window.close();
})().catch(e=>{console.error(e);process.exit(1)});
