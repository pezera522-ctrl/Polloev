from pathlib import Path
import re,hashlib,json,subprocess
site=Path(__file__).resolve().parents[1]
h=(site/'index.html').read_text();ids=re.findall(r'\bid="([^"]+)"',h)
assert len(ids)==len(set(ids)), 'duplicate ids'
for src in re.findall(r'(?:src|href)="([^"]+)"',h):
 if not re.match(r'https?:',src):assert (site/src.split('?')[0]).is_file(),src
for f in [site/'java.js',*(site/'js').glob('*.js')]:subprocess.run(['node','--check',str(f)],check=True)
assert len(re.findall('data-posicion=',h))==5
alljs='\n'.join(f.read_text() for f in [site/'java.js',*(site/'js').glob('*.js')])
assert 'CUENTAS_AUTORIZADAS' not in alljs
assert not re.search(r'sb_secret_|eyJ[a-zA-Z0-9_-]+\.',alljs)
assert 'innerHTML' not in (site/'java.js').read_text()
print('PASS: unique IDs, asset references, JS syntax, five inputs, no embedded credentials/private keys, safe text rendering')
print(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [site/'style.css',*site.glob('*.PNG')]},indent=2))
