/** Explicit iPhone-friendly isolated Supabase QA configuration.
 * A public project URL/key is not a secret. Reject service_role and the owner's MAIN project.
 * Never auto-enable a production backend or accept a user-controlled RPC endpoint.
 */
export const QA_STORAGE_KEY='rucaleta-cloud-qa-v16';
export const ALLOWED_QA_REF='xpkzzmnwzodikygfsdkp';
const bad=(reason)=>{throw new Error('CLOUD_QA_'+reason)};
export function validateQaConfig(data){
 if(!data||typeof data!=='object'||Array.isArray(data))bad('CONFIG_REQUIRED');
 const url=String(data.url||'').trim().replace(/\/+$/,'');
 const key=String(data.key||'').trim();
 let parsed;try{parsed=new URL(url)}catch{bad('INVALID_URL')}
 if(parsed.protocol!=='https:'||parsed.username||parsed.password||parsed.port||parsed.pathname!=='/'||parsed.search||parsed.hash||!/^([a-z0-9]{12,40})\.supabase\.co$/.test(parsed.hostname))bad('ONLY_SUPABASE_HTTPS');
 const ref=parsed.hostname.split('.')[0];
 if(ref!==ALLOWED_QA_REF)bad('ONLY_AUTHORIZED_QA_PROJECT');
 if(!/^sb_publishable_[A-Za-z0-9_-]{10,}$/.test(key))bad('PUBLISHABLE_KEY_ONLY');
 return {url:`https://${parsed.hostname}`,key,ref};
}
export function readQaConfig(storage=globalThis.localStorage){
 try{const raw=storage?.getItem(QA_STORAGE_KEY);return raw?validateQaConfig(JSON.parse(raw)):null;}catch{return null;}
}
export function saveQaConfig(data,storage=globalThis.localStorage){
 const valid=validateQaConfig(data);storage.setItem(QA_STORAGE_KEY,JSON.stringify({url:valid.url,key:valid.key}));return valid;
}
export function clearQaConfig(storage=globalThis.localStorage){storage?.removeItem(QA_STORAGE_KEY);}

/** Verify the isolated project marker remotely before storing a connection from a phone.
 * Timeout and failure must not silently enable access to a different project.
 */
export async function checkQaProject(data,{fetcher=globalThis.fetch}={}){
 const v=validateQaConfig(data);
 const response=await fetcher(`${v.url}/rest/v1/rpc/rucaleta_v16_qa_marker`,{
  method:'POST',headers:{apikey:v.key,'Content-Type':'application/json'},body:'{}',cache:'no-store'});
 if(!response.ok)bad('MARKER_UNAVAILABLE');
 const marker=await response.json();
 if(marker?.tag!=='RUCALETA_QA_V16'||marker?.qa_only!==true||marker?.premium_enabled!==false)bad('MARKER_INVALID');
 return v;
}
