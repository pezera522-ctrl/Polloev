/** REAL parallel HTTP requests to Supabase QA PostgreSQL RPCs. No mocks or fake results.
 * Runs ONLY when explicit alternate project configuration is validated.
 */
import {CLOUD_QA_INTEGRATION,SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY} from './config.js';
import {sessionToken,analysisApi} from './supabase.js';
const literal='["2","4","6","8","0"]';
export async function concurrencyProbe(count,{fetcher=fetch,tokenProvider=sessionToken,analysis=analysisApi}={}){
 if(!CLOUD_QA_INTEGRATION)throw Error('CLOUD_QA_REQUIRED');
 if(![2,5,10,20].includes(count))throw Error('UNSUPPORTED_CONCURRENCY');
 let snapshot=await analysis();
 if(snapshot.free_credits_remaining<1)throw Error('NO_QA_CREDITS_LEFT');
 // New session resets only active signals/streaks; historical events are preserved.
 if(snapshot.state.seq>snapshot.state.sessionStartSeq){snapshot=await analysis('new_session',{},crypto.randomUUID(),snapshot.revision);}
 snapshot=await analysis('seed_history',{values:JSON.parse(literal)},crypto.randomUUID(),snapshot.revision);
 const revision=snapshot.revision,before=snapshot.free_credits_remaining;
 const jwt=await tokenProvider();if(!jwt)throw Error('QA_AUTH_REQUIRED');
 const endpoint=SUPABASE_URL+'/rest/v1/rpc/rucaleta_v15_apply';
 const headers={'apikey':SUPABASE_PUBLISHABLE_KEY,'Authorization':'Bearer '+jwt,'Content-Type':'application/json'};
 const operations=Array.from({length:count},()=>({p_request_id:crypto.randomUUID(),p_expected_revision:revision,p_action:'spin',p_payload:{value:'10'}}));
 // Start every network operation without awaiting another first.
 const responses=await Promise.all(operations.map(async op=>{
  try{const r=await fetcher(endpoint,{method:'POST',headers,body:JSON.stringify(op),cache:'no-store'});
   return {ok:r.ok,status:r.status,receipt:await r.json().catch(()=>null),request_id:op.p_request_id};}
  catch(error){return {ok:false,status:0,network_error:String(error),request_id:op.p_request_id};}
 }));
 const successes=responses.filter(r=>r.ok),rejected=responses.filter(r=>!r.ok);
 // An error other than serialization/conflict is not silently considered proof.
 const conflicts=rejected.filter(r=>r.receipt?.message?.includes('ANALYSIS_REVISION_CONFLICT')||r.receipt?.code==='40001');
 const after=await analysis();
 const winner=successes[0];
 const pass=successes.length===1&&conflicts.length===count-1&&after.revision===revision+1
  &&after.free_credits_remaining===before-1
  &&after.state.signals.filter(s=>s.triggerSeq===after.state.seq).length===3;
 let replay=null;
 if(pass&&winner){
  const op=operations.find(x=>x.p_request_id===winner.request_id);
  const r=await fetcher(endpoint,{method:'POST',headers,body:JSON.stringify(op),cache:'no-store'});
  replay=await r.json().catch(()=>null);
  const final=await analysis();
  if(!r.ok||replay?.replayed!==true||final.free_credits_remaining!==after.free_credits_remaining||final.revision!==after.revision)
   throw Error('QA_REPLAY_OR_BALANCE_CHANGED');
 }
 return {passed:pass,count,successes:successes.length,conflicts:conflicts.length,
  other_errors:rejected.length-conflicts.length,before_credits:before,after_credits:after.free_credits_remaining,
  revision:after.revision,verified_replay:replay?.replayed===true,
  evidence:responses.map(x=>({status:x.status,ok:x.ok,code:x.receipt?.code||null,network_error:x.network_error||null}))};
}
