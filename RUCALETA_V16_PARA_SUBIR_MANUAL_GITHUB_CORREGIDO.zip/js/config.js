// V16: main Supabase credentials are NOT embedded in distributed assets.
// iPhone cloud QA accepts only the authorized xpkzzmnwzodikygfsdkp project.
import {readQaConfig} from './cloud-qa.js';
export const LOCAL_QA_INTEGRATION=typeof window!=='undefined' && ['127.0.0.1','localhost'].includes(location.hostname) && location.port==='8766';
export const CLOUD_QA_CONFIG=!LOCAL_QA_INTEGRATION?readQaConfig():null;
export const CLOUD_QA_INTEGRATION=!!CLOUD_QA_CONFIG;
export const SUPABASE_URL=CLOUD_QA_CONFIG?.url||'';
export const SUPABASE_PUBLISHABLE_KEY=CLOUD_QA_CONFIG?.key||'';
// Keep deny-by-default explicit for legacy deployment safety checks.
export const ANALYSIS_BACKEND_ENABLED=false || LOCAL_QA_INTEGRATION || CLOUD_QA_INTEGRATION;
