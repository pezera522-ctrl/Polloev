import {SUPABASE_URL as BASE,SUPABASE_PUBLISHABLE_KEY as KEY,CLOUD_QA_INTEGRATION} from './config.js';
import {projectV15Read} from './v15-projection.js';
const AUTH_STORAGE='rucaleta-auth-session-v1';
const safeJson=(text)=>{try{return JSON.parse(text)}catch{return {message:text}}};
let memory=null;
let refreshInFlight=null;
let authEpoch=0;
export function currentSession(){
  if(memory)return memory;
  try{const v=localStorage.getItem(AUTH_STORAGE);memory=v?JSON.parse(v):null;}catch{memory=null}
  return memory;
}
function saveSession(v){memory=v;try{if(v)localStorage.setItem(AUTH_STORAGE,JSON.stringify(v));else localStorage.removeItem(AUTH_STORAGE);}catch{/*private browsing*/}}
function explain(response,data){return new Error(data?.msg||data?.message||data?.error_description||data?.error||`Error del servidor (${response.status}).`)}
async function call(endpoint,{method='GET',payload=null,token=null}={}){
  if(!BASE||!KEY)throw new Error('Conexión remota desactivada. Configura un proyecto Supabase QA independiente.');
  const headers={'apikey':KEY,'Content-Type':'application/json'};
  if(token)headers.Authorization=`Bearer ${token}`;
  const res=await fetch(BASE+endpoint,{method,headers,body:payload===null?undefined:JSON.stringify(payload),cache:'no-store'});
  const value=safeJson(await res.text());
  if(!res.ok)throw explain(res,value);
  return value;
}
export async function signIn(email,password){const epoch=++authEpoch;const a=await call('/auth/v1/token?grant_type=password',{method:'POST',payload:{email,password}});if(epoch!==authEpoch)throw Error('Inicio de sesión cancelado por un cambio de cuenta.');saveSession(a);return a;}
export async function signUp(email,password){return call('/auth/v1/signup',{method:'POST',payload:{email,password}});}
export async function logout(){authEpoch++;const s=currentSession();try{if(s?.access_token)await call('/auth/v1/logout',{method:'POST',token:s.access_token});}finally{saveSession(null)}}
export async function sessionToken(){
  const session=currentSession();if(!session?.access_token)return null;
  if(session.expires_at && session.expires_at>Math.floor(Date.now()/1000)+65)return session.access_token;
  if(!session.refresh_token){saveSession(null);return null;}
  // A refresh token can be single-use. All concurrent requests share one refresh.
  if(!refreshInFlight){
    const epoch=authEpoch;
    refreshInFlight=(async()=>{
      try{
        const updated=await call('/auth/v1/token?grant_type=refresh_token',{method:'POST',payload:{refresh_token:session.refresh_token}});
        if(epoch!==authEpoch)return null;
        saveSession(updated);return updated.access_token;
      }catch{if(epoch===authEpoch)saveSession(null);return null;}
    })().finally(()=>{refreshInFlight=null});
  }
  return refreshInFlight;
}
export async function userInfo(){const token=await sessionToken();if(!token)return null;try{return await call('/auth/v1/user',{token})}catch{saveSession(null);return null}}
export async function rpc(name,params={}){const token=await sessionToken();if(!token)throw new Error('Necesitas iniciar sesión nuevamente.');return call(`/rest/v1/rpc/${encodeURIComponent(name)}`,{method:'POST',token,payload:params});}
export async function getLegal(){return rpc('get_my_legal_status');}
export async function acceptLegal(docs){return rpc('accept_current_legal_documents',{p_document_ids:docs.map(d=>d.id),p_document_hashes:docs.map(d=>d.sha256)});}
export async function getAccess(){return rpc('get_my_access');}
export async function requestPasswordReset(email){return call('/auth/v1/recover',{method:'POST',payload:{email}})}
/** V15 remote adapter, disabled by config until SQL/Edge verified on isolated PG.
 * The browser sends domain operations only. POST receipt is reconciled by GET.
 */
export async function analysisApi(action=null,payload={},requestId=null,expectedRevision=undefined){
 const token=await sessionToken();if(!token)throw Error('Necesitas iniciar sesión nuevamente.');
 const headers={apikey:KEY,Authorization:`Bearer ${token}`,'Content-Type':'application/json'};
 const endpoint=CLOUD_QA_INTEGRATION?`${BASE}/rest/v1/rpc/`:`${BASE}/functions/v1/rucaleta-v15`;
 async function read(){
  const response=await fetch(CLOUD_QA_INTEGRATION?endpoint+'rucaleta_v15_read':endpoint,{method:CLOUD_QA_INTEGRATION?'POST':'GET',headers,body:CLOUD_QA_INTEGRATION?'{}':undefined,cache:'no-store'});
  const data=safeJson(await response.text());if(!response.ok)throw explain(response,data);
  return projectV15Read(data);
 }
 if(!action)return read();
 if(!requestId||!Number.isSafeInteger(expectedRevision))throw Error('Identificador y revisión requeridos.');
 const options={method:'POST',headers,body:JSON.stringify(CLOUD_QA_INTEGRATION?{p_action:action,p_request_id:requestId,p_payload:payload,p_expected_revision:expectedRevision}:{action,request_id:requestId,payload,expected_revision:expectedRevision}),cache:'no-store'};
 let response;
 try{response=await fetch(CLOUD_QA_INTEGRATION?endpoint+'rucaleta_v15_apply':endpoint,options);}catch(error){
  // Network ambiguity: retry ONLY the same UUID, never generate a new operation.
  response=await fetch(CLOUD_QA_INTEGRATION?endpoint+'rucaleta_v15_apply':endpoint,options);
 }
 const receipt=safeJson(await response.text());if(!response.ok)throw explain(response,receipt);
 if(receipt.request_id!==requestId||!Number.isSafeInteger(Number(receipt.revision)))throw Error('Recibo remoto inválido.');
 const projected=await read();
 if(projected.revision<Number(receipt.revision))throw Error('La operación se guardó, pero la lectura aún no la refleja. Recupera la sesión.');
 return {...projected,debited:receipt.debited,request_id:receipt.request_id};
}
