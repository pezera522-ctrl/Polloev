/** American roulette order (clockwise). Visualizes a DECLARED result; never spins randomly. */
import {attributes,normalizeNumber} from './engine.js';
export const AMERICAN_WHEEL=Object.freeze(['0','28','9','26','30','11','7','20','32','17','5','22','34','15','3','24','36','13','1','00','27','10','25','29','12','8','19','31','18','6','21','33','16','4','23','35','14','2']);
const SVG='http://www.w3.org/2000/svg',DELTA=360/38;
const point=(r,deg)=>{const a=(deg-90)*Math.PI/180;return [160+r*Math.cos(a),160+r*Math.sin(a)]};
const make=(tag,attrs={})=>{const x=document.createElementNS(SVG,tag);for(const [k,v] of Object.entries(attrs))x.setAttribute(k,String(v));return x};
function wedge(a,b){const p=point(138,a),q=point(138,b);return `M 160 160 L ${p[0]} ${p[1]} A 138 138 0 0 1 ${q[0]} ${q[1]} Z`};
export function rouletteMarkup(){
 const svg=make('svg',{viewBox:'0 0 320 320',role:'img','aria-label':'Ruleta americana de 38 casillas en orden oficial'});
 svg.append(make('circle',{cx:160,cy:160,r:157,fill:'#bd9453'}),make('circle',{cx:160,cy:160,r:151,fill:'#0b1018'}));
 const wheel=make('g',{'data-rotor':'',transform:'rotate(0 160 160)'});
 for(let i=0;i<AMERICAN_WHEEL.length;i++){
  const value=AMERICAN_WHEEL[i],clr=value==='0'||value==='00'?'#136a51':attributes(value).color==='red'?'#a62335':'#161f29';
  wheel.append(make('path',{d:wedge(i*DELTA-DELTA/2,i*DELTA+DELTA/2),fill:clr,stroke:'#c9a36b','stroke-width':1.0}));
  const [x,y]=point(116,i*DELTA);
  const t=make('text',{x,y,fill:'#fff','font-family':'system-ui, sans-serif','font-size':value==='00'?10:11,'font-weight':700,'text-anchor':'middle','dominant-baseline':'middle',transform:`rotate(${i*DELTA} ${x} ${y})`});t.textContent=value;wheel.append(t);
 }
 svg.append(wheel);svg.append(make('circle',{cx:160,cy:160,r:80,fill:'#18232e',stroke:'#d5b47b','stroke-width':5}),make('circle',{cx:160,cy:160,r:64,fill:'#101922',stroke:'#7a622e','stroke-width':2}));
 const center=make('text',{x:160,y:151,fill:'#e9d9be','text-anchor':'middle','font-size':18,'font-weight':700,'font-family':'system-ui'});center.textContent='RUCALETA';svg.append(center);
 const resultLabel=make('text',{x:160,y:184,fill:'#e0b970','text-anchor':'middle','font-size':26,'font-weight':800,'font-family':'system-ui','aria-hidden':'true'});resultLabel.textContent='—';svg.append(resultLabel);
 // Fixed pointer is independent of rotor rotation; the declared result aligns below it.
 svg.append(make('polygon',{points:'151,7 169,7 160,28',fill:'#eac68b',stroke:'#141820','stroke-width':2}),make('circle',{cx:160,cy:6,r:4,fill:'#f6ddb0'}));
 return {svg,wheel,resultLabel};
}
export function createRoulette(target,{reducedMotion=false}={}){
 const {svg,wheel,resultLabel}=rouletteMarkup();target.replaceChildren(svg);
 let rotation=0,reduced=!!reducedMotion,last=null,active=null,generation=0;
 wheel.style.transformOrigin='160px 160px';wheel.style.transformBox='view-box';
 const stop=()=>{
  generation++;
  if(active){
   // Preserve the CURRENT displayed angle, not the old target angle, when a new result arrives.
   // Without this, fast successive spins visibly snap to the previous destination.
   try{
    const matrix=getComputedStyle(wheel).transform;
    if(matrix && matrix!=='none' && typeof DOMMatrixReadOnly!=='undefined'){
     const m=new DOMMatrixReadOnly(matrix);
     rotation=((Math.atan2(m.b,m.a)*180/Math.PI)%360+360)%360;
    }
   }catch{ /* Fallback to stored target if the browser cannot expose its matrix. */ }
   active.cancel();active=null;
  }
  wheel.style.transition='none';wheel.style.transform=`rotate(${rotation}deg)`;
 };
 return {
  setReduced(v){reduced=!!v;if(reduced)stop();},
  isAnimating(){return !!active;},
  show(value,{animate=true}={}){
   value=normalizeNumber(value);const index=AMERICAN_WHEEL.indexOf(value);
   if(index<0)throw Error('INVALID_WHEEL_TARGET');
   stop();const desired=((360-index*DELTA)%360+360)%360;
   const delta=((desired-rotation)%360+360)%360;
   const start=rotation;
   const motion=animate&&!reduced&&typeof wheel.animate==='function'&&!(typeof document!=='undefined'&&document.hidden);
   const end=start+(motion?1800:0)+delta;
   rotation=end%360;last=value;resultLabel.textContent=value;
   if(motion){
    const run=++generation;
    // Distinct acceleration phase prevents a sharp angular leap when consecutive spins begin.
    // Remaining 78% decelerates progressively onto the user-declared result.
    active=wheel.animate([
      {transform:`rotate(${start}deg)`,offset:0,easing:'cubic-bezier(.58,0,.92,.45)'},
      {transform:`rotate(${start+(end-start)*.13}deg)`,offset:.22,easing:'cubic-bezier(.13,.7,.18,1)'},
      {transform:`rotate(${end}deg)`,offset:1}
    ],{duration:2900,easing:'linear',fill:'forwards'});
    active.onfinish=()=>{if(run!==generation)return;const completed=active;active=null;wheel.style.transform=`rotate(${rotation}deg)`;completed.cancel();};
    active.oncancel=()=>{if(run===generation)active=null;};
   }else wheel.style.transform=`rotate(${rotation}deg)`;
   return value;
  },
  last:()=>last,
  destroy(){stop();target.replaceChildren();}
 };
}
