/** RUCALETA — motor determinista del laboratorio, sin apuestas reales ni cobros.
 * Es independiente de la red, conserva 0 y 00 como valores diferentes y es testeable en Node.
 */
export const RED = Object.freeze(new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]));
export const TARGETS = Object.freeze({color:['red','black'], parity:['even','odd'],half:['low','high']});
export const STAKES = Object.freeze({A:[4,8,16,32],B:[5,10,20,40]});
const MAX_RESULTS=500;
export function normalizeNumber(input) {
  const raw=String(input ?? '').trim();
  if(raw==='00') return '00';
  if(!/^(?:0|[1-9]|[12]\d|3[0-6])$/.test(raw)) throw new Error('El resultado debe ser 0, 00 o un número del 1 al 36.');
  return raw;
}
export function attributes(input) {
  const n=normalizeNumber(input);
  if(n==='0'||n==='00') return null;
  const number=Number(n);
  return {color:RED.has(number)?'red':'black',parity:number%2===0?'even':'odd',half:number<=18?'low':'high'};
}
export const friendly={red:'Rojo',black:'Negro',even:'Par',odd:'Impar',low:'1–18',high:'19–36'};
export function emptyState(){return {version:1,results:[],streaks:{red:0,black:0,even:0,odd:0,low:0,high:0},signals:[],attempts:[],actions:[],seq:0,window:{lastGreenSeq:null,endSeq:null,generation:0},sessionNumber:1,sessionStartSeq:0,groups:[]};}
export function safeState(input){
  if(!input || input.version!==1 || !Array.isArray(input.results) || !Array.isArray(input.signals) || !Array.isArray(input.attempts) || !Array.isArray(input.actions)) return emptyState();
  return {...input,window:input.window&&typeof input.window==='object'?input.window:{lastGreenSeq:null,endSeq:null,generation:0},sessionNumber:input.sessionNumber||1,sessionStartSeq:Number.isSafeInteger(input.sessionStartSeq)?input.sessionStartSeq:0,groups:Array.isArray(input.groups)?input.groups:[]};
}
const uuid=()=>globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
export function confirmBet(current, signalId, stake, requestId=uuid(), options={}) {
  const state=structuredClone(safeState(current));
  if(state.actions.some(a=>a.requestId===requestId)) return state;
  const signal=state.signals.find(s=>s.id===signalId);
  if(!signal||signal.status!=='active') throw new Error('La señal ya no está activa.');
  if(state.attempts.some(a=>a.signalId===signalId && a.status==='pending')) throw new Error('Ya existe una apuesta confirmada pendiente para esta señal.');
  const attemptNumber=state.attempts.filter(a=>a.signalId===signalId).length+1;
  if(attemptNumber>4) throw new Error('La señal agotó sus cuatro intentos.');
  // The only documented progressions are A and B. Lock the first choice per signal.
  const previous=state.attempts.filter(a=>a.signalId===signalId);
  const scheme=previous.length===0?(stake===STAKES.A[0]?'A':stake===STAKES.B[0]?'B':null):previous[0].scheme;
  if(!scheme || stake!==STAKES[scheme][attemptNumber-1])throw new Error('Importe fuera de la progresión seleccionada.');
  const attempt={id:options.idFactory?.('attempt',0)??uuid(),signalId,attemptNumber,stake,scheme,status:'pending',result:null,confirmedAt:options.eventTime??new Date().toISOString()};
  state.attempts.push(attempt);
  state.actions.push({requestId,kind:'confirmBet',attemptId:attempt.id});
  return state;
}
export function addResult(current, raw, requestId=uuid(), options={}) {
  const state=structuredClone(safeState(current));
  if(state.actions.some(a=>a.requestId===requestId)) return state;
  const value=normalizeNumber(raw), attrs=attributes(value);
  state.seq++;
  const result={seq:state.seq,value,at:options.eventTime??new Date().toISOString()};
  state.results.push(result);if(state.results.length>MAX_RESULTS)state.results.shift();
  // Los cinco resultados de arranque son contexto histórico, no giros apostables.
  const seeding=options.seed===true;
  if(seeding && (state.seq-state.sessionStartSeq)>(options.seedLimit??5))throw new Error('La carga inicial supera su límite permitido.');
  // Solo se resuelven apuestas confirmadas; nunca inventar un resultado de apuesta.
  for(const a of state.attempts.filter(a=>a.status==='pending')) {
    const signal=state.signals.find(s=>s.id===a.signalId);
    if(!signal||signal.status!=='active') continue;
    const win=attrs!==null && attrs[signal.category]===signal.target;
    a.status=win?'won':'lost';a.result=value;a.resolvedSeq=result.seq;
    if(win){signal.status='won';signal.completedSeq=result.seq;}
    else if(a.attemptNumber>=4){signal.status='lost';signal.completedSeq=result.seq;}
  }
  // Un verde renueva el plazo antes de comprobar vencimientos; no altera ausencias.
  if(attrs===null){
    state.window.lastGreenSeq=result.seq;
    state.window.endSeq=result.seq+30;
    state.window.generation++;
    for(const signal of state.signals.filter(s=>s.status==='active'&&s.specialWindow)) signal.windowEndSeq=state.window.endSeq;
  }
  // 0 y 00 no suman ni reinician los contadores de ausencia.
  if(attrs) {
    for(const [category, targets] of Object.entries(TARGETS)) {
      for(const target of targets){
        const old=state.streaks[target]||0;
        const count=attrs[category]===target ? 0 : old+1;
        state.streaks[target]=count;
        if(!seeding && old===4 && count===5 && !state.signals.some(s=>s.category===category&&s.target===target&&s.status==='active')){
          const specialWindow=state.window.endSeq!==null&&result.seq<=state.window.endSeq;
          const groupKey=`${state.sessionNumber}:${result.seq}`;
          let group=state.groups.find(g=>g.key===groupKey);
          if(!group){group={id:options.idFactory?.('group',0)??uuid(),key:groupKey,triggerSeq:result.seq,sessionNumber:state.sessionNumber,creditStatus:'not_charged_local'};state.groups.push(group);}
          state.signals.push({id:options.idFactory?.('signal',state.signals.length)??uuid(),groupId:group.id,category,target,triggerSeq:result.seq,status:'active',specialWindow,windowEndSeq:specialWindow?state.window.endSeq:null,createdAt:result.at});
        }
      }
    }
  }
  // Primero se resuelve el giro 30; luego se cierran las señales sin resolver.
  if(state.window.endSeq!==null && result.seq>=state.window.endSeq){
    for(const signal of state.signals.filter(s=>s.status==='active'&&s.specialWindow)){
      signal.status='closed_by_window';signal.completedSeq=result.seq;
      for(const a of state.attempts.filter(a=>a.signalId===signal.id&&a.status==='pending'))a.status='interrupted';
    }
    state.window.endSeq=null;
  }
  state.actions.push({requestId,kind:'addResult',seq:result.seq});
  if(state.actions.length>1000)state.actions.splice(0,state.actions.length-1000);
  return state;
}
export function metrics(state){
  const s=safeState(state);
  const resolved=s.attempts.filter(a=>a.status==='won'||a.status==='lost');
  const wins=resolved.filter(a=>a.status==='won').length;
  const closed=s.signals.filter(v=>v.status==='won'||v.status==='lost');
  const signalWins=closed.filter(v=>v.status==='won').length;
  const net=resolved.reduce((total,a)=>total+(a.status==='won'?a.stake:-a.stake),0);
  return {bets:resolved.length,wins,losses:resolved.length-wins,betRate:resolved.length?100*wins/resolved.length:null,signalRate:closed.length?100*signalWins/closed.length:null,net};
}

/** Carga histórica inicial sin crear señales, apuestas ni grupos cobrables. */
export function seedInitialResults(values){
  if(!Array.isArray(values)||values.length!==5)throw new Error('Se requieren exactamente cinco resultados iniciales.');
  let state=emptyState();
  for(const value of values){
    state=addResult(state,value,uuid(),{seed:true});
  }
  state.signals=[];state.groups=[];state.actions=[];
  return state;
}
/** Nueva sesión de análisis; conserva el historial, pero cierra las señales pendientes. */
export function startNewSession(current, requestId=uuid()){
  const state=structuredClone(safeState(current));
  if(state.actions.some(a=>a.requestId===requestId))return state;
  for(const signal of state.signals.filter(s=>s.status==='active')){
    signal.status='closed_by_new_session';signal.completedSeq=state.seq;
  }
  for(const attempt of state.attempts.filter(a=>a.status==='pending'))attempt.status='interrupted';
  state.sessionNumber++;
  state.sessionStartSeq=state.seq;
  state.streaks={red:0,black:0,even:0,odd:0,low:0,high:0};
  state.window={lastGreenSeq:null,endSeq:null,generation:0};
  state.actions.push({requestId,kind:'startNewSession',sessionNumber:state.sessionNumber});
  return state;
}
export function windowRemaining(current){
  const s=safeState(current);
  return s.window.endSeq===null?0:Math.max(0,s.window.endSeq-s.seq);
}

/** Registra un resultado respetando la carga inicial de cinco giros de CADA sesión. */
export function recordSessionResult(current, raw, requestId=uuid(), options={}) {
  const state=safeState(current);
  const isSeed=(state.seq-state.sessionStartSeq)<5;
  return addResult(state,raw,requestId,{...options,seed:isSeed});
}
export function initialResultsRemaining(current){
  const state=safeState(current);
  return Math.max(0,5-(state.seq-state.sessionStartSeq));
}

/** Carga opcional por lote de 5 a 10 resultados de contexto, antes del primer giro.
 * No crea señales ni consume créditos; se conserva como un evento único del servidor. */
export function seedHistory(current,values,requestId=uuid(),options={}) {
 const state=safeState(current);
 if(!Array.isArray(values)||values.length<5||values.length>10)throw Error('INITIAL_HISTORY_RANGE');
 if(state.seq!==state.sessionStartSeq||state.signals.length&&state.signals.some(x=>x.status==='active'))throw Error('INITIAL_HISTORY_ALREADY_STARTED');
 let next=state;
 for(let i=0;i<values.length;i++)next=addResult(next,normalizeNumber(values[i]),`${requestId}:seed:${i}`,{...options,seed:true,seedLimit:10});
 next.actions=next.actions.filter(x=>!String(x.requestId).startsWith(`${requestId}:seed:`));
 next.actions.push({requestId,kind:'seedHistory',count:values.length,seq:next.seq});
 return next;
}
