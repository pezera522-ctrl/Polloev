/** Single unresolved operation per account. No browser retry may generate a second UUID. */
export function createOutbox(storage,{prefix='rucaleta-pending-v1'}={}){
 const key=userId=>`${prefix}:${userId}`;
 const get=userId=>{try{const raw=storage.getItem(key(userId));return raw?JSON.parse(raw):null}catch{return null}};
 const put=(userId,operation)=>{storage.setItem(key(userId),JSON.stringify(operation));return operation};
 const clear=userId=>storage.removeItem(key(userId));
 return {get,put,clear};
}
