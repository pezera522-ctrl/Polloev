/** Stable app adapter; local SQLite QA is ONLY enabled on loopback :8766. */
import * as supabase from './supabase.js';
import {LOCAL_QA_INTEGRATION} from './config.js';
const STORAGE='rucaleta-v11-local-session';
const token=()=>localStorage.getItem(STORAGE);
async function call(path,{method='GET',body=null}={}){
 const headers={'Content-Type':'application/json'};
 if(token())headers.Authorization=`Bearer ${token()}`;
 let response;
 try{response=await fetch('/api'+path,{method,headers,body:body===null?undefined:JSON.stringify(body),cache:'no-store'});}
 catch(e){throw Object.assign(Error('La conexión local se interrumpió.'),{ambiguous:true});}
 const data=await response.json().catch(()=>({error:'INVALID_RESPONSE'}));
 if(!response.ok)throw Object.assign(Error(data.error||`HTTP_${response.status}`),{status:response.status,code:data.error});
 return data;
}
const local={
 async signUp(email,password){const s=await call('/signup',{method:'POST',body:{email,password}});localStorage.setItem(STORAGE,s.access_token);return s;},
 async signIn(email,password){const s=await call('/login',{method:'POST',body:{email,password}});localStorage.setItem(STORAGE,s.access_token);return s;},
 async logout(){try{await call('/logout',{method:'POST',body:{}});}finally{localStorage.removeItem(STORAGE);}},
 async userInfo(){if(!token())return null;try{return await call('/user')}catch{localStorage.removeItem(STORAGE);return null}},
 async getLegal(){return call('/legal')},
 async acceptLegal(docs){return call('/legal/accept',{method:'POST',body:{documents:docs.map(d=>({id:d.id,sha256:d.sha256})),adult:true}})},
 async getAccess(){return call('/access')},
 async requestPasswordReset(){throw Error('Recuperación de contraseña desactivada en QA local.')},
 async analysisApi(action=null,payload={},requestId=null,expectedRevision=undefined){
  return call('/analysis',action?{method:'POST',body:{action,payload,request_id:requestId,expected_revision:expectedRevision}}:{});
 }
};
export const signUp=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).signUp(...x);
export const signIn=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).signIn(...x);
export const logout=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).logout(...x);
export const userInfo=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).userInfo(...x);
export const getLegal=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).getLegal(...x);
export const acceptLegal=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).acceptLegal(...x);
export const getAccess=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).getAccess(...x);
export const requestPasswordReset=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).requestPasswordReset(...x);
export const analysisApi=(...x)=>(LOCAL_QA_INTEGRATION?local:supabase).analysisApi(...x);
