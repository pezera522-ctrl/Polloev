/** Read-only UI projection of a PostgreSQL-authoritative event stream.
 * Server owns signals, attempts, credits and revisions; this module never computes a charge.
 * Fail closed on incomplete or inconsistent server responses.
 */
import {emptyState,normalizeNumber,attributes} from './engine.js';
const integer=(v)=>Number.isSafeInteger(Number(v))&&Number(v)>=0;
const obj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const assert=(condition,code)=>{if(!condition)throw Error('REMOTE_PROJECTION_'+code)};
export function projectV15Read(data){
 assert(obj(data),'RESPONSE');
 const stream=data.stream,events=data.events,signals=data.signals,attempts=data.attempts;
 assert(Array.isArray(events)&&Array.isArray(signals)&&Array.isArray(attempts),'ARRAYS');
 const state=emptyState();let rev=0,seq=0,session=1,start=0,seeded=false,greenEnd=null,lastGreen=null,generation=0;
 let streaks={...state.streaks};
 for(const e of events){
  assert(obj(e)&&integer(e.revision)&&Number(e.revision)===rev+1,'REVISION');rev++;
  assert(['seed_history','spin','confirm','new_session'].includes(e.action)&&obj(e.payload),'EVENT');
  if(e.action==='new_session'){
   session++;start=seq;seeded=false;greenEnd=null;lastGreen=null;generation=0;
   streaks={red:0,black:0,even:0,odd:0,low:0,high:0};
   state.actions.push({requestId:e.request_id,kind:'startNewSession',sessionNumber:session});continue;
  }
  if(e.action==='confirm'){
   state.actions.push({requestId:e.request_id,kind:'confirmBet'});continue;
  }
  const values=e.action==='seed_history'?e.payload.values:[e.payload.value];
  assert(Array.isArray(values)&&values.length>0,'RESULTS');
  if(e.action==='seed_history'){
   assert(!seeded&&seq===start&&values.length>=5&&values.length<=10,'SEED');seeded=true;
  }else assert(seeded,'SPIN_BEFORE_SEED');
  for(const raw of values){
   assert(typeof raw==='string','NUMBER_TYPE');const value=normalizeNumber(raw);seq++;
   state.results.push({seq,value,at:e.at||null});
   if(state.results.length>500)state.results.shift();
   const a=attributes(value);
   if(!a){lastGreen=seq;greenEnd=seq+30;generation++;}
   else for(const [category,targets] of Object.entries({color:['red','black'],parity:['even','odd'],half:['low','high']}))
    for(const target of targets)streaks[target]=a[category]===target?0:streaks[target]+1;
   if(greenEnd!==null&&seq>=greenEnd)greenEnd=null;
  }
  state.actions.push({requestId:e.request_id,kind:e.action==='seed_history'?'seedHistory':'addResult',seq});
 }
 if(stream===null){assert(events.length===0&&signals.length===0&&attempts.length===0,'EMPTY');return {state,revision:0,free_credits_remaining:integer(data.free_credits_remaining)?Number(data.free_credits_remaining):null,premium_active:false};}
 assert(obj(stream)&&integer(stream.revision)&&Number(stream.revision)===rev,'STREAM_REVISION');
 assert(integer(stream.seq)&&Number(stream.seq)===seq,'STREAM_SEQ');
 assert(Number(stream.session_no)===session&&Number(stream.session_start_seq)===start,'SESSION');
 assert(stream.seeded===seeded,'SEEDED');
 assert(JSON.stringify(stream.streaks)===JSON.stringify(streaks)||Object.keys(streaks).every(k=>Number(stream.streaks?.[k])===streaks[k]),'STREAKS');
 assert((stream.green_end===null?null:Number(stream.green_end))===greenEnd,'WINDOW');
 assert(integer(stream.credits)&&Number(stream.credits)<=5,'CREDITS');
 const ids=new Set();const groups=new Map();
 for(const s of signals){
  assert(obj(s)&&typeof s.id==='string'&&!ids.has(s.id),'SIGNAL_ID');ids.add(s.id);
  assert(['color','parity','half'].includes(s.category)&&typeof s.target==='string'&&integer(s.trigger_seq),'SIGNAL');
  const key=`${s.session_no}:${s.trigger_seq}`;
  if(!groups.has(key))groups.set(key,{id:key,key,triggerSeq:Number(s.trigger_seq),sessionNumber:Number(s.session_no),creditStatus:'charged'});
  state.signals.push({id:s.id,groupId:key,category:s.category,target:s.target,triggerSeq:Number(s.trigger_seq),status:s.status,specialWindow:!!s.special,windowEndSeq:s.window_end===null?null:Number(s.window_end),completedSeq:s.completed_seq===null?undefined:Number(s.completed_seq),createdAt:null});
 }
 for(const a of attempts){
  assert(obj(a)&&ids.has(a.signal_id)&&integer(a.number)&&Number(a.number)>=1&&Number(a.number)<=4,'ATTEMPT');
  state.attempts.push({id:a.id,signalId:a.signal_id,attemptNumber:Number(a.number),stake:Number(a.stake),scheme:a.scheme,status:a.status,result:a.result,resolvedSeq:a.resolved_seq===null?undefined:Number(a.resolved_seq)});
 }
 state.seq=seq;state.streaks=streaks;state.sessionNumber=session;state.sessionStartSeq=start;
 state.window={lastGreenSeq:lastGreen,endSeq:greenEnd,generation};state.groups=[...groups.values()];
 return {state,revision:rev,free_credits_remaining:Number(stream.credits),premium_active:false};
}
