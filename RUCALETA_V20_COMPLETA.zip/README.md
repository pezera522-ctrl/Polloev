# RUCALETA V20 QA

Continúa la V19 con la misma identidad y el mismo movimiento de ruleta. Añade profundidad visual, edición administrativa de códigos y un servicio separado de pagos en pruebas.

Para subir manualmente la web utiliza RUCALETA_V20_WEB.zip. No necesita compilación. Para conservar el proyecto, las pruebas y el servicio usa RUCALETA_V20_COMPLETA.zip. Los PNG originales están preservados en el completo; la web usa sus versiones WebP.

`ESTADO.md` resume lo implementado y lo pendiente. `COMANDOS.md` contiene instrucciones de terminal. `payments-server/README.md` describe la integración de pago preparada y sus límites. Pagos desactivados, sin credenciales privadas ni activación automática de premium. El panel administrativo exige el rol real en el servidor.

QA: xpkzzmnwzodikygfsdkp. No ejecutes sql/reference_v16; son archivos históricos. No hubo migraciones de base de datos en V20.
