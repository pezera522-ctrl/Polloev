# Comandos separados · ejecutar dentro de la carpeta descomprimida

Abrir una vista local o en Codespaces:

```bash
python3 -m http.server 8767 --bind 0.0.0.0
```

En Codespaces abre el puerto 8767 desde **Ports**. En un equipo local abre http://localhost:8767. No abras el HTML directamente con `file://`.

Instalar únicamente dependencias de pruebas y comprobar la entrega:

```bash
npm ci
npm test
npm run test:static
```

Pruebas visuales adicionales, con el servidor anterior activo:

```bash
npx playwright install --with-deps chromium webkit
npm run test:mobile
```

Esta última suite no se ejecutó en Work: requiere navegadores disponibles. Guarda capturas y comprueba movimiento, tamaños, navegación pública y desbordamientos. No sustituye Safari físico ni Auth real.

No hay comandos de push, despliegue o pagos. No vuelvas a ejecutar `sql/reference_v16`: QA ya está configurado. La asignación del propietario requiere revisar su UUID en `sql/bootstrap_admin_MANUAL.sql`.


## Servicio de pagos separado (opcional, desactivado por defecto)

Requiere Node 24.19 o posterior. Desde la carpeta del proyecto completo:

```bash
node tests/payments_service.mjs
node payments-server/server.mjs
```

La primera orden prueba con dobles y SQLite en memoria; no llama a Mercado Pago. La segunda inicia el servicio desactivado, sin habilitar compras. No abre ni publica la web.

Para la futura prueba externa configura los campos de payments-server/env.example como secretos/variables del servidor de hosting. No pongas un archivo con secretos dentro del ZIP público ni en GitHub. El servicio requiere proxy HTTPS del mismo dominio y disco persistente. La activación de premium todavía necesita el puente descrito en payments-server/README.md; no hay un comando de despliegue comercial en esta entrega.
