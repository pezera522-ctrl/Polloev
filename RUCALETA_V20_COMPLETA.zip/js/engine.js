/** RUCALETA — motor determinista del laboratorio, sin apuestas reales ni cobros.
 * Es independiente de la red, conserva 0 y 00 como valores diferentes y es testeable en Node.
 */
export const RED = Object.freeze(new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]));
export const TARGETS = Object.freeze({color:['red','black'], parity:['even','odd'],half:['low','high']});
export const STAKES = Object.freeze({A:[4,8,16,32],B:[5,10,20,40]});
const MAX_RESULTS=500;
export function normalizeNumber(input) {
  const raw=String(input ?? '').trim();
  if(raw==='00') return '00';
  if(!/^(?:0|[1-9]|[12]\d|3[0-6])$/.test(raw)) throw new Error('El resultado debe ser 0, 00 o un número del 1 al 36.');
  return raw;
}
export function attributes(input) {
  const n=normalizeNumber(input);
  if(n==='0'||n==='00') return null;
  const number=Number(n);
  return {color:RED.has(number)?'red':'black',parity:number%2===0?'even':'odd',half:number<=18?'low':'high'};
}
export const friendly={red:'Rojo',black:'Negro',even:'Par',odd:'Impar',low:'1–18',high:'19–36'};
export function emptyState(){return {version:1,results:[],streaks:{red:0,black:0,even:0,odd:0,low:0,high:0},signals:[],attempts:[],actions:[],seq:0,window:{lastGreenSeq:null,endSeq:null,generation:0},sessionNumber:1,sessionStartSeq:0,groups:[]};}
