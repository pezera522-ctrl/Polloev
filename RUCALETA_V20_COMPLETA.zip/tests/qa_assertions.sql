-- Transactional fixtures only. Every inserted test row is rolled back.
BEGIN;
INSERT INTO auth.users(id,email) VALUES('16000000-0000-4000-8000-000000000001','v16-transient-a@example.invalid'),('16000000-0000-4000-8000-000000000002','v16-transient-b@example.invalid');
INSERT INTO rucaleta_v16.admins VALUES('16000000-0000-4000-8000-000000000002');
INSERT INTO public.legal_consents(user_id,legal_document_id,document_sha256) SELECT u,d.id,d.content_sha256 FROM unnest(ARRAY['16000000-0000-4000-8000-000000000001'::uuid,'16000000-0000-4000-8000-000000000002'::uuid]) u CROSS JOIN public.legal_documents d WHERE d.status='active';
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000001',true);
DO $$ DECLARE r jsonb;rev bigint:=0;request uuid:=gen_random_uuid();s uuid;i integer;n integer;before_count integer;BEGIN
 BEGIN PERFORM public.rucaleta_v16_admin();RAISE EXCEPTION 'FAIL non-admin';EXCEPTION WHEN insufficient_privilege THEN NULL;END;
 BEGIN PERFORM * FROM rucaleta_v16.streams;RAISE EXCEPTION 'FAIL raw table';EXCEPTION WHEN insufficient_privilege THEN NULL;END;
 BEGIN PERFORM public.rucaleta_v16_apply(gen_random_uuid(),0,'seed_history','{"values":["1","2","3","4","5","6","7","8","9","10","11"]}');RAISE EXCEPTION 'FAIL eleven seed';EXCEPTION WHEN invalid_parameter_value THEN NULL;END;
 r:=public.rucaleta_v16_apply(request,0,'seed_history','{"values":["0","1","1","1","1"]}');rev:=1;
 r:=public.rucaleta_v16_apply(request,0,'seed_history','{"values":["0","1","1","1","1"]}');IF NOT (r->>'replayed')::boolean THEN RAISE EXCEPTION 'FAIL replay';END IF;
 BEGIN PERFORM public.rucaleta_v16_apply(request,0,'spin','{"value":"1"}');RAISE EXCEPTION 'FAIL conflicting replay';EXCEPTION WHEN invalid_parameter_value THEN NULL;END;
 BEGIN PERFORM public.rucaleta_v16_apply(gen_random_uuid(),0,'spin','{"value":"1"}');RAISE EXCEPTION 'FAIL revision';EXCEPTION WHEN serialization_failure THEN NULL;END;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"1"}');rev:=rev+1;
 IF (r->>'debited')::int<>1 OR jsonb_array_length(r->'created_signals')<>3 THEN RAISE EXCEPTION 'FAIL group charge';END IF;
 s:=(r->'created_signals'->0->>'id')::uuid;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'confirm',jsonb_build_object('signal_id',s,'stake',4));rev:=rev+1;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"00"}');rev:=rev+1;
 IF public.rucaleta_v16_read()->'attempts'->0->>'status'<>'lost' THEN RAISE EXCEPTION 'FAIL green loss';END IF;
 BEGIN PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'confirm',jsonb_build_object('signal_id',s,'stake',10));RAISE EXCEPTION 'FAIL wrong progression';EXCEPTION WHEN invalid_parameter_value THEN NULL;END;
 FOR i IN 2..4 LOOP
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'confirm',jsonb_build_object('signal_id',s,'stake',4*power(2,i-1)));rev:=rev+1;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"0"}');rev:=rev+1;
 END LOOP;
 IF public.rucaleta_v16_read()->'attempts'->3->>'status'<>'lost' THEN RAISE EXCEPTION 'FAIL fourth';END IF;
 FOR i IN 1..30 LOOP r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin',jsonb_build_object('value',CASE WHEN i%2=0 THEN '2' ELSE '1' END));rev:=rev+1;END LOOP;
 r:=public.rucaleta_v16_read();IF r->'stream'->>'green_end' IS NOT NULL THEN RAISE EXCEPTION 'FAIL window boundary';END IF;
 before_count:=jsonb_array_length(r->'signals');
 FOR i IN 1..7 LOOP PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"36"}');rev:=rev+1;END LOOP;
 IF jsonb_array_length(public.rucaleta_v16_read()->'signals')<>before_count THEN RAISE EXCEPTION 'FAIL outside window';END IF;
 IF NOT (public.rucaleta_v16_verify()->>'valid')::boolean THEN RAISE EXCEPTION 'FAIL integrity';END IF;
END $$;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000002',true);
DO $$DECLARE r jsonb;BEGIN
 r:=public.rucaleta_v16_read();IF jsonb_array_length(r->'events')<>0 THEN RAISE EXCEPTION 'FAIL cross user read';END IF;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),0,'seed_history','{"values":["00","1","2","3","4","5","6","7","8","9"]}');IF (r->>'seq')::int<>10 THEN RAISE EXCEPTION 'FAIL ten seed';END IF;PERFORM public.rucaleta_v16_verify();
 r:=public.rucaleta_v16_admin('code','{"code":"TEST16","creator_id":"16000000-0000-4000-8000-000000000002","discount_pct":20,"commission_pct":10,"active":true}');
 r:=public.rucaleta_v16_admin('subscription',jsonb_build_object('user_id','16000000-0000-4000-8000-000000000001','expires_at',now()+interval '1 month','enabled',true));
END $$;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000001',true);
DO $$DECLARE r jsonb;rev bigint;balance integer;BEGIN
 r:=public.rucaleta_v16_read();rev:=(r->'stream'->>'revision')::bigint;balance:=(r->>'free_credits_remaining')::int;
 r:=public.rucaleta_v16_redeem('test16');IF (r->>'monthly_cents')::int<>15920 OR NOT (r->>'recurring')::boolean THEN RAISE EXCEPTION 'FAIL recurring discount';END IF;
 PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'new_session','{}');rev:=rev+1;
 PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'seed_history','{"values":["0","1","1","1","1"]}');rev:=rev+1;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"1"}');
 IF (r->>'debited')::int<>0 OR (r->>'free_credits_remaining')::int<>balance OR jsonb_array_length(r->'created_signals')<>3 THEN RAISE EXCEPTION 'FAIL premium';END IF;
 PERFORM public.rucaleta_v16_verify();
END $$;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000002',true);
SELECT public.rucaleta_v16_admin('block','{"user_id":"16000000-0000-4000-8000-000000000001","blocked":true}') IS NOT NULL AS block_saved;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000001',true);
DO $$ BEGIN BEGIN PERFORM public.rucaleta_v16_read();RAISE EXCEPTION 'FAIL blocked user';EXCEPTION WHEN insufficient_privilege THEN NULL;END;END $$;
RESET ROLE;
SET LOCAL ROLE anon;
DO $$ BEGIN BEGIN PERFORM public.rucaleta_v16_read();RAISE EXCEPTION 'FAIL anonymous';EXCEPTION WHEN insufficient_privilege THEN NULL;END;END $$;
RESET ROLE;

RESET ROLE;
INSERT INTO auth.users(id,email) VALUES('16000000-0000-4000-8000-000000000003','v16-zero@example.invalid');
INSERT INTO public.legal_consents(user_id,legal_document_id,document_sha256) SELECT '16000000-0000-4000-8000-000000000003',id,content_sha256 FROM public.legal_documents WHERE status='active';
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000003',true);
DO $$DECLARE rev bigint:=0;i integer;r jsonb;BEGIN
 FOR i IN 1..6 LOOP
 IF i>1 THEN PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'new_session','{}');rev:=rev+1;END IF;
 PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'seed_history','{"values":["0","1","1","1","1"]}');rev:=rev+1;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"1"}');rev:=rev+1;
 IF i=6 AND ((r->>'debited')::int<>0 OR jsonb_array_length(r->'created_signals')<>0) THEN RAISE EXCEPTION 'FAIL zero credits';END IF;
 END LOOP;
 IF (r->>'free_credits_remaining')::int<>0 THEN RAISE EXCEPTION 'FAIL session refill';END IF;
END $$;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000002',true);
SELECT public.rucaleta_v16_admin('subscription',jsonb_build_object('user_id','16000000-0000-4000-8000-000000000003','expires_at',now()+interval '1 day','enabled',true)) IS NOT NULL AS premium_zero;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000003',true);
DO $$DECLARE rev bigint;r jsonb;BEGIN
 rev:=(public.rucaleta_v16_read()->'stream'->>'revision')::bigint;
 PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'new_session','{}');rev:=rev+1;
 PERFORM public.rucaleta_v16_apply(gen_random_uuid(),rev,'seed_history','{"values":["0","1","1","1","1"]}');rev:=rev+1;
 r:=public.rucaleta_v16_apply(gen_random_uuid(),rev,'spin','{"value":"1"}');
 IF (r->>'free_credits_remaining')::int<>0 OR jsonb_array_length(r->'created_signals')<>3 THEN RAISE EXCEPTION 'FAIL premium zero';END IF;
END $$;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000002',true);
SELECT public.rucaleta_v16_admin('subscription',jsonb_build_object('user_id','16000000-0000-4000-8000-000000000003','expires_at',now()-interval '1 day','enabled',true)) IS NOT NULL AS expired;
SELECT set_config('request.jwt.claim.sub','16000000-0000-4000-8000-000000000003',true);
DO $$BEGIN IF (public.rucaleta_v16_read()->>'premium_active')::boolean THEN RAISE EXCEPTION 'FAIL expired premium';END IF;END $$;
SELECT 'PASS: zero credits, no refill, premium at zero, expiration, seed, group debit, replay, conflict, revision, green, fourth, window, integrity, isolation, RLS/grants, admin, premium, recurring discount, block, anon' AS result;
ROLLBACK;
