// Rendered regression suite. Requires installed browsers; never creates QA users.
// Public flows only. Run against a static server of THIS package.
const {chromium,webkit}=require('playwright');const assert=require('node:assert/strict');const fs=require('node:fs');
(async()=>{fs.mkdirSync('artifacts/browser',{recursive:true});
for(const [name,type]of Object.entries({chromium,webkit})){
 const browser=await type.launch({headless:true});
 for(const width of [375,390,430,768,1280]){
  const context=await browser.newContext({viewport:{width,height:844},isMobile:width<768,hasTouch:width<768});const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  // Block external writes: this public-render suite must not create accounts.
  await page.route('https://xpkzzmnwzodikygfsdkp.supabase.co/**',route=>route.fulfill({status:403,contentType:'application/json',body:'{"message":"External writes disabled in rendering tests"}'}));
  await page.goto(process.env.RUCALETA_TEST_URL||'http://127.0.0.1:8767');
  const capture=async(screen)=>{assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`${name}/${width}/${screen} overflow`);await page.screenshot({path:`artifacts/browser/${name}-${width}-${screen}.png`,fullPage:true});};
  await capture('cover');await page.locator('#boton-iniciar').click();await page.locator('#transicion-ruleta').waitFor({state:'visible'});
  await page.waitForTimeout(200);const a=await page.locator('#ruleta-animada').evaluate(el=>getComputedStyle(el).transform);await page.waitForTimeout(250);const b=await page.locator('#ruleta-animada').evaluate(el=>getComputedStyle(el).transform);assert.notEqual(a,b,'Rotor must actually move');
  await page.locator('#pantalla-login').waitFor({state:'visible'});await capture('login');await page.locator('#show-signup').click();assert.equal(await page.locator('#register-confirm-password').isVisible(),true);await capture('registration');
  await page.locator('#login-usuario').fill('invalid');await page.locator('#signup').click();assert.match(await page.locator('#mensaje-login').textContent(),/correo/i);
  await page.locator('#show-login').click();await page.getByRole('button',{name:'Guía',exact:true}).click();assert.equal(await page.locator('#help-dialog').isVisible(),true);await capture('guide');await page.locator('#close-help').click();
  assert.deepEqual(errors,[]);await context.close();console.log(`PASS ${name} ${width}: cover, rotor motion, login/register, validation, guide, overflow`);
 }
 const context=await browser.newContext({viewport:{width:390,height:844},reducedMotion:'reduce'});const page=await context.newPage();await page.goto(process.env.RUCALETA_TEST_URL||'http://127.0.0.1:8767');await page.locator('#boton-iniciar').click();await page.locator('#pantalla-login').waitFor({state:'visible',timeout:1200});await context.close();await browser.close();
}})().catch(e=>{console.error(e);process.exitCode=1;});
