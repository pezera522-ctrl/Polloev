# Servicio de pagos QA · preparado, no desplegado

Node 24.19 o posterior. Servicio HTTP independiente, sin Edge Functions ni claves privadas incluidas. No se ejecuta desde un hosting estático. Usa almacenamiento SQLite persistente; desplegar una sola instancia con volumen duradero y proxy HTTPS. El servidor escucha en 127.0.0.1:8788 y no sirve archivos.

## Implementado y probado con dobles explícitos

- Verificar sesión contra Supabase QA y limitar acceso a UUIDs autorizados para pruebas.
- Obtener precio/descuento recurrente del RPC del servidor, no del cliente; exigir consentimiento vigente para crear un contrato.
- Verificar vendedor de prueba antes de solicitar cambios; crear suscripción mensual pendiente en MXN, consultar estado y cancelar contrato propio.
- Persistir intención antes de solicitarla. Si la creación falla ambiguamente, bloquear otro contrato hasta revisar Mercado Pago; no repetir ciegamente la creación.
- Verificar firma HMAC del webhook y antigüedad, volver a consultar suscripción/factura/pago en Mercado Pago, exigir live_mode=false en pagos y verificar vendedor, importe y moneda.
- Registrar pagos de prueba por ID sin duplicarlos. Una autorización de suscripción por sí sola NO significa pago confirmado.
- No admite modo live. No registra tarjetas, tokens de Auth ni credenciales en SQLite.

## Pendiente antes de usarlo

1. Configurar credenciales del vendedor de PRUEBA, ID de esa cuenta, correo del comprador de prueba y secreto webhook en el servidor. El prefijo del token no basta para identificar una cuenta de prueba: se comprueba la cuenta con /users/me. Si Mercado Pago no devuelve test_user o site_id MLM, el servicio bloquea la operación.
2. Configurar UUIDs Auth QA permitidos y APP_ORIGIN HTTPS; configurar proxy del mismo origen /api/billing/* al servicio. CORS no está abierto.
3. Registrar URL pública del webhook y tópicos subscription_preapproval y subscription_authorized_payment. Probar entrega y firma con la cuenta real de prueba. Si hay creación incierta, verificar manualmente el contrato del external_reference antes de reparar la intención local; no borrar el registro sin investigar.
4. Implementar y verificar el puente transaccional entre los pagos confirmados y premium/comisiones en Supabase. Esta entrega registra entitlement_status=pending_integration y NO concede premium. No está conectado el botón de compra de la web porque ese puente aún falta.
5. Validar renovaciones, cancelaciones, reembolsos/contracargos y recuperación tras fallos end-to-end. El servicio no está listo para producción.

Rutas: GET /api/billing/capabilities; GET /api/billing/status; POST /api/billing/checkout; POST /api/billing/cancel. Salvo capabilities/webhook, requieren Authorization Bearer de Supabase y UUID QA permitido. POST /api/billing/webhook valida firma; nunca confía en el estado recibido del navegador.

No compartas claves en el chat. `env.example` contiene únicamente nombres vacíos y el modo desactivado. Configúralas como secretos del proveedor de hosting; comandos en COMANDOS.md de la entrega.

Documentación consultada:
- https://www.mercadopago.com.mx/developers/es/docs/subscriptions/integration-configuration/subscription-no-associated-plan/pending-payments
- https://www.mercadopago.com.mx/developers/es/docs/your-integrations/notifications/webhooks
- https://www.mercadopago.com.mx/developers/es/reference/online-payments/subscriptions/get-authorized-payment/get
- https://www.mercadopago.com.mx/developers/es/news/2023/11/16/Questions-on-how-to-test-your-integration--
