import {DatabaseSync} from 'node:sqlite';
export function openStore(path){
 const db=new DatabaseSync(path);db.exec(`PRAGMA journal_mode=WAL;PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS intents(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,cents INTEGER NOT NULL CHECK(cents>0),state TEXT NOT NULL,provider_id TEXT UNIQUE,checkout TEXT,created_at TEXT NOT NULL);
 CREATE UNIQUE INDEX IF NOT EXISTS one_open_intent ON intents(user_id) WHERE state<>'cancelled';
 CREATE TABLE IF NOT EXISTS test_payments(payment_id TEXT PRIMARY KEY,intent_id TEXT NOT NULL,status TEXT NOT NULL,cents INTEGER NOT NULL,verified_at TEXT NOT NULL,entitlement_status TEXT NOT NULL DEFAULT 'pending_integration');`);
 return {db,close:()=>db.close(),current:user=>db.prepare('SELECT * FROM intents WHERE user_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1').get(user),byProvider:id=>db.prepare('SELECT * FROM intents WHERE provider_id=?').get(String(id)),
 create:r=>db.prepare('INSERT INTO intents(id,user_id,cents,state,created_at) VALUES(?,?,?,?,?)').run(r.id,r.user_id,r.cents,'creating',new Date().toISOString()),
 bind:(id,providerId,checkout)=>db.prepare("UPDATE intents SET provider_id=?,checkout=?,state='pending' WHERE id=?").run(String(providerId),checkout,id),
 mark:(id,state)=>db.prepare('UPDATE intents SET state=? WHERE id=?').run(state,id),
 record:r=>db.prepare(`INSERT INTO test_payments(payment_id,intent_id,status,cents,verified_at) VALUES(?,?,?,?,?) ON CONFLICT(payment_id) DO UPDATE SET status=excluded.status,verified_at=excluded.verified_at WHERE test_payments.intent_id=excluded.intent_id`).run(String(r.id),r.intent_id,r.status,r.cents,new Date().toISOString()),
 payments:intent=>db.prepare('SELECT payment_id,status,cents,entitlement_status FROM test_payments WHERE intent_id=? ORDER BY verified_at DESC LIMIT 20').all(intent)};
}
