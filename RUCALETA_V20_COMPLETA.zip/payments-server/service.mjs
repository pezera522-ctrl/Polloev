import {randomUUID} from 'node:crypto';
import {BillingError,cents,safeCheckout,verifySignature} from './provider.mjs';
// Server-only QA service. No path grants premium or writes production data.
export function createBilling({provider,store,authenticate,quote,testSellerId,testPayerEmail,allowedUsers,returnUrl,webhookSecret,enabled=false}){
 const allowed=new Set(allowedUsers);const gate=()=>{if(!enabled)throw new BillingError('PAYMENTS_NOT_CONFIGURED',503);};
 async function user(token){gate();const u=await authenticate(token);if(!u?.id||!allowed.has(u.id))throw new BillingError('QA_BILLING_ACCESS_REQUIRED',403);return u;}
 async function owned(row){await provider.verifySeller();const s=await provider.request('/preapproval/'+encodeURIComponent(row.provider_id));if(String(s.id)!==row.provider_id||s.external_reference!==row.id||String(s.collector_id)!==String(testSellerId)||s.auto_recurring?.currency_id!=='MXN'||cents(s.auto_recurring?.transaction_amount)!==row.cents)throw new BillingError('SUBSCRIPTION_MISMATCH',409);return s;}
 return {
  async checkout(token){const u=await user(token);const prior=store.current(u.id);if(prior&&prior.state!=='cancelled'){if(!prior.checkout)throw new BillingError('CREATION_UNCERTAIN_REVIEW_REQUIRED',409);return {checkout_url:prior.checkout,state:prior.state,mode:'test',premium_activated:false};}
   const q=await quote(token);if(q.currency!=='MXN'||!Number.isSafeInteger(q.monthly_cents)||q.monthly_cents<=0||q.monthly_cents>19900)throw new BillingError('INVALID_SERVER_QUOTE',409);
   await provider.verifySeller();const id=randomUUID();store.create({id,user_id:u.id,cents:q.monthly_cents});
   // Persist first. Ambiguous provider failures are never retried as new contracts.
   try{const r=await provider.request('/preapproval','POST',{reason:'RUCALETA Premium · PRUEBA',external_reference:id,payer_email:testPayerEmail,auto_recurring:{frequency:1,frequency_type:'months',transaction_amount:q.monthly_cents/100,currency_id:'MXN'},back_url:returnUrl,status:'pending'});if(!r.id||r.external_reference!==id)throw new BillingError('INVALID_PROVIDER_RESPONSE',502);const url=safeCheckout(r.init_point);store.bind(id,r.id,url);return {checkout_url:url,state:'pending',mode:'test',premium_activated:false};}catch(e){store.mark(id,'creation_uncertain');throw e;}
  },
  async status(token){const u=await user(token),row=store.current(u.id);if(!row)return {state:'none',mode:'test',premium_activated:false};let state=row.state;if(row.provider_id){const s=await owned(row);if(row.state!=='cancelled'){state=s.status;if(!['pending','authorized','paused','cancelled'].includes(state))throw new BillingError('UNKNOWN_PROVIDER_STATUS',502);store.mark(row.id,state);}}return {state,mode:'test',monthly_cents:row.cents,payments:store.payments(row.id),premium_activated:false};},
  async cancel(token){const u=await user(token),row=store.current(u.id);if(!row?.provider_id)throw new BillingError('SUBSCRIPTION_NOT_FOUND',404);await owned(row);if(row.state!=='cancelled'){const r=await provider.request('/preapproval/'+encodeURIComponent(row.provider_id),'PUT',{status:'cancelled'});if(r.status!=='cancelled')throw new BillingError('CANCELLATION_UNCONFIRMED',502);store.mark(row.id,'cancelled');}return {state:'cancelled',mode:'test',premium_activated:false};},
  async webhook({signature,requestId,dataId,body}){gate();verifySignature({signature,requestId,dataId,secret:webhookSecret});if(String(body?.data?.id).toLowerCase()!==String(dataId).toLowerCase())throw new BillingError('WEBHOOK_ID_MISMATCH',400);
   if(!['subscription_preapproval','subscription_authorized_payment'].includes(body.type))return {ignored:true};
   await provider.verifySeller();
   if(body.type==='subscription_preapproval'){const row=store.byProvider(dataId);if(!row)return {ignored:true};const s=await owned(row);if(row.state!=='cancelled'&&['pending','authorized','paused','cancelled'].includes(s.status))store.mark(row.id,s.status);return {received:true,premium_activated:false};}
   const invoice=await provider.request('/authorized_payments/'+encodeURIComponent(dataId));const row=store.byProvider(invoice.preapproval_id);if(!row)return {ignored:true};await owned(row);
   if(!invoice.payment?.id)return {received:true,premium_activated:false};
   const pay=await provider.request('/v1/payments/'+encodeURIComponent(invoice.payment.id));
   if(String(pay.id)!==String(invoice.payment.id)||pay.live_mode!==false||String(pay.collector_id)!==String(testSellerId)||pay.currency_id!=='MXN'||cents(pay.transaction_amount)!==row.cents)throw new BillingError('TEST_PAYMENT_MISMATCH',409);
   store.record({id:pay.id,intent_id:row.id,status:pay.status,cents:row.cents});return {received:true,mode:'test',premium_activated:false,entitlement_status:'pending_integration'};
  }
 };
}
