import {createHmac,timingSafeEqual} from 'node:crypto';
export class BillingError extends Error{constructor(code,status=400){super(code);this.status=status;}}
export function verifySignature({signature,requestId,dataId,secret,now=Date.now()}){
 if(!secret||!requestId||!dataId||!signature)throw new BillingError('INVALID_SIGNATURE',401);
 const fields=signature.split(',').map(x=>x.trim().split('='));
 const ts=fields.filter(x=>x[0]==='ts'),macs=fields.filter(x=>x[0]==='v1');
 if(ts.length!==1||macs.length!==1||!/^\d{10,13}$/.test(ts[0][1])||! /^[a-f0-9]{64}$/i.test(macs[0][1]))throw new BillingError('INVALID_SIGNATURE',401);
 const millis=ts[0][1].length===10?Number(ts[0][1])*1000:Number(ts[0][1]);
 if(Math.abs(now-millis)>300000)throw new BillingError('EXPIRED_SIGNATURE',401);
 const text=`id:${String(dataId).toLowerCase()};request-id:${requestId};ts:${ts[0][1]};`;
 const expected=createHmac('sha256',secret).update(text).digest();
 if(!timingSafeEqual(expected,Buffer.from(macs[0][1],'hex')))throw new BillingError('INVALID_SIGNATURE',401);
}
export function safeCheckout(url){const u=new URL(url);if(u.protocol!=='https:'||!['www.mercadopago.com.mx','www.mercadopago.com'].includes(u.hostname)||u.username||u.password)throw new BillingError('UNEXPECTED_CHECKOUT_HOST',502);return u.href;}
export function cents(value){const n=Number(value);if(!Number.isFinite(n)||n<0||Math.abs(n*100-Math.round(n*100))>1e-6)throw new BillingError('INVALID_AMOUNT');return Math.round(n*100);}
export function createProvider({accessToken,testSellerId,fetchImpl=fetch}){
 async function request(path,method='GET',body){
  const r=await fetchImpl('https://api.mercadopago.com'+path,{method,redirect:'error',headers:{Authorization:`Bearer ${accessToken}`,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw new BillingError('PROVIDER_REQUEST_FAILED',502);return r.json();
 }
 return {request,async verifySeller(){const u=await request('/users/me');if(String(u.id)!==String(testSellerId)||!u.tags?.includes('test_user')||u.site_id!=='MLM')throw new BillingError('TEST_SELLER_REQUIRED',503);return u;}};
}
