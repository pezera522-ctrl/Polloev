# V18 · resultado breve de los 20 hallazgos

Fuente única: ZIP V17 adjunto. Se mantiene el motor V16, su proyección y sus activos originales. No se publicó ni se modificó GitHub, producción, Mikosmetics, pagos o Edge Functions.

| Hallazgo | Cambio y prueba / límite |
|---|---|
| H01 | Eliminados los estilos que fijaban el rotor. La rotación la controla un módulo único; se comprobaron muestras de geometría. Falta muestreo en navegador real. |
| H02 | La salida espera las tres animaciones, con timeout de seguridad y fundido posterior. Prueba de espera aprobada. |
| H03 | Bola y rotor comparten destino; 38 alineaciones angulares/radiales y tramo final conjunto comprobados. Es una animación decorativa, no una simulación física certificada. |
| H04 | Una carpeta fuente, un manifiesto y un ZIP verificado tras extracción. |
| H05 | Reescrita y aprobada la prueba de tutorial → documentos → consentimiento → mesa; usuario ya consentido entra directamente. |
| H06 | Adaptador Auth probado con HTTP simulado; API QA accesible. Pendiente registro/confirmación/recuperación con buzón real y dominio final autorizado. |
| H07 | Precio y códigos disponibles; cobros explícitamente desactivados. Proveedor, webhook, renovación, cancelación y conciliación de pagos pendientes. |
| H08 | Teléfono identificado como contacto opcional sin verificación SMS. Acceso real es correo/contraseña; no se promete OTP. |
| H09 | Selector de 5 o 10 resultados; servidor acepta 5–10. Migración QA registrada, pruebas de 5/10 y rechazo de 11 aprobadas. |
| H10 | PostgreSQL QA: RLS/grants, acceso cruzado, usuario bloqueado, anónimo y no administrador aprobados. Avisos heredados detallados abajo. |
| H11 | Una hoja de estilos cargada; retiradas capas externas y todas las reglas antiguas de rueda. Se conserva CSS heredado de otras pantallas para evitar rehacerlas; su limpieza restante es secundaria. |
| H12 | Los cinco recursos WebP suman 973,864 bytes frente a 10,125,372 de los PNG. Se conservan los PNG; carga diferida fuera del inicio. Red lenta no medida en navegador. |
| H13 | Se mantienen CSP, ausencia de scripts externos y renderizado de texto seguro; prueba de XSS en datos aprobada. Tokens siguen en localStorage: riesgo residual de XSS; migración a cookies HttpOnly necesita backend de sesión. |
| H14 | Selector de modos usa botones con aria-pressed y role=group, sin anunciar pestañas incompletas. |
| H15 | Versiones/huellas actuales, rechazo de huellas obsoletas y consentimiento repetido aprobados en PostgreSQL. Contenido legal comercial aún requiere aprobación. |
| H16 | Roles/admin, códigos, suscripciones y bloqueos probados con fixtures transaccionales. Tabla permite seleccionar usuario; cambios sensibles piden confirmación. Hay 0 administradores permanentes: falta el UUID verificado del propietario. |
| H17 | Pruebas de envío ambiguo, reintento del mismo UUID, doble toque y conservación de sesión ante fallo de red aprobadas. Sin carga simultánea real entre navegadores en esta entrega. |
| H18 | Adaptaciones móvil, foco, movimiento reducido, modales y controles implementadas. Safari físico no probado. |
| H19 | Suite de navegador actualizada para Chromium/WebKit, cinco anchos y capturas. No ejecutada: falta control-browser en el entorno gestionado; sin comparación visual aprobada ni umbral de píxeles certificado. |
| H20 | Registro de migración 20261018215419, parche idempotente y scripts históricos separados como referencia. No se reaplicaron instalaciones. |

## Pruebas que sí se ejecutaron

- `npm test`: UI/DOM, Auth con dobles HTTP y geometría/espera de ruleta.
- `npm run test:static`: sintaxis, recursos, IDs, una hoja de estilos, CSP y ausencia de claves privadas evidentes.
- PostgreSQL QA: señales, 0/00, 30 giros, cuarto intento, 1 crédito por grupo, saldo cero, no recarga por nueva sesión, premium/expiración, idempotencia, aislamiento, admin, descuentos y comisiones recurrentes. Todos con rollback.
- Consentimiento real por RPC SQL: hashes, persistencia y reintento. No equivale a una sesión HTTP Auth real.
- HTTP QA: Auth settings 200; lectura/admin sin sesión 401. Fixtures restantes: 0.

## Seguridad heredada pendiente

El asesor no señaló objetos V16 nuevos. Persisten siete avisos informativos de [RLS sin políticas en objetos heredados](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy), cinco [funciones SECURITY DEFINER heredadas expuestas](https://supabase.com/docs/guides/database/database-linter?lint=0029_authenticated_security_definer_function_executable) y [protección de contraseñas filtradas desactivada](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Son límites de salida comercial; no se declaran resueltos.

No todos los 20 hallazgos están cerrados: se distinguen correcciones ejecutadas de verificaciones o integraciones externas pendientes.
