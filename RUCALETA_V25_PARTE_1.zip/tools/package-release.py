"""Package a verified V25 working copy. Never deploys or contacts a service."""
from pathlib import Path, PurePosixPath
import hashlib, json, re, sys, zipfile
root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'entrega_v25'
out.mkdir(parents=True,exist_ok=True)
excluded={'node_modules','private-data','qa-preview','.openai','.git','__pycache__','dist'}
def eligible(p):
 rel=p.relative_to(root)
 return p.is_file() and not p.is_symlink() and not any(x in excluded for x in rel.parts) and p.name!='MANIFIESTO_SHA256.json' and p.suffix.lower() not in {'.zip','.sqlite','.db','.pyc'} and not p.name.startswith('.env') and not p.name.endswith(('.sqlite-wal','.sqlite-shm'))
files=sorted(p for p in root.rglob('*') if eligible(p))
# Check keys without exposing matches in logs. The public Supabase key is not a private credential.
secret_patterns=[rb'sb_secret_[A-Za-z0-9_-]{20,}',rb'(?:APP_USR|TEST)-[0-9]{8,}-[A-Za-z0-9_-]{15,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
for p in files:
 if p.suffix.lower() in {'.js','.mjs','.json','.md','.sql','.txt','.html','.log'}:
  assert not any(re.search(rx,p.read_bytes()) for rx in secret_patterns),f'Private key pattern: {p.relative_to(root)}'
 # A legacy JWT, if any, must never be service_role.
 if p.suffix.lower() in {'.js','.mjs','.json','.html'}:
  import base64
  for match in re.finditer(rb'eyJ[A-Za-z0-9_-]+\.([A-Za-z0-9_-]+)\.[A-Za-z0-9_-]+',p.read_bytes()):
   try: payload=json.loads(base64.urlsafe_b64decode(match[1]+b'='*(-len(match[1])%4)))
   except (ValueError,TypeError): continue
   assert payload.get('role')!='service_role',f'Private JWT: {p.relative_to(root)}'
baseline=json.loads((root/'docs/BASE_ARCHIVOS_ORIGINALES.json').read_text())
comparison={'original_count':len(baseline),'modified_originals':[],'missing_originals':[],'new_files':[],'protected':'tests/fixtures/protected-hashes.json'}
for name,digest in baseline.items():
 p=root/name
 if not p.exists():comparison['missing_originals'].append(name)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=digest:comparison['modified_originals'].append(name)
for p in files:
 name=p.relative_to(root).as_posix()
 if name not in baseline:comparison['new_files'].append(name)
assert not comparison['missing_originals'],'An original file is missing'
(root/'docs/evidencias/COMPARACION_ARCHIVOS.json').write_text(json.dumps(comparison,indent=2,ensure_ascii=False)+'\n')
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
mp=root/'MANIFIESTO_SHA256.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');files.append(mp)
required={'index.html','java.js','app.css','premium-v25.css','package.json','package-lock.json','README.md','INSTALACION_V25.md','PENDIENTES_EXTERNOS.md','PRUEBAS_V25.md','CHANGELOG_V25.md','MIGRACIONES_SQL/04_conciliacion_QA.sql'}
assert required.issubset({p.relative_to(root).as_posix() for p in files})
def make(name,paths):
 zpath=out/name
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(paths):z.write(p,p.relative_to(root).as_posix())
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(set(z.namelist()))
  for n in z.namelist():
   assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
   if n in manifest:assert hashlib.sha256(z.read(n)).hexdigest()==manifest[n]
 return {'file':name,'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'files':len(paths),'crc':'OK'}
reports=[make('RUCALETA_V25_FINAL.zip',files)]
# Part 1 holds all source and instructions. Balance the original large media between both parts.
media={'.png','.webp','.jpeg','.jpg','.mp3','.wav','.mp4'}
parts=[[p for p in files if p.suffix.lower() not in media],[]];sizes=[sum(p.stat().st_size for p in parts[0]),0]
for p in sorted((p for p in files if p.suffix.lower() in media),key=lambda p:-p.stat().st_size):
 i=0 if sizes[0]<=sizes[1] else 1;parts[i].append(p);sizes[i]+=p.stat().st_size
for i,paths in enumerate(parts,1):reports.append(make(f'RUCALETA_V25_PARTE_{i}.zip',paths))
with zipfile.ZipFile(out/reports[0]['file']) as full,zipfile.ZipFile(out/reports[1]['file']) as a,zipfile.ZipFile(out/reports[2]['file']) as b:
 assert not set(a.namelist())&set(b.namelist())
 assert set(a.namelist())|set(b.namelist())==set(full.namelist())
result={'archives':reports,'parts_union_equals_full':True,'private_key_patterns_found':False,'original_files_preserved':True,'production_modified':False}
(out/'VALIDACION_ENTREGA.json').write_text(json.dumps(result,indent=2)+'\n')
for f in ['INSTALACION_V25.md','PENDIENTES_EXTERNOS.md','PRUEBAS_V25.md','CHANGELOG_V25.md','README.md']:(out/f).write_bytes((root/f).read_bytes())
print(json.dumps(result,indent=2))
