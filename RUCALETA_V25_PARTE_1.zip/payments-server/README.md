# Puente de pagos V25 · solo QA

Servicio Node 24.19+, separado del hosting estático. Desactivado por defecto y sin modo live. Configuración y arranque: `../INSTALACION_V25.md`.

Implementa sesión Supabase verificada, lista de UUIDs QA permitidos, cotización del servidor, checkout externo, firma HMAC de webhook, consulta de factura/pago al proveedor y conciliación idempotente. Persiste precio, descuento y comisión del contrato; no depende de porcentajes enviados por el navegador. La RPC service_role `rucaleta_billing_qa_verify` actualiza Premium/comisiones únicamente después de la verificación del servicio. Se conserva SQLite para intenciones y vínculo factura/pago. Los fallos ambiguos de creación requieren revisión.

El SQL del puente ya está aplicado en RUCALETA-QA. Las pruebas locales usan dobles HTTP explícitos y PostgreSQL real desechable. No se contactó Mercado Pago, no se desplegó este servicio y no se activaron cobros. Checkout externo y webhooks reales de prueba siguen pendientes de credenciales e infraestructura HTTPS.

Rutas: GET `/api/billing/capabilities`, GET `/api/billing/status`, POST `/api/billing/checkout`, POST `/api/billing/cancel`, POST `/api/billing/webhook`. Salvo capabilities/webhook requieren Bearer y UUID QA permitido. La cancelación solo afecta al contrato propio y exige respuesta confirmada del proveedor. Bloquear acceso desde administración no cancela renovaciones.

Conservar una sola instancia y volumen duradero. No publicar claves service_role, token Mercado Pago, secreto webhook, SQLite ni `.env`. El ejemplo contiene únicamente variables vacías.

Referencias oficiales utilizadas:
- https://www.mercadopago.com.mx/developers/es/docs/subscriptions/integration-configuration/subscription-no-associated-plan/pending-payments
- https://www.mercadopago.com.mx/developers/es/docs/your-integrations/notifications/webhooks
- https://www.mercadopago.com.mx/developers/es/reference/online-payments/subscriptions/get-authorized-payment/get
