import {createServer} from 'node:http';
import {mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createProvider,BillingError} from './provider.mjs';
import {openStore} from './store.mjs';
import {createBilling} from './service.mjs';
import {createEntitlementBridge} from './bridge.mjs';
const QA='https://xpkzzmnwzodikygfsdkp.supabase.co';
export function readConfig(env=process.env){
 const enabled=env.PAYMENTS_MODE==='sandbox';if(env.PAYMENTS_MODE&&!['disabled','sandbox'].includes(env.PAYMENTS_MODE))throw Error('Only disabled or sandbox mode is supported.');
 const origin=env.APP_ORIGIN||'';if(enabled){if(!origin.startsWith('https://')||new URL(origin).origin!==origin)throw Error('APP_ORIGIN must be an exact HTTPS origin.');for(const k of ['MP_ACCESS_TOKEN','MP_TEST_SELLER_ID','MP_TEST_PAYER_EMAIL','MP_WEBHOOK_SECRET','QA_BILLING_USER_IDS','SUPABASE_PUBLISHABLE_KEY','SUPABASE_SERVICE_ROLE_KEY'])if(!env[k])throw Error('Missing server setting: '+k);if(!env.MP_TEST_PAYER_EMAIL.endsWith('@testuser.com'))throw Error('A Mercado Pago test payer is required.');}
 return {enabled,origin,db:env.BILLING_DB_PATH||'./private-data/billing.sqlite',port:Number(env.PORT||8788),env};
}
export function makeHandler(service,{origin,enabled}){
 const buckets=new Map();
 return async(req,res)=>{
  const reply=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(JSON.stringify(data));};
  try{
   const url=new URL(req.url,'http://localhost');
   if(req.method==='GET'&&url.pathname==='/api/billing/capabilities')return reply(200,{configured:enabled,mode:enabled?'test':'disabled',premium_activation:enabled});
   if(!enabled)throw new BillingError('PAYMENTS_NOT_CONFIGURED',503);
   const ip=req.socket.remoteAddress||'unknown',now=Date.now();for(const [k,v]of buckets)if(v.until<now)buckets.delete(k);if(buckets.size>5000)throw new BillingError('BUSY',503);const bucket=buckets.get(ip)||{count:0,until:now+60000};buckets.set(ip,bucket);if(++bucket.count>60)throw new BillingError('RATE_LIMITED',429);
   const isWebhook=url.pathname==='/api/billing/webhook';
   if(!isWebhook&&req.headers.origin&&req.headers.origin!==origin)throw new BillingError('ORIGIN_DENIED',403);
   if(!isWebhook&&!['GET','POST'].includes(req.method))throw new BillingError('METHOD_NOT_ALLOWED',405);
   const token=/^Bearer (\S+)$/.exec(req.headers.authorization||'')?.[1];
   if(!isWebhook&&!token)throw new BillingError('AUTH_REQUIRED',401);
   let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>16384)throw new BillingError('BODY_TOO_LARGE',413);}
   let body={};try{body=raw?JSON.parse(raw):{};}catch{throw new BillingError('INVALID_JSON',400);}
   if(isWebhook&&req.method==='POST')return reply(200,await service.webhook({signature:req.headers['x-signature'],requestId:req.headers['x-request-id'],dataId:url.searchParams.get('data.id'),body}));
   if(req.method==='GET'&&url.pathname==='/api/billing/status')return reply(200,await service.status(token));
   if(req.method==='POST'&&url.pathname==='/api/billing/checkout')return reply(200,await service.checkout(token));
   if(req.method==='POST'&&url.pathname==='/api/billing/cancel')return reply(200,await service.cancel(token));
   throw new BillingError('NOT_FOUND',404);
  }catch(e){reply(e instanceof BillingError?e.status:502,{error:e instanceof BillingError?e.message:'BILLING_UNAVAILABLE'});}
 };
}
export function start(env=process.env){
 const c=readConfig(env);mkdirSync(dirname(resolve(c.db)),{recursive:true,mode:0o700});const store=openStore(c.db);
 const provider=createProvider({accessToken:env.MP_ACCESS_TOKEN,testSellerId:env.MP_TEST_SELLER_ID});
 async function supabase(path,token,body){const r=await fetch(QA+path,{method:body===undefined?'GET':'POST',headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(10000)});if(!r.ok)throw new BillingError('ACCOUNT_VERIFICATION_FAILED',r.status===401?401:403);return r.json();}
 const applyEntitlement=c.enabled?createEntitlementBridge({serviceRoleKey:env.SUPABASE_SERVICE_ROLE_KEY}):null;
 const service=createBilling({provider,store,enabled:c.enabled,applyEntitlement, premiumStatus:async token=>{const d=await supabase('/rest/v1/rpc/rucaleta_v16_read',token,{});return d.premium_active;},testSellerId:env.MP_TEST_SELLER_ID,testPayerEmail:env.MP_TEST_PAYER_EMAIL,allowedUsers:(env.QA_BILLING_USER_IDS||'').split(',').map(s=>s.trim()),returnUrl:c.origin+'/?billing=return',webhookSecret:env.MP_WEBHOOK_SECRET,
 authenticate:token=>supabase('/auth/v1/user',token),quote:async token=>{const legal=await supabase('/rest/v1/rpc/get_my_legal_status',token,{});if(!legal.ready)throw new BillingError('LEGAL_ACCEPTANCE_REQUIRED',403);return supabase('/rest/v1/rpc/rucaleta_billing_quote',token,{});}});
 const server=createServer(makeHandler(service,c));server.requestTimeout=20000;server.headersTimeout=10000;server.listen(c.port,env.BILLING_BIND_HOST||'127.0.0.1');return {server,store};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){start();console.log('RUCALETA billing QA service started. No live mode is supported.');}
