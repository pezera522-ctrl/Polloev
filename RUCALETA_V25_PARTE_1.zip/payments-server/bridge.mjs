import {BillingError} from './provider.mjs';
const QA='https://xpkzzmnwzodikygfsdkp.supabase.co';
/** Only the server may call the service-role-protected QA entitlement RPC. */
export function createEntitlementBridge({serviceRoleKey,fetchImpl=fetch}){
 if(!serviceRoleKey)throw new Error('SUPABASE_SERVICE_ROLE_KEY is required for billing bridge');
 return async function apply({paymentId,subscriptionId,userId,status,amountCents,approvedAt,providerUpdatedAt,invoiceId,pricing}){
  const r=await fetchImpl(QA+'/rest/v1/rpc/rucaleta_billing_qa_verify',{
   method:'POST',headers:{apikey:serviceRoleKey,Authorization:'Bearer '+serviceRoleKey,'Content-Type':'application/json'},
   body:JSON.stringify({p_event:{payment_id:String(paymentId),subscription_id:String(subscriptionId),user_id:userId,status,amount_cents:amountCents,approved_at:approvedAt||null,provider_updated_at:providerUpdatedAt,invoice_id:String(invoiceId),pricing}}),
   signal:AbortSignal.timeout(10000),redirect:'error'
  });
  if(!r.ok)throw new BillingError('ENTITLEMENT_BRIDGE_UNAVAILABLE',503);
  return r.json();
 };
}
