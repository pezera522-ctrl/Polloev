// Server-verified administrator management and complete paginated exports.
export function mountAdminTools({rpc,openDialog,confirm,csvText,getUser,doc=document,win=window}){
 const $=id=>doc.getElementById(id),el=(t,text)=>{const n=doc.createElement(t);if(text!=null)n.textContent=String(text);return n;};
 let team=null,pending=null,busy=false;
 const say=t=>{$('admin-team-status').textContent=t;};
 async function refresh(){try{const owner=getUser()?.id;const d=await rpc('rucaleta_admin_team',{p_action:'list',p_target:null,p_operation:null});if(owner!==getUser()?.id)return;team=d;
  $('admin-team-list').replaceChildren();for(const row of d.administrators){const item=el('li');item.append(el('strong',row.email||row.user_id),el('small',`${row.user_id} · ${row.manager?'Admin principal':'Administrador'}`));if(d.can_manage&&!row.manager&&row.user_id!==owner){const b=el('button','Retirar permiso');b.type='button';b.className='v16-button';b.onclick=()=>change('revoke',row.user_id,row.email);item.append(b);}$('admin-team-list').append(item);}
  $('admin-team-form').hidden=!d.can_manage;say(d.can_manage?'Tu rol principal puede gestionar administradores por UUID.':'Tu rol permite consultar administradores. Solo el principal puede cambiar permisos.');
 }catch(e){team=null;$('admin-team-form').hidden=true;say(`No se pudo verificar el equipo. ${e.message}`);}}
 async function change(action,target,label=target){if(busy)return;busy=true;try{
  if(!team?.can_manage)throw Error('No tienes permiso para gestionar administradores.');
  if(!await confirm('Permisos administrativos',`${action==='grant'?'Dar acceso administrativo a':'Retirar acceso administrativo de'} ${label}. Se validará la cuenta y se registrará la acción en el servidor.`))return;
  if(pending&&(pending.action!==action||pending.target!==target))throw Error('Primero reintenta la operación anterior para confirmar su estado.');
  pending??={action,target,id:win.crypto.randomUUID()};
  await rpc('rucaleta_admin_team',{p_action:action,p_target:target,p_operation:pending.id});pending=null;await refresh();say('Permiso confirmado por el servidor.');
 }catch(e){say(`Cambio sin confirmar: ${e.message}`);if(/REQUIRED|PROTECTED|INVALID|BLOCKED|CONFLICT/.test(e.message))pending=null;}finally{busy=false;}}
 $('admin-team-refresh').onclick=refresh;
 $('admin-security-section').addEventListener('toggle',()=>{if($('admin-security-section').open)void refresh();});
 $('admin-team-form').onsubmit=e=>{e.preventDefault();if(e.currentTarget.reportValidity())void change('grant',e.currentTarget.elements.user_id.value.trim());};
 const kinds={audit:'Auditoría',users:'Usuarios',subscriptions:'Suscripciones',payments:'Pagos',commissions:'Comisiones'};
 async function records(){const kind=$('admin-export-kind').value,owner=getUser()?.id;let all=[],cursor=null,until=null;
  for(let pages=0;pages<200;pages++){
   const d=await rpc('rucaleta_admin_records',{p_kind:kind,p_cursor:cursor,p_until:until});if(getUser()?.id!==owner)throw Error('La sesión cambió.');
   all.push(...d.records.map(({cursor,...row})=>row));until=d.as_of;$('admin-export-status').textContent=`Consultando ${all.length} registros…`;
   if(!d.has_more)return {kind,all,until};if(!d.next_cursor||d.next_cursor===cursor)throw Error('El servidor no entregó una página válida.');cursor=d.next_cursor;
  }throw Error('El conjunto supera 100,000 registros. Solicita una exportación por periodo; no se generó un archivo parcial.');
 }
 const cell=value=>value&&typeof value==='object'?JSON.stringify(value):value??'';
 async function exportData(format){const buttons=[$('admin-export-csv'),$('admin-export-pdf')];buttons.forEach(b=>b.disabled=true);try{
  const {kind,all,until}=await records();const keys=Object.keys(all[0]||{});if(format==='csv'){
   const blob=new Blob([csvText([keys,...all.map(row=>keys.map(k=>cell(row[k])))])],{type:'text/csv;charset=utf-8'}),url=win.URL.createObjectURL(blob),a=el('a');a.href=url;a.download=`RUCALETA_${kind}_${new Date(until).toISOString().slice(0,10)}.csv`;a.click();win.setTimeout(()=>win.URL.revokeObjectURL(url),1000);
  }else{
   $('admin-print-title').textContent=`RUCALETA · ${kinds[kind]}`;$('admin-print-meta').textContent=`${all.length} registros · corte ${new Date(until).toLocaleString('es-MX')}. Los registros modificados después del corte no se incluyen.`;
   const t=el('table'),head=el('tr');keys.forEach(k=>head.append(el('th',k)));const thead=el('thead');thead.append(head);t.append(thead);const body=el('tbody');for(const row of all){const tr=el('tr');keys.forEach(k=>tr.append(el('td',cell(row[k]))));body.append(tr);}t.append(body);$('admin-print-body').replaceChildren(all.length?t:el('p','No hay registros en este conjunto.'));openDialog($('admin-print-dialog'));
  }$('admin-export-status').textContent=`${all.length} registros consultados. ${format==='csv'?'CSV preparado.':'Vista lista para imprimir o guardar como PDF.'}`;
 }catch(e){$('admin-export-status').textContent=`No se pudo exportar: ${e.message}`;}finally{buttons.forEach(b=>b.disabled=false);}}
 $('admin-export-csv').onclick=()=>exportData('csv');$('admin-export-pdf').onclick=()=>exportData('pdf');$('admin-print-close').onclick=()=>$('admin-print-dialog').close();$('admin-print-save').onclick=()=>win.print();
}
