// Presentation and navigation only. Never reads or changes monetary state.
export function mountPremiumShell(doc=document,win=window){
  const reduced=()=>win.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const nav=doc.querySelector('.rucaleta-nav'),menu=doc.getElementById('rucaleta-menu'),toggle=doc.getElementById('rucaleta-menu-toggle');
  const backdrop=doc.createElement('button');backdrop.className='v25-menu-backdrop';backdrop.type='button';backdrop.setAttribute('aria-label','Cerrar menú');backdrop.hidden=true;doc.body.append(backdrop);
  const title=doc.createElement('div');title.className='v25-menu-heading';title.textContent='Tu Rucaleta';
  const close=doc.createElement('button');close.type='button';close.textContent='×';close.className='v25-round';close.setAttribute('aria-label','Cerrar menú');title.append(close);menu.prepend(title);
  const shut=()=>{menu.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus({preventScroll:true});};close.onclick=shut;backdrop.onclick=shut;
  const updateMenu=()=>{backdrop.hidden=menu.hidden;nav.classList.remove('v25-nav-away');doc.body.classList.toggle('v25-menu-open',!menu.hidden);if(!menu.hidden){close.focus({preventScroll:true});if(!reduced())menu.animate?.([{opacity:0,transform:'translateX(24px)'},{opacity:1,transform:'translateX(0)'}],{duration:240,easing:'cubic-bezier(.2,.8,.2,1)'});}};
  new MutationObserver(updateMenu).observe(menu,{attributes:true,attributeFilter:['hidden']});
  menu.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const targets=[...menu.querySelectorAll('button:not([hidden])')].filter(x=>!x.disabled);if(e.shiftKey&&doc.activeElement===targets[0]){e.preventDefault();targets.at(-1).focus();}else if(!e.shiftKey&&doc.activeElement===targets.at(-1)){e.preventDefault();targets[0].focus();}});
  let lastY=win.scrollY||0,pending=false;
  win.addEventListener('scroll',()=>{if(pending)return;pending=true;win.requestAnimationFrame(()=>{const y=Math.max(0,win.scrollY||0),delta=y-lastY;if(menu.hidden&&Math.abs(delta)>8){nav.classList.toggle('v25-nav-away',delta>0&&y>100);lastY=y;}pending=false;});},{passive:true});
  const screens=[...doc.querySelectorAll('.pantalla')];
  const screenChanged=()=>{nav.classList.remove('v25-nav-away');const current=screens.find(x=>!x.hidden);if(!current)return;doc.body.dataset.screen=current.id;lastY=win.scrollY||0;
    if(reduced())return;
    const panels=current.querySelectorAll('.login-panel,.legal-page-header,.v22-home-action,.v22-account-preview,.sesion-contenido > .titulo-sesion');
    [...panels].slice(0,6).forEach((panel,i)=>panel.animate?.([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:300,delay:i*35,easing:'cubic-bezier(.2,.8,.2,1)',fill:'backwards'}));
  };
  const observer=new MutationObserver(screenChanged);for(const s of screens)observer.observe(s,{attributes:true,attributeFilter:['hidden']});screenChanged();
  // The user-supplied reference editor remains responsible for all amounts.
  // Only fit its existing native dialog above the on-screen keyboard.
  const viewport=()=>{doc.documentElement.style.setProperty('--v25-keyboard-height',`${win.visualViewport?.height||win.innerHeight}px`);doc.documentElement.style.setProperty('--v25-keyboard-top',`${win.visualViewport?.offsetTop||0}px`);};
  viewport();win.visualViewport?.addEventListener('resize',viewport,{passive:true});win.visualViewport?.addEventListener('scroll',viewport,{passive:true});
}
