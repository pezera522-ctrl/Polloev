// Read-only presentation. The original engine and amount-reference module own all values.
export function createSignalPresentation({feed,amounts,getUserId,doc=document,win=window}){
 const el=(tag,text,cls)=>{const n=doc.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 const reduced=()=>win.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 const header=el('div',null,'v25-carousel-header'),count=el('span'),notice=el('span',null,'v25-signal-notice'),controls=el('div');notice.setAttribute('role','status');
 const previous=el('button','←','v25-round'),next=el('button','→','v25-round');previous.type=next.type='button';previous.setAttribute('aria-label','Señal anterior');next.setAttribute('aria-label','Señal siguiente');controls.append(previous,next);header.append(count,notice,controls);feed.before(header);header.hidden=true;
 feed.setAttribute('aria-roledescription','carrusel');
 let selected=null,index=0,oldIds=[],oldSteps=new Map(),expanded=new Set();
 const cards=()=>[...feed.querySelectorAll('.player-signal-card')];
 function current(){const list=cards();if(!list.length)return 0;const left=feed.getBoundingClientRect().left;let best=0,dist=Infinity;list.forEach((n,i)=>{const d=Math.abs(n.getBoundingClientRect().left-left);if(d<dist){best=i;dist=d;}});return best;}
 function updateControls(){const list=cards();index=current();selected=list[index]?.dataset.signalId||null;previous.disabled=index===0;next.disabled=index>=list.length-1;count.textContent=`${list.length} ${list.length===1?'señal activa':'señales activas'}${list.length>1?` · ${index+1}/${list.length}`:''}`;}
 feed.addEventListener('scroll',updateControls,{passive:true});
 const move=delta=>{const list=cards(),n=list[Math.max(0,Math.min(list.length-1,current()+delta))];if(n)feed.scrollTo({left:n.offsetLeft-feed.firstElementChild.offsetLeft,behavior:reduced()?'auto':'smooth'});};previous.onclick=()=>move(-1);next.onclick=()=>move(1);
 function stored(){try{const id=getUserId();if(!id||win.sessionStorage.getItem(`rucaleta-ruc006-visit-${id}`)!=='yes')return null;return JSON.parse(win.localStorage.getItem(`rucaleta-ruc006-local-${id}`)||'null');}catch{return null;}}
 function details(card,sig,step,state){const record=stored()?.signals?.[sig.id];if(!record||!Number.isSafeInteger(record.cents))return;
  const d=el('details',null,'v25-amount-details'),title=el('summary','Referencias de los 4 intentos'),grid=el('ol',null,'v25-attempt-grid');d.append(title,grid);d.open=expanded.has(sig.id);d.ontoggle=()=>{if(d.open)expanded.add(sig.id);else expanded.delete(sig.id);};
  for(let n=1;n<=4;n++){
   const row=el('li');row.dataset.phase=n<step?'previous':n===step?'current':'future';
   // Same reference formula as the untouched module; past references use its existing snapshots.
   const cents=n<step?record.snapshots?.[n]:record.cents*2**(n-1);
   row.append(el('span',`Intento ${n}`),el('strong',Number.isSafeInteger(cents)?amounts.fmt(cents):'Sin registro'),el('small',n<step?'Anterior':n===step?'Actual':'Pendiente'));grid.append(row);
  }
  d.append(el('p','Referencias guardadas en este navegador. No representan apuestas ejecutadas.','v25-muted'));
  if(record.history?.length){const changes=el('details',null,'v25-amount-history');changes.append(el('summary','Monto actualizado · ver cambios'));const list=el('ol');for(const h of record.history){list.append(el('li',`${new Date(h.at).toLocaleString('es-MX')} · ${amounts.fmt(h.from)} → ${amounts.fmt(h.to)} · desde el intento ${h.attempt}`));}changes.append(list);d.append(changes);}card.append(d);
 }
 return {
  before(){index=current();selected=cards()[index]?.dataset.signalId||selected;},
  after(state,active){
   // The existing screen adapter moves the feed; keep its controls attached to it.
   feed.before(header);
   const list=cards(),ids=active.map(s=>s.id);header.hidden=!list.length;controls.hidden=list.length<2;
   const added=ids.filter(id=>!oldIds.includes(id));notice.textContent=oldIds.length&&added.length?`${added.length===1?'Nueva señal':`${added.length} nuevas señales`}`:'';
   const chosen=ids.indexOf(selected);index=chosen>=0?chosen:Math.min(index,Math.max(0,ids.length-1));
   list.forEach((card,i)=>{const sig=active[i];if(!sig)return;card.dataset.signalId=sig.id;card.setAttribute('aria-label',`Señal ${i+1} de ${list.length}`);
    const step=Number(card.querySelector('.ruc-money-live')?.dataset.attempt)||0;
    const money=card.querySelector('.ruc-money-live');if(money)money.setAttribute('aria-label',`Referencia actual: ${money.textContent}. Editar el monto de esta señal`);
    const label=el('span','Referencia actual','v25-reference-label');card.querySelector('.ruc-signal-amount')?.prepend(label);
    if(step)details(card,sig,step,state);
    if(step&&oldSteps.has(sig.id)&&oldSteps.get(sig.id)!==step&&!reduced())card.querySelector('.ruc-money-live')?.animate?.([{opacity:.35,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:240,easing:'ease-out'});
    oldSteps.set(sig.id,step);
   });
   const bar=doc.getElementById('ruc-amount-default');if(bar&&!bar.querySelector('.v25-reference-label'))bar.prepend(el('span','Monto para señales nuevas','v25-reference-label'));
   if(list[index])feed.scrollLeft=list[index].offsetLeft-list[0].offsetLeft;
   oldIds=ids;for(const id of oldSteps.keys())if(!ids.includes(id)){oldSteps.delete(id);expanded.delete(id);}updateControls();
  }
 };
}
