import {mountAdminTools} from './admin-tools.js';
// Administration only. No access to the signal engine or monetary-reference store.
export function csvText(rows) {
  const safe=value=>{let s=String(value??'');if(/^[\s]*[=+\-@]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};
  return '\ufeff'+rows.map(row=>row.map(safe).join(',')).join('\r\n');
}
export function missingFunction(error){return error?.code==='PGRST202'||/PGRST202|Could not find the function|function .* does not exist/i.test(error?.message||'');}
export function createAdministration({rpc,openDialog,confirm,getUser,doc=document,win=window}) {
  const $=id=>doc.getElementById(id);
  const el=(tag,text,cls)=>{const n=doc.createElement(tag);if(text!=null)n.textContent=String(text);if(cls)n.className=cls;return n;};
  const currency=v=>v==null?'—':new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN',minimumFractionDigits:0,maximumFractionDigits:2}).format(Number(v)/100);
  const time=v=>v?new Date(v).toLocaleString('es-MX',{dateStyle:'medium',timeStyle:'short'}):'—';
  const icon=name=>{const n=el('img',null,'v25-icon');n.src=`assets/icons/${name}.svg`;n.alt='';return n;};
  let data=null,offset=0,generation=0,saving=false,extended=null,editOperation=null;
  const labels={subscription:'Suscripción actualizada',block:'Acceso actualizado',code:'Código actualizado',support_create:'Ticket recibido',support_reply:'Respuesta de soporte',support_status:'Estado de ticket',payment:'Estado de pago',new_user:'Nueva cuenta',admin_owner_setup:'Administrador principal configurado',admin_grant:'Administrador agregado',admin_revoke:'Permiso administrativo revocado',billing_qa_verified:'Pago verificado en QA'};
  function status(text,error=false){$('admin-status').textContent=text;$('admin-status').setAttribute('role',error?'alert':'status');}
  function table(holder,rows,columns,empty='Todavía no hay registros.',action){
    holder.replaceChildren();if(!rows?.length){holder.append(el('p',empty,'v25-empty'));return;}
    const wrap=el('div',null,'table-scroll'),t=el('table',null,'admin-record-table'),head=el('thead'),hr=el('tr'),body=el('tbody');
    columns.forEach(c=>hr.append(el('th',c[0])));if(action)hr.append(el('th','Gestionar'));head.append(hr);
    for(const row of rows){const tr=el('tr');for(const [label,key,format] of columns){const td=el('td',format?format(row[key],row):row[key]??'—');td.dataset.label=label;tr.append(td);}if(action){const td=el('td');td.dataset.label='Gestionar';td.append(action(row));tr.append(td);}body.append(tr);}
    t.append(head,body);wrap.append(t);holder.append(wrap);
  }
  function button(text,fn){const b=el('button',text,'v16-button');b.type='button';b.onclick=fn;return b;}
  function go(id){const section=$(id);if(!section)return;if(section.tagName==='DETAILS')section.open=true;section.scrollIntoView?.({block:'start',behavior:win.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});(section.querySelector('summary,h3')||section).focus?.({preventScroll:true});}
  function metric(label,value,name,note){const n=el('article',null,'v25-metric');const badge=el('span',null,'v25-icon-medallion');badge.append(icon(name));n.append(badge,el('span',label),el('strong',value),el('small',note));return n;}
  function selectUser(u){
    for(const id of ['subscription-form','block-form'])$(id).elements.namedItem('user_id').value=u.id;
    const f=$('subscription-form');f.elements.namedItem('enabled').checked=!!u.enabled;f.elements.namedItem('expires_at').required=!!u.enabled;
    f.elements.namedItem('expires_at').value=u.expires_at?new Date(new Date(u.expires_at).getTime()-new Date(u.expires_at).getTimezoneOffset()*60000).toISOString().slice(0,16):'';
    $('block-form').elements.namedItem('blocked').checked=!!u.blocked;
    $('admin-selected-user').textContent=`Cuenta seleccionada: ${u.email||u.id}`;
    $('admin-user-source').textContent=u.subscription_source==='mercadopago_qa'?'Vigencia gestionada por Mercado Pago. Una vigencia manual no cancela renovaciones.':'Las vigencias manuales no modifican contratos de Mercado Pago.';
    $('code-form').elements.namedItem('creator_id').value=u.id;
    go('admin-user-actions');
  }
  function editCode(c){const f=$('code-form');for(const k of ['code','creator_id','discount_pct','commission_pct'])f.elements.namedItem(k).value=c[k];f.elements.namedItem('active').checked=!!c.active;f.elements.namedItem('code').readOnly=true;f.elements.namedItem('creator_id').readOnly=true;$('code-edit-status').textContent=`Editar ${c.code}`;go('code-editor');}
  function render(d){
    data=d;$('admin-content').hidden=false;const s=d.statistics||{},x=d.workspace||{};
    $('admin-role-label').textContent='Administrador';
    $('admin-statistics').replaceChildren(
      metric('Usuarios',s.users??'—','UserRound',x.active_users_30d==null?'Cuentas registradas':`${x.active_users_30d} con acceso en últimos 30 días`),
      metric('Suscripciones activas',s.premium_active??'—','Crown','Vigencia confirmada'),
      metric('Ingresos del mes',currency(x.month_cents),'ChartNoAxesColumnIncreasing',`Histórico: ${currency(x.total_cents)} MXN`),
      metric('Códigos activos',x.active_codes??'—','Tag','Descuentos de creador')
    );
    $('admin-extension-notice').hidden=!!d.workspace;
    $('admin-payments-summary').replaceChildren(metric('Aprobados hoy',x.approved_today??'—','CreditCard','Pagos verificados'),metric('Renovaciones hoy',x.renewals_today??'—','RefreshCw','Cobros posteriores al primero'),metric('Pendientes',x.pending_payments??'—','Clock','Por confirmar'));
    $('admin-processor').textContent='Mercado Pago · conexión no verificada';
    $('admin-processor').dataset.state='unknown';
    const users=$('admin-users');users.replaceChildren();const wrap=el('div');table(wrap,d.users,[['Correo','email'],['Alta','created_at',time],['Premium hasta','expires_at',time],['Acceso','blocked',v=>v?'Bloqueado':'Habilitado']],undefined,u=>button('Gestionar',()=>selectUser(u)));users.replaceWith(Object.assign(wrap,{id:'admin-users'}));
    table($('admin-codes'),d.codes,[['Código','code'],['Descuento','discount_pct',v=>`${v}%`],['Comisión','commission_pct',v=>`${v}%`],['Usos','uses'],['Comisiones','earned_cents',currency],['Estado','active',v=>v?'Activo':'Pausado']],undefined,c=>button('Editar',()=>editCode(c)));
    table($('admin-payments'),d.payments,[['Fecha','approved_at',time],['Referencia','payment_id'],['Importe MXN','amount_cents',currency],['Estado','payment_status',v=>({approved:'Aprobado',pending:'Pendiente',in_process:'En proceso',rejected:'Rechazado',cancelled:'Cancelado',refunded:'Reembolsado',charged_back:'Contracargo'})[v]||v]],x.payments_available?'No hay pagos registrados.':'El detalle de pagos no está habilitado en el servidor.');
    table($('admin-commissions'),d.commissions,[['Fecha','created_at',time],['Código','code'],['Pago MXN','net_cents',currency],['Comisión MXN','commission_cents',currency],['Reversada MXN','reversed_cents',v=>v==null?'—':currency(v)],['Referencia','provider_reference']]);
    $('admin-audit').replaceChildren();for(const row of d.audit||[]){const item=el('li',null,'v25-activity-row');const badge=el('span',null,'v25-icon-medallion');badge.append(icon(row.action?.startsWith('support')?'Headphones':'History'));const info=el('div');info.append(el('strong',labels[row.action]||row.action),el('small',row.actor?`Responsable: ${row.actor}`:'Evento del sistema'));item.append(badge,info,el('time',time(row.at)));$('admin-audit').append(item);}if(!d.audit?.length)$('admin-audit').append(el('li','Sin actividad administrativa registrada.','v25-empty'));
    offset=d.offset||0;$('admin-page').textContent=d.users?.length?`${offset+1}–${offset+d.users.length} de ${s.users??'—'}`:'Sin usuarios';$('admin-prev').disabled=offset===0;$('admin-next').disabled=(d.users?.length||0)<50;
    $('admin-last-sync').textContent=`Actualizado ${new Date().toLocaleTimeString('es-MX',{hour:'2-digit',minute:'2-digit'})}`;
    $('admin-audit-scope').textContent=`Se muestran los últimos ${d.audit?.length||0} eventos. La exportación consulta todas las páginas del conjunto elegido.`;
    $('admin-alert-count').textContent=x.open_tickets==null?'—':String(x.open_tickets);
    $('admin-security-info').textContent='Acceso autorizado por el servidor. Las acciones administrativas se registran con cuenta y fecha. La sesión no se cierra por inactividad de esta interfaz.';
    const incident=$('admin-incidents');incident.replaceChildren();const issues=(d.payments||[]).filter(p=>['rejected','refunded','charged_back'].includes(p.payment_status));for(const p of issues){const row=el('li',`Pago ${p.payment_id} · ${{rejected:'Rechazado',refunded:'Reembolsado',charged_back:'Contracargo'}[p.payment_status]} · ${time(p.updated_at)}`);incident.append(row);}if(!issues.length)incident.append(el('li',x.payments_available?'Sin incidencias en los últimos 100 pagos consultados.':'Pagos todavía sin conexión verificada.'));
    filterUsers();status('Datos consultados al servidor.');
  }
  async function refresh(action='read',payload={offset}){
    const owner=getUser()?.id,ticket=++generation;
    if(!owner)throw Error('Inicia sesión para consultar la administración.');
    status(action==='read'?'Consultando administración…':'Guardando cambio…');
    try{
      let d;
      if(action!=='read'){
        const fingerprint=JSON.stringify([owner,action,payload]);if(editOperation&&editOperation.fingerprint!==fingerprint)throw Error('Hay un cambio pendiente de comprobar. Reintenta los mismos datos antes de realizar otro cambio.');editOperation??={fingerprint,id:win.crypto.randomUUID()};
        try{await rpc('rucaleta_admin_update',{p_action:action,p_payload:payload,p_operation:editOperation.id});editOperation=null;}catch(e){if(/REQUIRED|INVALID|PROTECTED|CONFLICT|PGRST202/.test(e.message)||missingFunction(e))editOperation=null;throw e;}
      }
      if(extended!==false){try{d=await rpc('rucaleta_admin_workspace',{p_offset:payload.offset??offset});extended=true;}catch(e){if(!missingFunction(e))throw e;extended=false;}}
      if(!d)d=await rpc('rucaleta_v16_admin',{p_action:'read',p_payload:{offset:payload.offset??offset}});
      if(ticket!==generation||owner!==getUser()?.id)return;
      render(d);return d;
    }catch(e){if(ticket===generation){data=null;$('admin-content').hidden=true;status(/ADMIN_REQUIRED|permission denied/i.test(e.message)?'Esta cuenta no tiene permiso de administrador.':`No se pudo confirmar la consulta. ${e.message}`,true);}throw e;}
  }
  async function run(fn){if(saving)return;saving=true;$('admin-dialog').setAttribute('aria-busy','true');for(const b of doc.querySelectorAll('#admin-dialog form button'))b.disabled=true;try{await fn();}catch(e){status(/ADMIN_REQUIRED|permission denied/i.test(e.message)?'Esta cuenta no tiene permiso de administrador.':e.message,true);}finally{saving=false;$('admin-dialog').removeAttribute('aria-busy');for(const b of doc.querySelectorAll('#admin-dialog form button'))b.disabled=false;}}
  function filterUsers(){const q=$('admin-filter').value.trim().toLowerCase();const rows=[...doc.querySelectorAll('#admin-users tbody tr')];for(const row of rows)row.hidden=!!q&&!row.textContent.toLowerCase().includes(q);$('admin-filter-status').textContent=q?`${rows.filter(r=>!r.hidden).length} coincidencias en esta página`:'';}
  $('admin-filter').oninput=filterUsers;
  $('admin-prev').onclick=()=>run(()=>refresh('read',{offset:Math.max(0,offset-50)}));$('admin-next').onclick=()=>run(()=>refresh('read',{offset:offset+50}));
  $('v24-admin-refresh').onclick=()=>run(()=>refresh());
  $('code-new').onclick=()=>{const f=$('code-form');f.reset();for(const k of ['code','creator_id'])f.elements.namedItem(k).readOnly=false;$('code-edit-status').textContent='Crear código';go('code-editor');};
  for(const b of doc.querySelectorAll('[data-admin-section]'))b.onclick=()=>go(b.dataset.adminSection);
  $('admin-alert-button').onclick=()=>{go('admin-support-section');doc.dispatchEvent(new Event('rucaleta:admin-support'));};
  for(const [id,action] of [['subscription-form','subscription'],['block-form','block'],['code-form','code']])$(id).onsubmit=e=>{
    e.preventDefault();const f=e.currentTarget;if(!f.reportValidity())return;
    run(async()=>{const p=Object.fromEntries(new win.FormData(f));for(const c of f.querySelectorAll('input[type=checkbox]'))p[c.name]=c.checked;
      if(action==='subscription'){if(p.enabled&&(!p.expires_at||new Date(p.expires_at)<=new Date()))throw Error('Selecciona una vigencia futura.');p.expires_at=p.expires_at?new Date(p.expires_at).toISOString():new Date().toISOString();}
      const detail=action==='code'?`Código ${p.code}: descuento ${p.discount_pct}% y comisión ${p.commission_pct}%. Las cuentas ya vinculadas conservan sus condiciones anteriores.`:action==='block'?`${p.blocked?'Bloquear':'Habilitar'} el acceso de ${p.user_id}. Esto no cancela sus renovaciones.`:`Actualizar vigencia manual de ${p.user_id}. Esto no cancela ni modifica un contrato de Mercado Pago.`;
      if(!await confirm('Confirmar cambio',detail))return;await refresh(action,p);status('Cambio guardado y consultado nuevamente.');
    });
  };
  $('subscription-form').elements.namedItem('enabled').onchange=e=>{$('subscription-form').elements.namedItem('expires_at').required=e.target.checked;};
  mountAdminTools({rpc,openDialog,confirm,csvText,getUser,doc,win});
  return {refresh,async open(){openDialog($('admin-dialog'));await run(()=>refresh());},go};
}
