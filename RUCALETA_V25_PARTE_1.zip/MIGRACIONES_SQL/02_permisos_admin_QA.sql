-- Additive administrative permissions and paginated exports. LOCAL/QA only.
BEGIN;
CREATE TABLE IF NOT EXISTS rucaleta_ui.admin_managers(user_id uuid PRIMARY KEY REFERENCES auth.users(id));
CREATE TABLE IF NOT EXISTS rucaleta_ui.admin_operations(
 actor uuid NOT NULL REFERENCES auth.users(id),operation_id uuid NOT NULL,action text NOT NULL,target uuid NOT NULL,
 response jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(actor,operation_id));
ALTER TABLE rucaleta_ui.admin_managers ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_ui.admin_operations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON rucaleta_ui.admin_managers,rucaleta_ui.admin_operations FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION rucaleta_ui.admin_team(p_action text,p_target uuid,p_operation uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE u uuid:=auth.uid();manager boolean;receipt rucaleta_ui.admin_operations%ROWTYPE;result jsonb;
BEGIN
 PERFORM rucaleta_v16.require_admin();
 SELECT EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers WHERE user_id=u) INTO manager;
 IF p_action='list' THEN
  RETURN jsonb_build_object('can_manage',manager,'administrators',coalesce((SELECT jsonb_agg(t) FROM (
   SELECT a.user_id,u.email,EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers m WHERE m.user_id=a.user_id) AS manager
   FROM rucaleta_v16.admins a JOIN auth.users u ON u.id=a.user_id ORDER BY u.email,a.user_id)t),'[]'::jsonb));
 END IF;
 IF NOT manager THEN RAISE EXCEPTION 'ADMIN_MANAGER_REQUIRED' USING ERRCODE='42501';END IF;
 IF p_action IS NULL OR p_action NOT IN ('grant','revoke') OR p_target IS NULL OR p_operation IS NULL THEN RAISE EXCEPTION 'INVALID_ADMIN_OPERATION';END IF;
 PERFORM pg_advisory_xact_lock(25250001);
 SELECT * INTO receipt FROM rucaleta_ui.admin_operations WHERE actor=u AND operation_id=p_operation;
 IF FOUND THEN
  IF receipt.action<>p_action OR receipt.target<>p_target THEN RAISE EXCEPTION 'ADMIN_OPERATION_CONFLICT';END IF;
  RETURN receipt.response;
 END IF;
 IF p_target=u OR EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers WHERE user_id=p_target) THEN RAISE EXCEPTION 'PROTECTED_ADMINISTRATOR';END IF;
 IF NOT EXISTS(SELECT 1 FROM auth.users WHERE id=p_target AND email_confirmed_at IS NOT NULL AND deleted_at IS NULL) THEN RAISE EXCEPTION 'CONFIRMED_ACCOUNT_REQUIRED';END IF;
 IF p_action='grant' THEN
  IF EXISTS(SELECT 1 FROM rucaleta_v16.accounts WHERE user_id=p_target AND blocked) THEN RAISE EXCEPTION 'ACCOUNT_BLOCKED';END IF;
  INSERT INTO rucaleta_v16.admins(user_id) VALUES(p_target) ON CONFLICT DO NOTHING;
 ELSE DELETE FROM rucaleta_v16.admins WHERE user_id=p_target;
 END IF;
 result:=jsonb_build_object('user_id',p_target,'administrator',p_action='grant','operation_id',p_operation);
 INSERT INTO rucaleta_ui.admin_operations(actor,operation_id,action,target,response) VALUES(u,p_operation,p_action,p_target,result);
 INSERT INTO rucaleta_v16.audit(actor,action,payload) VALUES(u,'admin_'||p_action,result);
 RETURN result;
END $$;

CREATE OR REPLACE FUNCTION rucaleta_ui.admin_records(p_kind text,p_cursor text,p_until timestamptz)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE rows jsonb;cutoff timestamptz:=least(coalesce(p_until,now()),now());
BEGIN
 PERFORM rucaleta_v16.require_admin();
 IF length(coalesce(p_cursor,''))>160 THEN RAISE EXCEPTION 'INVALID_CURSOR';END IF;
 CASE p_kind
 WHEN 'audit' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO rows FROM (
   SELECT id::text AS cursor,id,at,actor,action,payload FROM rucaleta_v16.audit
   WHERE at<=cutoff AND id>coalesce(nullif(p_cursor,'')::bigint,0) ORDER BY id LIMIT 501)t;
 WHEN 'users' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO rows FROM (
   SELECT u.id::text AS cursor,u.id,u.email,u.created_at,coalesce(a.blocked,false) AS blocked
   FROM auth.users u LEFT JOIN rucaleta_v16.accounts a ON a.user_id=u.id
   WHERE u.created_at<=cutoff AND u.id::text>coalesce(p_cursor,'') ORDER BY u.id::text LIMIT 501)t;
 WHEN 'subscriptions' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO rows FROM (
   SELECT s.user_id::text AS cursor,s.user_id,s.expires_at,s.enabled,s.source,s.updated_at
   FROM rucaleta_v16.subscriptions s WHERE s.updated_at<=cutoff AND s.user_id::text>coalesce(p_cursor,'') ORDER BY s.user_id::text LIMIT 501)t;
 WHEN 'commissions' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO rows FROM (
   SELECT c.id::text AS cursor,c.* FROM rucaleta_v16.commissions c
   WHERE c.created_at<=cutoff AND c.id::text>coalesce(p_cursor,'') ORDER BY c.id::text LIMIT 501)t;
 WHEN 'payments' THEN
  IF to_regclass('rucaleta_v16.billing_qa_payments') IS NULL THEN RAISE EXCEPTION 'BILLING_TABLE_NOT_INSTALLED';END IF;
  EXECUTE 'SELECT coalesce(jsonb_agg(to_jsonb(t)),''[]''::jsonb) FROM (SELECT payment_id AS cursor,payment_id,subscription_id,user_id,amount_cents,payment_status,approved_at,updated_at FROM rucaleta_v16.billing_qa_payments WHERE updated_at<=$1 AND payment_id>coalesce($2,'''') ORDER BY payment_id LIMIT 501)t' INTO rows USING cutoff,p_cursor;
 ELSE RAISE EXCEPTION 'INVALID_EXPORT_KIND';
 END CASE;
 RETURN jsonb_build_object('records',(SELECT coalesce(jsonb_agg(value),'[]'::jsonb) FROM jsonb_array_elements(rows) WITH ORDINALITY x(value,n) WHERE n<=500),
  'has_more',jsonb_array_length(rows)>500,'next_cursor',rows->499->>'cursor','as_of',cutoff);
END $$;
CREATE OR REPLACE FUNCTION public.rucaleta_admin_team(p_action text DEFAULT 'list',p_target uuid DEFAULT NULL,p_operation uuid DEFAULT NULL)
RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.admin_team(p_action,p_target,p_operation) $$;
CREATE OR REPLACE FUNCTION public.rucaleta_admin_records(p_kind text,p_cursor text DEFAULT NULL,p_until timestamptz DEFAULT NULL)
RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.admin_records(p_kind,p_cursor,p_until) $$;
REVOKE ALL ON FUNCTION rucaleta_ui.admin_team(text,uuid,uuid),public.rucaleta_admin_team(text,uuid,uuid),rucaleta_ui.admin_records(text,text,timestamptz),public.rucaleta_admin_records(text,text,timestamptz) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION rucaleta_ui.admin_team(text,uuid,uuid),public.rucaleta_admin_team(text,uuid,uuid),rucaleta_ui.admin_records(text,text,timestamptz),public.rucaleta_admin_records(text,text,timestamptz) TO authenticated;

CREATE TABLE IF NOT EXISTS rucaleta_ui.admin_edits(actor uuid NOT NULL REFERENCES auth.users(id),operation_id uuid NOT NULL,action text NOT NULL,payload jsonb NOT NULL,response jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(actor,operation_id));
ALTER TABLE rucaleta_ui.admin_edits ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON rucaleta_ui.admin_edits FROM PUBLIC,anon,authenticated;
CREATE OR REPLACE FUNCTION rucaleta_ui.admin_update(p_action text,p_payload jsonb,p_operation uuid) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE receipt rucaleta_ui.admin_edits%ROWTYPE;result jsonb;u uuid:=auth.uid();
BEGIN
 PERFORM rucaleta_v16.require_admin();
 IF p_action IS NULL OR p_action NOT IN ('subscription','block','code') OR p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' OR octet_length(p_payload::text)>4000 OR p_operation IS NULL THEN RAISE EXCEPTION 'INVALID_ADMIN_OPERATION';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(u::text||p_operation::text,2526));
 SELECT * INTO receipt FROM rucaleta_ui.admin_edits WHERE actor=u AND operation_id=p_operation;
 IF FOUND THEN
  IF receipt.action<>p_action OR receipt.payload<>p_payload THEN RAISE EXCEPTION 'ADMIN_OPERATION_CONFLICT';END IF;
  RETURN receipt.response;
 END IF;
 IF p_action='block' AND coalesce((p_payload->>'blocked')::boolean,false) AND EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers WHERE user_id=(p_payload->>'user_id')::uuid) THEN RAISE EXCEPTION 'PROTECTED_ADMINISTRATOR';END IF;
 PERFORM public.rucaleta_v16_admin(p_action,p_payload);
 IF p_action='subscription' THEN UPDATE rucaleta_v16.subscriptions SET source='manual_qa' WHERE user_id=(p_payload->>'user_id')::uuid;END IF;
 result:=jsonb_build_object('confirmed',true,'operation_id',p_operation);
 INSERT INTO rucaleta_ui.admin_edits(actor,operation_id,action,payload,response) VALUES(u,p_operation,p_action,p_payload,result);
 RETURN result;
END $$;
CREATE OR REPLACE FUNCTION public.rucaleta_admin_update(p_action text,p_payload jsonb,p_operation uuid) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.admin_update(p_action,p_payload,p_operation) $$;
REVOKE ALL ON FUNCTION rucaleta_ui.admin_update(text,jsonb,uuid),public.rucaleta_admin_update(text,jsonb,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION rucaleta_ui.admin_update(text,jsonb,uuid),public.rucaleta_admin_update(text,jsonb,uuid) TO authenticated;
-- The V25 administrative API adds replay protection and protects the principal account.
-- The original implementation remains available internally for the verified wrapper.
REVOKE EXECUTE ON FUNCTION public.rucaleta_v16_admin(text,jsonb) FROM PUBLIC,anon,authenticated;
-- Harden deployments where this legacy implementation was moved to the private schema.
DO $$ BEGIN
 IF to_regprocedure('rucaleta_v16.rucaleta_v16_admin(text,jsonb)') IS NOT NULL THEN
  REVOKE EXECUTE ON FUNCTION rucaleta_v16.rucaleta_v16_admin(text,jsonb) FROM PUBLIC,anon,authenticated;
 END IF;
END $$;
COMMIT;
