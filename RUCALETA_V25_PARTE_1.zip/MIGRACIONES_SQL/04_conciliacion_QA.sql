-- Requires the original QA billing bridge and v25_admin_support_QA.sql.
-- No provider calls, charges, production configuration or signal-engine changes.
BEGIN;
GRANT USAGE ON SCHEMA rucaleta_ui TO service_role;
ALTER TABLE rucaleta_v16.billing_qa_payments ADD COLUMN IF NOT EXISTS provider_updated_at timestamptz;
ALTER TABLE rucaleta_v16.billing_qa_payments ADD COLUMN IF NOT EXISTS invoice_id text;
CREATE TABLE IF NOT EXISTS rucaleta_ui.billing_contracts(
 subscription_id text PRIMARY KEY,user_id uuid NOT NULL REFERENCES auth.users(id),amount_cents integer NOT NULL CHECK(amount_cents BETWEEN 1 AND 19900),
 creator_code text REFERENCES rucaleta_v16.creator_codes(code),discount_pct integer NOT NULL CHECK(discount_pct BETWEEN 0 AND 99),
 commission_pct integer NOT NULL CHECK(commission_pct BETWEEN 0 AND 100),created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS rucaleta_ui.billing_grace(
 subscription_id text NOT NULL REFERENCES rucaleta_ui.billing_contracts(subscription_id),paid_until timestamptz NOT NULL,
 failed_at timestamptz NOT NULL,grace_until timestamptz NOT NULL,PRIMARY KEY(subscription_id,paid_until));
CREATE TABLE IF NOT EXISTS rucaleta_ui.commission_reversals(
 commission_id uuid PRIMARY KEY REFERENCES rucaleta_v16.commissions(id),amount_cents integer NOT NULL CHECK(amount_cents>=0),
 reason text NOT NULL CHECK(reason IN ('refunded','charged_back')),created_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE rucaleta_ui.billing_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_ui.billing_grace ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_ui.commission_reversals ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON rucaleta_ui.billing_contracts,rucaleta_ui.billing_grace,rucaleta_ui.commission_reversals FROM PUBLIC,anon,authenticated,service_role;
CREATE OR REPLACE FUNCTION rucaleta_ui.billing_quote() RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE q jsonb;ref rucaleta_v16.referrals%ROWTYPE;
BEGIN
 PERFORM rucaleta_v16.require_user();q:=public.rucaleta_v16_quote(NULL);
 SELECT * INTO ref FROM rucaleta_v16.referrals WHERE user_id=auth.uid();
 RETURN q||jsonb_build_object('commission_pct',coalesce(ref.commission_pct,0),'pricing_version',25);
END $$;
CREATE OR REPLACE FUNCTION public.rucaleta_billing_quote() RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.billing_quote() $$;
REVOKE ALL ON FUNCTION public.rucaleta_billing_quote(),rucaleta_ui.billing_quote() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.rucaleta_billing_quote(),rucaleta_ui.billing_quote() TO authenticated;

CREATE OR REPLACE FUNCTION rucaleta_ui.billing_verify(p_event jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE
 u uuid:=(p_event->>'user_id')::uuid;pid text:=p_event->>'payment_id';sid text:=p_event->>'subscription_id';inv text:=p_event->>'invoice_id';
 status text:=p_event->>'status';amount integer:=(p_event->>'amount_cents')::integer;approved timestamptz:=(p_event->>'approved_at')::timestamptz;
 event_at timestamptz:=(p_event->>'provider_updated_at')::timestamptz;q jsonb:=p_event->'pricing';
 old rucaleta_v16.billing_qa_payments%ROWTYPE;contract rucaleta_ui.billing_contracts%ROWTYPE;
 v_paid_until timestamptz;v_grace_until timestamptz;v_expires timestamptz;comm rucaleta_v16.commissions%ROWTYPE;
BEGIN
 IF coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'role',current_setting('request.jwt.claim.role',true)) IS DISTINCT FROM 'service_role' THEN RAISE EXCEPTION 'BILLING_SERVICE_ROLE_REQUIRED' USING ERRCODE='42501';END IF;
 IF u IS NULL OR pid IS NULL OR pid !~ '^[0-9]{1,24}$' OR sid IS NULL OR length(sid) NOT BETWEEN 2 AND 128 OR inv IS NULL OR length(inv) NOT BETWEEN 1 AND 128
 OR status IS NULL OR status NOT IN ('approved','pending','in_process','rejected','cancelled','refunded','charged_back') OR amount IS NULL OR amount NOT BETWEEN 1 AND 19900
 OR event_at IS NULL OR event_at>now()+interval '5 minutes' OR (status='approved' AND (approved IS NULL OR approved>now()+interval '5 minutes'))
 OR q IS NULL OR (q->>'pricing_version')::integer IS DISTINCT FROM 25 OR (q->>'monthly_cents')::integer IS DISTINCT FROM amount
 OR (q->>'base_cents')::integer IS DISTINCT FROM 19900 OR (q->>'discount_pct')::integer IS NULL OR (q->>'commission_pct')::integer IS NULL
 OR amount<>19900*(100-(q->>'discount_pct')::integer)/100 THEN RAISE EXCEPTION 'BILLING_INVALID_VERIFIED_PAYMENT';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(u::text,123456));
 INSERT INTO rucaleta_ui.billing_contracts(subscription_id,user_id,amount_cents,creator_code,discount_pct,commission_pct)
 VALUES(sid,u,amount,q->>'applied_code',(q->>'discount_pct')::integer,(q->>'commission_pct')::integer) ON CONFLICT DO NOTHING;
 SELECT * INTO contract FROM rucaleta_ui.billing_contracts WHERE subscription_id=sid FOR UPDATE;
 IF contract.user_id<>u OR contract.amount_cents<>amount OR contract.creator_code IS DISTINCT FROM q->>'applied_code' OR contract.discount_pct<>(q->>'discount_pct')::integer OR contract.commission_pct<>(q->>'commission_pct')::integer THEN RAISE EXCEPTION 'BILLING_CONTRACT_CONFLICT';END IF;
 SELECT * INTO old FROM rucaleta_v16.billing_qa_payments WHERE payment_id=pid FOR UPDATE;
 IF FOUND THEN
  IF old.user_id<>u OR old.subscription_id<>sid OR old.amount_cents<>amount OR (old.invoice_id IS NOT NULL AND old.invoice_id<>inv) OR (old.approved_at IS NOT NULL AND approved IS NOT NULL AND old.approved_at<>approved) THEN RAISE EXCEPTION 'BILLING_IMMUTABLE_PAYMENT_CONFLICT';END IF;
  IF old.provider_updated_at>event_at OR old.payment_status IN ('refunded','charged_back','cancelled') OR (old.payment_status='approved' AND status NOT IN ('approved','refunded','charged_back')) THEN status:=old.payment_status;END IF;
 END IF;
 INSERT INTO rucaleta_v16.billing_qa_payments(payment_id,subscription_id,user_id,amount_cents,payment_status,approved_at,invoice_id,provider_updated_at)
 VALUES(pid,sid,u,amount,status,approved,inv,event_at)
 ON CONFLICT(payment_id) DO UPDATE SET payment_status=excluded.payment_status,approved_at=coalesce(rucaleta_v16.billing_qa_payments.approved_at,excluded.approved_at),invoice_id=excluded.invoice_id,provider_updated_at=greatest(rucaleta_v16.billing_qa_payments.provider_updated_at,excluded.provider_updated_at),updated_at=now();
 IF status='approved' AND contract.creator_code IS NOT NULL THEN
  INSERT INTO rucaleta_v16.commissions(user_id,code,provider_reference,net_cents,commission_cents)
  VALUES(u,contract.creator_code,'mp-qa:'||pid,amount,amount*contract.commission_pct/100) ON CONFLICT(provider_reference) DO NOTHING;
  SELECT * INTO comm FROM rucaleta_v16.commissions WHERE provider_reference='mp-qa:'||pid;
  IF comm.user_id<>u OR comm.net_cents<>amount OR comm.code<>contract.creator_code OR comm.commission_cents<>amount*contract.commission_pct/100 THEN RAISE EXCEPTION 'BILLING_COMMISSION_CONFLICT';END IF;
 ELSIF status IN ('refunded','charged_back') THEN
  INSERT INTO rucaleta_ui.commission_reversals(commission_id,amount_cents,reason)
  SELECT id,commission_cents,status FROM rucaleta_v16.commissions WHERE provider_reference='mp-qa:'||pid ON CONFLICT DO NOTHING;
 END IF;
 SELECT max(approved_at+interval '1 month') INTO v_paid_until FROM rucaleta_v16.billing_qa_payments WHERE subscription_id=sid AND user_id=u AND payment_status='approved';
 -- One fixed three-day courtesy window per paid period, only for a verified failed renewal.
 -- Repeated notifications/retries cannot move the end of this window forward.
 IF status='rejected' AND v_paid_until IS NOT NULL AND EXISTS(SELECT 1 FROM rucaleta_v16.billing_qa_payments WHERE subscription_id=sid AND payment_status='approved' AND invoice_id IS DISTINCT FROM inv AND approved_at<event_at) THEN
  INSERT INTO rucaleta_ui.billing_grace(subscription_id,paid_until,failed_at,grace_until) VALUES(sid,v_paid_until,event_at,event_at+interval '3 days')
  ON CONFLICT(subscription_id,paid_until) DO UPDATE SET failed_at=least(rucaleta_ui.billing_grace.failed_at,excluded.failed_at),grace_until=least(rucaleta_ui.billing_grace.grace_until,excluded.grace_until);
 END IF;
 SELECT g.grace_until INTO v_grace_until FROM rucaleta_ui.billing_grace g WHERE g.subscription_id=sid AND g.paid_until=v_paid_until;
 -- All paid subscriptions for the account remain independent; a refund cannot erase another valid period.
 SELECT max(p.approved_at+interval '1 month') INTO v_expires FROM rucaleta_v16.billing_qa_payments p WHERE p.user_id=u AND p.payment_status='approved';
 SELECT greatest(v_expires,max(g.grace_until)) INTO v_expires FROM rucaleta_ui.billing_grace g JOIN rucaleta_ui.billing_contracts c USING(subscription_id)
 WHERE c.user_id=u AND g.paid_until=(SELECT max(p.approved_at+interval '1 month') FROM rucaleta_v16.billing_qa_payments p WHERE p.subscription_id=c.subscription_id AND p.payment_status='approved');
 IF NOT EXISTS(SELECT 1 FROM rucaleta_v16.subscriptions WHERE user_id=u AND source='manual_qa') THEN
  IF v_expires IS NOT NULL THEN
   INSERT INTO rucaleta_v16.subscriptions(user_id,expires_at,enabled,source) VALUES(u,v_expires,true,'mercadopago_qa')
   ON CONFLICT(user_id) DO UPDATE SET expires_at=excluded.expires_at,enabled=true,updated_at=now() WHERE rucaleta_v16.subscriptions.source='mercadopago_qa';
  ELSE UPDATE rucaleta_v16.subscriptions SET enabled=false,updated_at=now() WHERE user_id=u AND source='mercadopago_qa';END IF;
 END IF;
 IF old.payment_status IS DISTINCT FROM status THEN INSERT INTO rucaleta_v16.audit(actor,action,payload) VALUES(u,'payment_'||status,jsonb_build_object('payment_id',pid,'environment','QA','source','verified_provider'));END IF;
 RETURN jsonb_build_object('premium_active',rucaleta_v16.is_premium(u),'premium_expires_at',v_expires,'grace_until',v_grace_until,'environment','QA');
END $$;
CREATE OR REPLACE FUNCTION public.rucaleta_billing_qa_verify(p_event jsonb) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.billing_verify(p_event) $$;
REVOKE ALL ON FUNCTION rucaleta_ui.billing_verify(jsonb),public.rucaleta_billing_qa_verify(jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION rucaleta_ui.billing_verify(jsonb),public.rucaleta_billing_qa_verify(jsonb) TO service_role;
-- Retain the old function for compatibility but disable the incomplete write path.
REVOKE ALL ON FUNCTION public.rucaleta_billing_qa_apply_payment(text,text,uuid,text,integer,timestamptz) FROM service_role;
COMMIT;
