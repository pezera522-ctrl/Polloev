-- Verified Auth account, RUCALETA-QA only: xpkzzmnwzodikygfsdkp.
-- Run as database owner AFTER the V25 additive scripts. Never from the browser.
-- Idempotent: no second audit event and no guessed account by browser email.
BEGIN;
DO $$
DECLARE target constant uuid:='8053caa9-fe1b-41b0-9b1c-cbc87032abd9';was_manager boolean;
BEGIN
 PERFORM pg_advisory_xact_lock(25250001);
 PERFORM 1 FROM auth.users WHERE id=target AND lower(email)='leonelmtz522@gmail.com'
 AND email_confirmed_at IS NOT NULL AND deleted_at IS NULL FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'EXACT_CONFIRMED_ADMIN_ACCOUNT_NOT_FOUND';END IF;
 IF EXISTS(SELECT 1 FROM rucaleta_v16.accounts WHERE user_id=target AND blocked) THEN RAISE EXCEPTION 'ADMIN_ACCOUNT_BLOCKED_REVIEW_REQUIRED';END IF;
 SELECT EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers WHERE user_id=target) INTO was_manager;
 INSERT INTO rucaleta_v16.admins(user_id) VALUES(target) ON CONFLICT DO NOTHING;
 INSERT INTO rucaleta_ui.admin_managers(user_id) VALUES(target) ON CONFLICT DO NOTHING;
 IF NOT was_manager THEN
  INSERT INTO rucaleta_v16.audit(actor,action,payload) VALUES(target,'admin_owner_setup',jsonb_build_object('origin','explicit_owner_authorization','environment','RUCALETA-QA','user_id',target));
 END IF;
END $$;
SELECT a.user_id,u.email,EXISTS(SELECT 1 FROM rucaleta_ui.admin_managers m WHERE m.user_id=a.user_id) AS principal
FROM rucaleta_v16.admins a JOIN auth.users u ON u.id=a.user_id WHERE a.user_id='8053caa9-fe1b-41b0-9b1c-cbc87032abd9';
COMMIT;
