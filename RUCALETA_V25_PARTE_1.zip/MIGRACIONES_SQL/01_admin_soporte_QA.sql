-- V25 additive UI services. Apply only to a reviewed LOCAL/QA database.
-- Does not change signal/attempt tables, references, authentication roles or billing.
-- No account becomes an administrator by running this script.
BEGIN;
DO $$ BEGIN
 IF to_regprocedure('rucaleta_v16.require_admin()') IS NULL OR to_regprocedure('public.rucaleta_v16_admin(text,jsonb)') IS NULL THEN
  RAISE EXCEPTION 'RUC_V16_ADMIN_PREREQUISITE_MISSING';
 END IF;
END $$;
CREATE SCHEMA IF NOT EXISTS rucaleta_ui;
REVOKE ALL ON SCHEMA rucaleta_ui FROM PUBLIC,anon,authenticated;
GRANT USAGE ON SCHEMA rucaleta_ui TO authenticated;
CREATE TABLE IF NOT EXISTS rucaleta_ui.support_tickets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES auth.users(id),
 subject text NOT NULL CHECK(char_length(subject) BETWEEN 3 AND 120),
 status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
 version bigint NOT NULL DEFAULT 1 CHECK(version>0),
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS support_ticket_user_idx ON rucaleta_ui.support_tickets(user_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS support_ticket_status_idx ON rucaleta_ui.support_tickets(status,updated_at DESC);
CREATE TABLE IF NOT EXISTS rucaleta_ui.support_messages (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),ticket_id uuid NOT NULL REFERENCES rucaleta_ui.support_tickets(id),
 author uuid NOT NULL REFERENCES auth.users(id),from_admin boolean NOT NULL,
 body text NOT NULL CHECK(char_length(body) BETWEEN 1 AND 4000),created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX IF NOT EXISTS support_message_ticket_idx ON rucaleta_ui.support_messages(ticket_id,created_at,id);
CREATE TABLE IF NOT EXISTS rucaleta_ui.support_operations (
 user_id uuid NOT NULL REFERENCES auth.users(id),operation_id uuid NOT NULL,action text NOT NULL,
 payload jsonb NOT NULL,response jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(user_id,operation_id)
);
ALTER TABLE rucaleta_ui.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_ui.support_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_ui.support_operations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA rucaleta_ui FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION rucaleta_ui.support(p_action text,p_payload jsonb,p_operation uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE u uuid:=auth.uid();is_admin boolean;ticket rucaleta_ui.support_tickets%ROWTYPE;
 old rucaleta_ui.support_operations%ROWTYPE;result jsonb;subject text;message text;
BEGIN
 PERFORM rucaleta_v16.require_user();
 IF p_action IS NULL OR p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' OR octet_length(p_payload::text)>20000 THEN RAISE EXCEPTION 'INVALID_PAYLOAD';END IF;
 SELECT EXISTS(SELECT 1 FROM rucaleta_v16.admins WHERE user_id=u) INTO is_admin;
 IF p_action IN ('list','admin_list') THEN
  IF p_action='admin_list' THEN PERFORM rucaleta_v16.require_admin();END IF;
  RETURN jsonb_build_object('tickets',coalesce((SELECT jsonb_agg(t) FROM (
   SELECT t.id,t.user_id,t.subject,t.status,t.version,t.created_at,t.updated_at FROM rucaleta_ui.support_tickets t
   WHERE t.user_id=u OR p_action='admin_list' ORDER BY t.updated_at DESC,t.id LIMIT 100)t),'[]'::jsonb),'limit',100);
 END IF;
 IF p_action='thread' THEN
  SELECT * INTO ticket FROM rucaleta_ui.support_tickets WHERE id=(p_payload->>'ticket_id')::uuid;
  IF NOT FOUND OR (ticket.user_id<>u AND NOT is_admin) THEN RAISE EXCEPTION 'TICKET_NOT_ACCESSIBLE' USING ERRCODE='42501';END IF;
  RETURN jsonb_build_object('ticket',to_jsonb(ticket),'messages',coalesce((SELECT jsonb_agg(m ORDER BY m.created_at,m.id) FROM (
   SELECT id,author,from_admin,body,created_at FROM rucaleta_ui.support_messages WHERE ticket_id=ticket.id ORDER BY created_at DESC,id DESC LIMIT 200)m),'[]'::jsonb),'limit',200);
 END IF;
 IF p_action NOT IN ('create','reply','close') OR p_operation IS NULL THEN RAISE EXCEPTION 'SUPPORT_OPERATION_REQUIRED';END IF;
 -- Same user/operation is serialized before checking its durable receipt.
 PERFORM pg_advisory_xact_lock(hashtextextended(u::text||p_operation::text,2525));
 SELECT * INTO old FROM rucaleta_ui.support_operations WHERE user_id=u AND operation_id=p_operation;
 IF FOUND THEN
  IF old.action<>p_action OR old.payload<>p_payload THEN RAISE EXCEPTION 'SUPPORT_IDEMPOTENCY_CONFLICT';END IF;
  RETURN old.response;
 END IF;
 IF p_action='create' THEN
  subject:=trim(p_payload->>'subject');message:=trim(p_payload->>'message');
  IF subject IS NULL OR char_length(subject) NOT BETWEEN 3 AND 120 OR message IS NULL OR char_length(message) NOT BETWEEN 5 AND 4000 THEN RAISE EXCEPTION 'INVALID_SUPPORT_TEXT';END IF;
  INSERT INTO rucaleta_ui.support_tickets(user_id,subject) VALUES(u,subject) RETURNING * INTO ticket;
 ELSE
  SELECT * INTO ticket FROM rucaleta_ui.support_tickets WHERE id=(p_payload->>'ticket_id')::uuid FOR UPDATE;
  IF NOT FOUND OR (ticket.user_id<>u AND NOT is_admin) THEN RAISE EXCEPTION 'TICKET_NOT_ACCESSIBLE' USING ERRCODE='42501';END IF;
  IF (p_payload->>'version')::bigint IS DISTINCT FROM ticket.version THEN RAISE EXCEPTION 'SUPPORT_CONFLICT';END IF;
  IF ticket.status='closed' THEN RAISE EXCEPTION 'TICKET_CLOSED';END IF;
  IF p_action='close' THEN
   PERFORM rucaleta_v16.require_admin();
   UPDATE rucaleta_ui.support_tickets SET status='closed',version=version+1,updated_at=clock_timestamp() WHERE id=ticket.id RETURNING * INTO ticket;
  ELSE
   message:=trim(p_payload->>'message');
   IF message IS NULL OR char_length(message) NOT BETWEEN 1 AND 4000 THEN RAISE EXCEPTION 'INVALID_SUPPORT_TEXT';END IF;
   UPDATE rucaleta_ui.support_tickets SET version=version+1,updated_at=clock_timestamp() WHERE id=ticket.id RETURNING * INTO ticket;
  END IF;
 END IF;
 IF p_action IN ('create','reply') THEN
  INSERT INTO rucaleta_ui.support_messages(ticket_id,author,from_admin,body) VALUES(ticket.id,u,is_admin,message);
 END IF;
 INSERT INTO rucaleta_v16.audit(actor,action,payload) VALUES(u,'support_'||p_action,jsonb_build_object('ticket_id',ticket.id,'version',ticket.version));
 result:=jsonb_build_object('ticket_id',ticket.id,'version',ticket.version,'status',ticket.status,'operation_id',p_operation);
 INSERT INTO rucaleta_ui.support_operations(user_id,operation_id,action,payload,response) VALUES(u,p_operation,p_action,p_payload,result);
 RETURN result;
END $$;

CREATE OR REPLACE FUNCTION rucaleta_ui.admin_workspace(p_offset integer DEFAULT 0)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE base jsonb;payments jsonb:='[]';payment_stats jsonb;codes jsonb;users jsonb;
 month_start timestamptz:=date_trunc('month',now() AT TIME ZONE 'America/Mexico_City') AT TIME ZONE 'America/Mexico_City';
 day_start timestamptz:=date_trunc('day',now() AT TIME ZONE 'America/Mexico_City') AT TIME ZONE 'America/Mexico_City';
BEGIN
 PERFORM rucaleta_v16.require_admin();
 base:=public.rucaleta_v16_admin('read',jsonb_build_object('offset',greatest(0,coalesce(p_offset,0))));
 -- Do not substitute commissions for total revenue. Missing billing data stays null.
 payment_stats:=jsonb_build_object('payments_available',false,'total_cents',null,'month_cents',null,'approved_today',null,'renewals_today',null,'pending_payments',null);
 IF to_regclass('rucaleta_v16.billing_qa_payments') IS NOT NULL THEN
  EXECUTE $q$ SELECT jsonb_build_object('payments_available',true,
   'total_cents',coalesce(sum(amount_cents) FILTER(WHERE payment_status='approved'),0),
   'month_cents',coalesce(sum(amount_cents) FILTER(WHERE payment_status='approved' AND approved_at >= $1),0),
   'approved_today',count(*) FILTER(WHERE payment_status='approved' AND approved_at >= $2),
   'pending_payments',count(*) FILTER(WHERE payment_status IN ('pending','in_process')),
   'renewals_today',(SELECT count(*) FROM (SELECT payment_status,approved_at,row_number() OVER(PARTITION BY subscription_id ORDER BY approved_at,payment_id) AS ordinal FROM rucaleta_v16.billing_qa_payments WHERE approved_at IS NOT NULL)x WHERE ordinal>1 AND payment_status='approved' AND approved_at >= $2))
   FROM rucaleta_v16.billing_qa_payments $q$ INTO payment_stats USING month_start,day_start;
  EXECUTE 'SELECT coalesce(jsonb_agg(p),''[]''::jsonb) FROM (SELECT payment_id,subscription_id,user_id,amount_cents,payment_status,approved_at,updated_at FROM rucaleta_v16.billing_qa_payments ORDER BY updated_at DESC,payment_id LIMIT 100)p' INTO payments;
 END IF;
 SELECT coalesce(jsonb_agg(c),'[]'::jsonb) INTO codes FROM (
  SELECT c.*,(SELECT count(*) FROM rucaleta_v16.commissions m WHERE m.code=c.code) AS uses,
  (SELECT coalesce(sum(commission_cents),0) FROM rucaleta_v16.commissions m WHERE m.code=c.code) AS earned_cents
  FROM rucaleta_v16.creator_codes c ORDER BY c.code LIMIT 100)c;
 IF to_regclass('rucaleta_ui.commission_reversals') IS NOT NULL THEN
  SELECT coalesce(jsonb_agg(c.value||jsonb_build_object('earned_cents',(c.value->>'earned_cents')::bigint-coalesce((SELECT sum(r.amount_cents) FROM rucaleta_ui.commission_reversals r JOIN rucaleta_v16.commissions m ON m.id=r.commission_id WHERE m.code=c.value->>'code'),0))),'[]'::jsonb) INTO codes FROM jsonb_array_elements(codes)c;
  base:=base||jsonb_build_object('commissions',(SELECT coalesce(jsonb_agg(c.value||jsonb_build_object('reversed_cents',coalesce((SELECT amount_cents FROM rucaleta_ui.commission_reversals WHERE commission_id=(c.value->>'id')::uuid),0))),'[]'::jsonb) FROM jsonb_array_elements(base->'commissions')c));
 END IF;
 SELECT coalesce(jsonb_agg(value||jsonb_build_object('subscription_source',(SELECT source FROM rucaleta_v16.subscriptions WHERE user_id=(value->>'id')::uuid))),'[]'::jsonb)
 INTO users FROM jsonb_array_elements(base->'users');
 RETURN base||jsonb_build_object('users',users,'codes',codes,'payments',payments,'workspace',payment_stats||jsonb_build_object(
  'active_users_30d',(SELECT count(*) FROM auth.users WHERE last_sign_in_at >= now()-interval '30 days' AND deleted_at IS NULL),
  'active_codes',(SELECT count(*) FROM rucaleta_v16.creator_codes WHERE active),
  'open_tickets',(SELECT count(*) FROM rucaleta_ui.support_tickets WHERE status='open'),
  'timezone','America/Mexico_City','environment','QA'));
END $$;
CREATE OR REPLACE FUNCTION public.rucaleta_support(p_action text,p_payload jsonb DEFAULT '{}',p_operation uuid DEFAULT NULL)
RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.support(p_action,p_payload,p_operation) $$;
CREATE OR REPLACE FUNCTION public.rucaleta_admin_workspace(p_offset integer DEFAULT 0)
RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_ui.admin_workspace(p_offset) $$;
REVOKE ALL ON FUNCTION rucaleta_ui.support(text,jsonb,uuid),rucaleta_ui.admin_workspace(integer),public.rucaleta_support(text,jsonb,uuid),public.rucaleta_admin_workspace(integer) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION rucaleta_ui.support(text,jsonb,uuid),rucaleta_ui.admin_workspace(integer),public.rucaleta_support(text,jsonb,uuid),public.rucaleta_admin_workspace(integer) TO authenticated;
COMMIT;
