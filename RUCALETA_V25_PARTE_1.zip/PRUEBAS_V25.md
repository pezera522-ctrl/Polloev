# Pruebas ejecutadas

Comando final: `npm test`. Resultado: **34 pruebas aprobadas, 0 fallidas**, más cinco comprobaciones finales de adaptador Auth, concurrencia Auth, geometría de ruleta, servicio de pagos y validación estática. Registro íntegro: `docs/evidencias/PRUEBAS_FINALES.log`.

- PostgreSQL local desechable (PGlite): 49 comprobaciones dentro de una prueba de integración. Permisos concedidos/denegados, aislamiento de tickets, versiones, idempotencia, principal protegido, exportación paginada, pagos, descuentos, comisiones, reversas y cortesía.
- Motor SQL real de QA: ejecutado en PostgreSQL local antes/después de las migraciones V25. Resultados idénticos para tres señales simultáneas, cuatro intentos, acierto, 0/00, ampliación y cierre a 30 giros. También se reprodujo el defecto heredado del historial inicial.
- Montos originales: validación, formato, edición independiente, predeterminado para señales futuras, instantáneas previas, persistencia y reconfirmación. La nueva presentación no escribe valores.
- DOM con servicios de prueba explícitos: bienvenida, login, términos, restauración, fallo de aceptación, administrador, menú, soporte y reintento tras respuesta perdida. Saltar cancela la espera del portal.
- Auth y Mercado Pago HTTP: dobles de prueba explícitos; **sin cobros ni contacto con Mercado Pago**. Se probaron firma HMAC, identidad, importes, origen, duplicados, cancelación propia y restricciones QA.
- QA real, consultas RPC dentro de transacción revertida: principal autorizado, 3 usuarios, 1 con inicio de sesión en 30 días, 0 pagos, 0 códigos; acceso directo administrativo antiguo denegado. Evidencia: `docs/QA_VERIFICACION_FINAL.json`. No se probaron credenciales de acceso del propietario en navegador.
- Navegador Chromium: bienvenida real → portal → Saltar → login sin sesión. Administración y señales revisadas con datos locales explícitamente rotulados. Administración sin desbordamiento horizontal en 320/375/390/430/768/1120 px; vista de exportación PDF abierta. Capturas en `docs/evidencias/capturas/`.

Las capturas administrativas contienen datos de prueba y acreditan presentación, no métricas reales. La portada V24 de comparación usa su HTML/CSS original sin ejecutar autenticación. La captura de ruleta pausa la animación para inspeccionar materiales. No se midieron FPS ni temperatura y no se probó Safari físico, impresión nativa a PDF, checkout externo o registro con correo real.

Se corrigieron los errores descubiertos durante desarrollo antes de esta ejecución final. Los scripts históricos `test:v24`, `test:ux`, `test:mobile` y las capturas V21–V24 son antecedentes; el comando vigente es `npm test`.
