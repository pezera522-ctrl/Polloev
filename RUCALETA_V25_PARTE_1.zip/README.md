# RUCALETA V25 · entrega QA

Continuación de la copia recuperada, con motor y montos protegidos. Fecha de entrega: 21 de octubre de 2026, México.

1. Lee `INSTALACION_V25.md` para ejecutar la aplicación.
2. Lee `PENDIENTES_EXTERNOS.md` antes de habilitar pagos o considerar producción.
3. Cambios: `CHANGELOG_V25.md`. Pruebas: `PRUEBAS_V25.md`.
4. Migraciones compatibles: `MIGRACIONES_SQL/`. Ya aplicadas en RUCALETA-QA.

Los documentos V16–V24 se conservan como antecedentes y no sustituyen estas instrucciones. El proyecto no ha sido desplegado ni subido a GitHub durante esta entrega. No contiene credenciales privadas.

Inicio local: Node 24.19+ → `npm ci` → `npm run dev` → http://localhost:4173.

El archivo FINAL contiene el proyecto completo. Las dos PARTES son una alternativa: extrae ambas dentro de la misma carpeta. Ninguna parte funciona por sí sola.
