import {test} from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {createAmountReferences} from '../js/amount-reference.js';
import {createSignalPresentation} from '../js/signal-presentation.js';

test('original amount module: independent references, past snapshots, defaults and visits',()=>{
 const dom=new JSDOM('<main></main><div id="primary-signal-feed"></div>',{url:'https://amounts.invalid/'}),w=dom.window;
 for(const key of ['window','document','localStorage','sessionStorage','Event'])globalThis[key]=key==='window'?w:w[key];
 w.matchMedia=()=>({matches:true});w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};
 try{
  const amounts=createAmountReferences({getUserId:()=> 'local-amount-test'}),host=w.document.querySelector('main'),feed=w.document.querySelector('#primary-signal-feed');
  const key='rucaleta-ruc006-local-local-amount-test',visit='rucaleta-ruc006-visit-local-amount-test';
  const saved=()=>JSON.parse(w.localStorage.getItem(key));
  const submit=value=>{const input=w.document.querySelector('#ruc-amount-input');input.value=value;input.dispatchEvent(new w.Event('input'));w.document.querySelector('.ruc-amount-form').dispatchEvent(new w.Event('submit',{cancelable:true}));};
  for(const invalid of ['0','-5','abc','1.234','1e3','1000000000'])assert.equal(amounts.parse(invalid),null);
  assert.equal(amounts.parse('2.50'),250);assert.equal(amounts.fmt(500),'$5 MXN');assert.equal(amounts.fmt(125050),'$1,250.50 MXN');
  amounts.mountDefault(host);host.querySelector('.ruc-amount-confirm').click();submit('5');assert.equal(saved().defaultCents,500);
  const card=(id,step)=>{const n=w.document.createElement('article');n.className='player-signal-card';amounts.mountSignal(n,{id},step);return n;};
  const a=card('A',1),b=card('B',1);assert.equal(saved().signals.A.cents,500);assert.equal(saved().signals.B.cents,500);
  a.querySelector('.ruc-money-live').click();submit('2.50');assert.equal(saved().signals.A.cents,250);assert.equal(saved().signals.B.cents,500);
  amounts.mountDefault(host);host.querySelector('.ruc-money-control').click();submit('10');card('C',1);assert.equal(saved().signals.C.cents,1000);assert.equal(saved().signals.A.cents,250);assert.equal(saved().signals.B.cents,500);
  const progressed=card('A',3);progressed.querySelector('.ruc-money-live').click();submit('5');
  const record=saved().signals.A;assert.deepEqual(record.snapshots,{'1':250,'2':500});assert.equal(record.cents,500);assert.equal(record.history.at(-1).attempt,3);
  const presentation=createSignalPresentation({feed,amounts,getUserId:()=> 'local-amount-test',doc:w.document,win:w});
  feed.replaceChildren(card('A',3),card('B',1));const before=w.localStorage.getItem(key);presentation.after({},[{id:'A'},{id:'B'}]);assert.equal(w.localStorage.getItem(key),before,'presentation writes no amount data');
  assert.deepEqual([...feed.firstElementChild.querySelectorAll('.v25-attempt-grid strong')].map(n=>n.textContent),['$2.50 MXN','$5 MXN','$20 MXN','$40 MXN']);
  assert.match(feed.firstElementChild.textContent,/Monto actualizado/);
  amounts.mountDefault(host);assert.equal(host.querySelector('.ruc-amount-confirm'),null,'ordinary remount preserves confirmation');
  w.sessionStorage.removeItem(visit);amounts.mountDefault(host);assert.ok(host.querySelector('.ruc-amount-confirm'),'new storage session requires confirmation');assert.equal(w.localStorage.getItem(key),before,'new visit does not overwrite individual references');
 }finally{dom.window.close();for(const key of ['window','document','localStorage','sessionStorage','Event'])delete globalThis[key];}
});
