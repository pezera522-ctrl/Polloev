import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';

const read=p=>fs.readFile(new URL('../'+p,import.meta.url),'utf8');
test('actual QA SQL engine: same reproducible behavior before and after V25 integration',async()=>{
 const db=new PGlite();
 try{
  await db.exec(`create role anon;create role authenticated;create role service_role;create schema auth;create schema extensions;
  create table auth.users(id uuid primary key,email text,created_at timestamptz default now(),email_confirmed_at timestamptz default now(),deleted_at timestamptz,last_sign_in_at timestamptz);
  create function auth.uid() returns uuid language sql as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
  grant usage on schema auth to authenticated;
  -- PGlite has PostgreSQL's built-in SHA-256; identical digest, no simulated engine.
  create function extensions.digest(bytea,text) returns bytea language sql immutable as $$select case when $2='sha256' then sha256($1) else null end$$;
  create table public.legal_documents(id int primary key,status text,effective_at timestamptz,content_sha256 text);
  create table public.legal_consents(user_id uuid,legal_document_id int,document_sha256 text);
  insert into public.legal_documents select n,'active',now()-interval '1 day','hash-'||n from generate_series(1,3)n;`);
  let base=await read('sql/reference_v16/qa_additive_v16.sql');
  base=base.replace('CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;','').replace(/^INSERT INTO rucaleta_v16\.(entitlements|streams|events|signals|attempts) SELECT .*;$/gm,'');
  await db.exec(base);await db.exec(await read('sql/reference_v16/qa_api_hardening.sql'));
  // Definitions retrieved read-only from QA; their MD5 hashes match the pre-change capture.
  const verified=JSON.parse(await read('tests/fixtures/qa-engine-verified.json'));
  for(const f of verified){assert.equal(crypto.createHash('md5').update(f.definition).digest('hex'),f.definition_hash);await db.exec(f.definition);}
  const hashes=async()=> (await db.query("select proname,md5(pg_get_functiondef(p.oid)) hash from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='rucaleta_v16' and proname=any($1) order by proname",[verified.map(f=>f.proname)])).rows;
  const beforeHash=await hashes();
  async function run(id){
   await db.exec('reset role');await db.query('insert into auth.users(id,email)values($1,$2)',[id,id+'@example.invalid']);
   await db.query('insert into public.legal_consents select $1,id,content_sha256 from public.legal_documents',[id]);
   await db.query("insert into rucaleta_v16.subscriptions values($1,now()+interval '1 month',true,'manual_qa',now())",[id]);
   await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec('set role authenticated');
   let revision=0;const events=[];
   const apply=async(action,payload={})=>{const r=(await db.query('select public.rucaleta_v16_apply($1,$2,$3,$4) d',[crypto.randomUUID(),revision,action,JSON.stringify(payload)])).rows[0].d;revision=r.revision;return r;};
   const state=async()=> (await db.query('select public.rucaleta_v16_read() d')).rows[0].d;
   await apply('seed_history',{values:['0','2','4','6','8']});let s=await state();assert.equal(s.stream.green_end,31);assert.equal(s.signals.length,0);
   const created=await apply('spin',{value:'10'});assert.equal(created.created_signals.length,3);s=await state();
   assert.deepEqual(s.signals.map(x=>x.target).sort(),['high','odd','red']);events.push({simultaneous:s.signals.map(x=>x.target).sort()});
   const red=s.signals.find(x=>x.target==='red'),odd=s.signals.find(x=>x.target==='odd');
   // Existing engine requires a confirmation for each attempt; no synthetic advancement.
   await apply('spin',{value:'2'});assert.equal((await state()).attempts.length,0);
   for(let n=1;n<=4;n++){await apply('confirm',{signal_id:red.id,stake:4*2**(n-1)});await apply('spin',{value:'2'});}
   s=await state();assert.equal(s.signals.find(x=>x.id===red.id).status,'lost');assert.deepEqual(s.attempts.filter(x=>x.signal_id===red.id).map(x=>x.number),[1,2,3,4]);
   await assert.rejects(()=>apply('confirm',{signal_id:red.id,stake:64}),/INVALID_CONFIRM_PAYLOAD/);
   await apply('confirm',{signal_id:odd.id,stake:5});await apply('spin',{value:'1'});s=await state();assert.equal(s.signals.find(x=>x.id===odd.id).status,'won');
   events.push({fourAttempts:'lost',oneAttempt:'won'});
   await apply('spin',{value:'00'});s=await state();const end=s.stream.seq+30;assert.equal(s.stream.green_end,end);assert.ok(s.signals.filter(x=>x.status==='active').every(x=>x.window_end===end));
   for(let n=0;n<30;n++)await apply('spin',{value:n%2?'20':'1'});
   s=await state();assert.equal(s.stream.seq,end);assert.equal(s.stream.green_end,null);assert.equal(s.signals.filter(x=>x.status==='active').length,0);
   events.push({newGreenEnd:end,closedAt:s.stream.seq});
   await apply('new_session');await apply('seed_history',{values:['0','2','2','2','2','2']});await apply('spin',{value:'2'});s=await state();
   assert.equal(s.signals.filter(x=>x.session_no===2).length,0);
   events.push({inheritedSeedThresholdGap:true});
   // The missed absence must reset before the existing engine crosses 4 -> 5 again.
   await apply('spin',{value:'1'});for(let n=0;n<5;n++)await apply('spin',{value:'2'});s=await state();assert.ok(s.signals.some(x=>x.session_no===2&&x.target==='red'));
   assert.equal((await db.query('select public.rucaleta_v16_verify() d')).rows[0].d.valid,true);
   await db.exec('reset role');return events;
  }
  const before=await run('00000000-0000-4000-8000-000000000101');
  for(const file of ['sql/v25_admin_support_QA.sql','sql/v25_admin_permissions_QA.sql','supabase/migrations/20261019210000_rucaleta_billing_qa_bridge.sql','sql/v25_billing_completion_QA.sql'])await db.exec(await read(file));
  assert.deepEqual(await hashes(),beforeHash,'11 protected definitions unchanged');
  const after=await run('00000000-0000-4000-8000-000000000102');assert.deepEqual(after,before);
  console.log('ENGINE_SQL: before/after identical; three simultaneous signals, four attempts, 0/00 and 30 spins tested.');
  console.log('INHERITED_GAP: seed [0,2,2,2,2,2] then spin 2 produces no signal (threshold already crossed in seed). No rule changed.');
 }finally{await db.close();}
});
