import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
const read=p=>fs.readFile(new URL('../'+p,import.meta.url));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
test('protected source equals the recovered original ZIP baseline',async()=>{
 const expected=JSON.parse(await read('tests/fixtures/protected-hashes.json'));
 for(const [name,checksum] of Object.entries(expected.files))assert.equal(hash(await read(name)),checksum,name);
 const source=(await read('java.js')).toString();
 for(const [name,checksum] of Object.entries(expected.functions)){
  const start=new RegExp('(?:async )?function '+name+'\\(').exec(source).index;
  const next=/\n(?:async )?function \w+\(/.exec(source.slice(start+1));
  assert.equal(hash(source.slice(start,next?start+1+next.index:undefined)),checksum,name);
 }
 assert.equal(hash((await read('js/roulette-motion.js')).toString().split('export async function playIntro')[0]),expected.roulette_geometry_prefix);
});
