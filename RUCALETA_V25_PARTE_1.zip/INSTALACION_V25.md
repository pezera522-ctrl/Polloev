# Instalar y ejecutar V25

## Archivo completo o dos partes

Usa `RUCALETA_V25_FINAL.zip`, **o bien** extrae `RUCALETA_V25_PARTE_1.zip` y `RUCALETA_V25_PARTE_2.zip` en una misma carpeta vacía. Son ZIP normales complementarios, no segmentos binarios. Al terminar deben coexistir `index.html`, `java.js`, `app.css`, `premium-v25.css`, `js/`, `assets/`, `dark-ruby/`, `payments-server/` y `package.json` en la raíz. Conserva una copia de tu versión anterior y sus datos.

En Codespaces desde iPhone: coloca los archivos extraídos en la raíz de tu copia de trabajo, abre Terminal y ejecuta:

```sh
node --version
npm ci
npm test
npm run dev
```

Requiere Node 24.19 o posterior. Abre el puerto **4173** desde la sección Puertos de Codespaces. Usa su URL en el navegador. El servidor es para desarrollo; bloquea carpetas privadas y no publica el servicio de pagos. No uses el servidor Python antiguo que expone todos los archivos. No ejecutes despliegues de producción con estas instrucciones.

El frontend usa la configuración QA existente de `js/config.js`/`js/supabase.js`. La clave publicable es pública por diseño; no sustituyas por service_role. La sesión y los montos del navegador se conservan en su mismo origen: al cambiar de URL o dominio, el almacenamiento del navegador es distinto. No borres el almacenamiento de Safari para actualizar.

## Tu administrador

Proyecto comprobado: **RUCALETA-QA**, `xpkzzmnwzodikygfsdkp`.
Cuenta: **leonelmtz522@gmail.com**.
UUID real: **8053caa9-fe1b-41b0-9b1c-cbc87032abd9**. Correo confirmado; administrador principal confirmado por el servidor.

La asignación ya se realizó en QA. Inicia sesión normalmente, acepta los términos vigentes si corresponde y abre **Mi cuenta → Administración** o el menú administrativo. No crees otra cuenta. Si no aparece, pulsa sincronizar y comprueba que estás usando la URL QA; los permisos provienen del servidor.

`MIGRACIONES_SQL/05_admin_leonel_QA.sql` verifica UUID, correo y estado antes de asignar. Es idempotente; no hace falta repetirlo en el QA actual. No ejecutes este UUID ni los scripts sobre otro proyecto por suposición.

## Base de datos

Las migraciones nuevas ya están aplicadas en QA. Para una restauración del **mismo esquema compatible**, revisa y ejecuta en orden los archivos 01 a 04 de `MIGRACIONES_SQL/`; el 05 es la asignación del principal. Los archivos `sql/reference_v16/` son referencias históricas, no un instalador para volver a crear o sobrescribir el QA actual.

Revisión y reversión: antes de aplicar fuera de QA, compara el esquema y conserva una copia de seguridad. Cada archivo nuevo usa transacción. Si falla, revierte la transacción. Después de aplicar, una reversión operativa consiste en desactivar el servicio de pagos y revocar temporalmente EXECUTE sobre las RPC nuevas afectadas, conservando tablas e historial para revisión. No borres registros financieros ni restaures los permisos antiguos que permitirían omitir la protección del principal. Una reversión destructiva de datos requiere un plan específico y autorización.

## Servicio Mercado Pago QA

Es independiente del frontend estático y está desactivado por defecto. Configura los nombres de `payments-server/env.example` en el entorno privado del servidor: modo `sandbox`, vendedor de prueba, comprador `@testuser.com`, token de prueba, secreto webhook, UUIDs QA permitidos, clave publicable y service_role de **QA**, `APP_ORIGIN` HTTPS exacto y ruta SQLite persistente.

Puedes arrancarlo con `npm run billing:serve` una vez configuradas las variables del entorno; usa una sola instancia con volumen persistente y proxy HTTPS del mismo origen para `/api/billing/*` hacia 127.0.0.1:8788. Registra `/api/billing/webhook` con los eventos de suscripción/factura/pago. No publiques SQLite ni archivos de entorno. En la aplicación se usa checkout externo; no se capturan tarjetas.

Comprueba primero `/api/billing/capabilities`; configurado no significa cobro aprobado. La activación de Premium requiere pago verificado por el proveedor y conciliado en SQL. Un contrato autorizado por sí solo no concede Premium. Una creación incierta exige revisar su external_reference en Mercado Pago antes de intentar crear otro contrato.

Para probar compras externas necesitas las credenciales de prueba. No compartas claves ni contraseñas en el chat. Las pruebas locales y SQL no sustituyen esa comprobación.
