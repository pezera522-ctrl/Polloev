# Cambios V25

- Recuperada la copia de trabajo y comprobado el checkpoint SHA-256 `7786671bd5b8d33e3d199b02cb376d7921459f8efadcd92dbd9840ef0d784113`.
- Bienvenida en cada carga normal; Comenzar abre el portal de 3.2 segundos, con Saltar/Escape. Conserva sesión. Acceso antes de términos; dos casillas y aceptación confirmada por servidor. La recuperación de contraseña mantiene su ruta específica.
- Ruleta original conservada. Nueva capa SVG de luz rubí, metal, reflejos y halo; estela de bola y realce de cierre. La geometría de las 38 casillas, física y posiciones finales no cambian. Movimiento reducido respetado.
- Presentación de montos renovada: referencia actual, cuatro intentos desplegables, estados con etiquetas e historial local. Carrusel horizontal con controles y conservación de la señal observada. Se retiró de la presentación el contador agregado ambiguo entre señales.
- Un solo menú compacto, transiciones de pantallas y paneles, foco restaurado y ajuste al área disponible del teclado. Se conservan los recursos gráficos originales.
- Administración: usuarios, accesos recientes de 30 días, Premium, ingresos reales, pagos, creadores, comisiones y reversas, incidencias, soporte, roles y auditoría. Estados vacíos/error sin cifras inventadas.
- CSV paginado y protegido contra fórmulas; vista imprimible para guardar PDF. Corte temporal explícito; límite de exportación de 100,000 registros, sin truncamiento silencioso.
- Soporte conectado por RPC: tickets, respuestas, cierre, versiones, permisos y reintentos idempotentes. Un envío incierto conserva el texto y su identificador.
- Roles verificados en servidor. Administrador principal protegido contra revocación/bloqueo y secundarios sin capacidad de elevar sus permisos. Acceso directo a la RPC administrativa antigua revocado para evitar eludir estas protecciones.
- Puente de pagos QA: conciliación, precio/descuento fijado por contrato, comisiones sobre pago confirmado, reversas de reembolso total, eventos duplicados y cortesía de tres días desde el primer fallo verificado de renovación. Se preservan las vigencias manuales.
- Migraciones aplicadas solamente en RUCALETA-QA. Se verificó y configuró el UUID real del administrador solicitado, sin crear otra cuenta. Las 11 definiciones originales del servidor se conservaron.
- Retiradas las superficies visibles de créditos y las opciones Estrategia A/B. Los campos heredados internos del motor siguen protegidos; véase PENDIENTES_EXTERNOS.

Archivos principales: `premium-v25.css`, `index.html`, `java.js`, `js/admin-workspace.js`, `js/admin-tools.js`, `js/support.js`, `js/signal-presentation.js`, `js/premium-shell.js`, `assets/v25/roulette-light-rig.svg`, `payments-server/`, `sql/v25_*.sql`.
