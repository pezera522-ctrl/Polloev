# Comprobación breve de integridad

- Se conservaron todos los archivos originales; las incorporaciones y modificaciones están identificadas en `docs/evidencias/COMPARACION_ARCHIVOS.json`.
- SHA-256 originales: `docs/BASE_ARCHIVOS_ORIGINALES.json`. Comparación automática: `tests/v25-integrity.test.mjs`.
- Sin cambios: `js/engine.js`, `js/v15-projection.js`, `js/amount-reference.js`, `js/supabase.js`, `motion.css`, `ruleta-americana-premium.svg`.
- Sin cambios: funciones `confirmSignal`, `renderSignalFeed`, `operate`, `reconcile`; `POCKETS` y `frameAt`. `playIntro` solo incorpora cancelación para Saltar, conservando duración y recorrido.
- Las 11 definiciones SQL protegidas mantienen sus hashes previos. Captura anterior: `docs/QA_FUNCIONES_ANTES.json`. Definiciones comprobadas: `tests/fixtures/qa-engine-verified.json`. La integración local verifica igualdad antes/después.
- Cambios de permisos administrativos deliberados: los clientes usan RPC nuevas con protecciones; no pueden invocar directamente el antiguo mutador administrativo.
- El empaquetado verifica CRC, rutas, hashes, archivos requeridos, ausencia de secretos conocidos y equivalencia entre ZIP completo y dos partes. Véase `VALIDACION_ENTREGA.json`, junto a los ZIP.

No se declara validación total de producción. Los límites y autorizaciones pendientes están en `PENDIENTES_EXTERNOS.md`.
