# RUCALETA V24 — Entrega de trabajo (RUC-006 local, no integrado con servidor)

Se modificaron `java.js`, `app.css` y se agregó `js/amount-reference.js`.

## Cambios verificables
- Editor inferior de monto predeterminado y monto individual de cada señal, con formato MXN y hasta dos decimales.
- Referencias matemáticas ilustrativas para cuatro intentos, etiqueta del cuarto intento, detalles desplegables, y registro local de cambios.
- Confirmación del monto predeterminado por pestaña/visita usando `sessionStorage`; importes individuales por cuenta en `localStorage` de este navegador.
- No se cambió el motor, el backend, la autenticación, las migraciones ni producción.

## Limitaciones IMPORTANTES
- **NO es RUC-006 completo ni listo para producción.** Los montos se guardan solo en este navegador; no hay sincronización entre dispositivos, control de concurrencia del servidor, ni historial monetario remoto.
- La confirmación de intentos sigue utilizando los importes A/B exigidos por el esquema SQL y RPC heredados. No se han eliminado estas secuencias del servidor. El nuevo editor de referencias no modifica ni autoriza una apuesta.
- Las referencias de intentos anteriores se conservan a partir de los datos observados en este navegador; no pueden reconstruirse con garantía si la señal fue procesada en otro dispositivo o antes de guardar datos locales.
- La detección real de múltiples señales, la persistencia de visitas y la sincronización con Supabase requieren QA conectado y cambios del backend.
- No se realizaron pruebas con Safari real ni servidor Supabase autenticado.

## Pruebas
`npm run test:ux` terminó correctamente en este entorno: 19 pruebas de UX, comprobaciones legales y estáticas. Estas pruebas no cubren la integración de montos con backend.

## Cómo integrar las dos partes
Los archivos `RUCALETA_V24_PARTE_1.zip` y `RUCALETA_V24_PARTE_2.zip` son ZIP **independientes**, cada uno con diferentes archivos y rutas conservadas. Extrae AMBOS en la misma carpeta raíz del repositorio; no subas los ZIP sin extraer si quieres que GitHub Pages/Cloudflare despliegue la aplicación. No sustituyen uno al otro.

## Ajuste visual posterior
- Se retiró del panel visible el selector de secuencias A/B. El servidor todavía utiliza el esquema heredado y su valor predeterminado, por lo que este cambio es exclusivamente de presentación.
- Se reemplazó el encabezado redundante «SEÑAL ENCONTRADA» por «SEÑAL ACTIVA» y el texto del cuarto intento por «Último intento».
- **Importante:** retirar el selector no equivale a implementar un nuevo flujo de apuestas ni a eliminar el esquema interno del servidor.
