# RUCALETA V23 · Integración visual Dark Ruby en sesión activa (QA)

Base: V23 legal ya corregida. Se mantuvieron sus archivos y las otras pantallas.

## Alcance
- El módulo `dark-ruby/` contiene el HTML, CSS, JS y los recursos del ZIP entregado. Su diseño está encapsulado en Shadow DOM para evitar conflictos con la pantalla legal y el CSS anterior.
- Se sustituye la vista de la **sesión activa** por Dark Ruby. La pantalla de carga de cinco resultados iniciales permanece como en V23, pues tiene un flujo funcional diferente.
- El registro de números usa el botón `boton-agregar-sesion` y su lógica original de sincronización con el backend. El módulo nuevo no guarda resultados por sí solo.
- Historial, saldo, ventana, estado y categorías de señal se leen de los elementos que actualiza el motor original. No se usan los datos demostrativos del ZIP visual.
- La referencia aislada muestra `17`, `Split`, `Calle` y `Color` como DEMO. El motor V23 no expone un número caliente, split o calle de ese tipo. Se conserva la distribución visual, pero esas tres columnas muestran las categorías reales `Color`, `Mitades` y `Paridad`; no se inventan apuestas.
- Se preservan las pantallas legales, autenticación, créditos, motor, suscripción, Mercado Pago y administración.

## Cambios
- `index.html`: añade el host visual a sesión activa y carga el integrador.
- `app.css`: oculta únicamente la presentación antigua de la sesión activa cuando se monta el nuevo módulo.
- `dark-ruby/index.html`, `styles.css`, `app.js`, `integration.js`, `assets/*`: vista aislada y puente hacia los controles originales.

## QA
- `node --check dark-ruby/app.js`: OK.
- `node --check dark-ruby/integration.js`: OK.
- `python tests/static_checks.py`: PASS.
- **Pendiente**: prueba real de Safari y Supabase QA; no se pudo ejecutar captura automatizada porque falta el navegador de Playwright en el entorno.
- No se modificó GitHub ni producción.

## Instalación QA
Descomprime el ZIP web en una rama o entorno de prueba, conservando rutas relativas, y sirve la carpeta con HTTP. No abras `index.html` con `file://` porque el integrador carga recursos con `fetch`.
