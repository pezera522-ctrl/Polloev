# RUCALETA V21 · ADAPTACIÓN MERCADO PAGO QA

Fecha: 19 octubre 2026. Entrega basada en ZIP RUCALETA_V21_FINAL(1).zip del usuario.

## Implementado en ESTA ENTREGA (código local)
- Botón de suscripción de prueba dentro de Mi cuenta, condicionado a disponibilidad real del backend (si no hay proxy permanece oculto). Estados de pago, consulta y cancelación; no se concede premium desde el navegador.
- API Node/SQLite QA de V21 conservada con validación de firma, vendedor de prueba, importe MXN, pago aprobado, idempotencia, cancelación y notificaciones `payment` y `subscription_authorized_payment`.
- Nuevo puente backend hacia RPC de Supabase QA, usando solo rol de servicio privado, y migración SQL `supabase/migrations/20261019210000_rucaleta_billing_qa_bridge.sql`. La RPC registra pagos, recalcula vigencia de Premium a partir de pagos confirmados y revoca tras reembolso/contracargo (no afecta vigencias manuales de QA).
- No se habilita modo LIVE. Si la aplicación o cuenta está mal configurada el servidor falla sin permitir checkout.

## Comprobado
- Tests locales de pagos con DOBLES (nunca cuenta externa), reglas offline, geometría de ruleta, verificaciones estáticas y render Chromium mock de anchos móviles 375/390/430 px.

## NO realizado
- NO se modificó RUCALETA producción ni la web publicada. NO se aplicó SQL remotamente ni desplegó servidor. NO se configuraron tokens privados, Webhooks ni comprobó una transacción externa de Mercado Pago; no hay ninguna garantía de autorización comercial de RUCALETA.
- No hay URL pública exacta en el ZIP; `APP_ORIGIN` permanece por configurar. Tampoco se conoce el hosting del servidor Node de pagos.
- Para habilitar QA real: migración QA, hosting server HTTPS, secrets, reverse proxy de same-origin, webhook, ZIP web QA y una única prueba end-to-end. Luego revisar autorización comercial y preparar implementación de producción por separado.

**No subir FUENTE_COMPLETA al hosting estático.** Este paquete contiene SQL, backend y tests. Publicar solo el ZIP web separado si se usa un sitio QA.
