# RUCALETA V21 · rediseño del jugador · QA sin despliegue

Fecha: 19 de octubre de 2026. Base: `RUCALETA_V20_COMPLETA(1).zip` aportado por el usuario. El paquete contiene un ZIP web listo para montar en **un entorno estático de QA** y la fuente completa. **No subir la entrega completa como sitio estático**: contiene material técnico que no debe quedar expuesto.

## Cambios implementados

- Interfaz del jugador simplificada: barra con el logo original y un menú desplegable para cuenta, historial, guía, sonido y volver. El historial técnico, administración y suscripción mantienen pantallas independientes; el menú administrativo continúa limitado por un rol emitido por el backend.
- Selector de **38 botones** de ruleta americana (0, 00 y 1–36) con color real, mínimo 44 píxeles y entrada con un toque, sin teclado obligatorio. La entrada manual original sigue en un desplegable. Registro real mediante `API.analysisApi('spin', ...)`, con bloqueo durante la operación, identificadores únicos en outbox, recuperación de respuestas ambiguas y confirmación visible una vez recibida la lectura del servidor.
- Registro inicial fiel al contrato: **exactamente cinco** resultados y posibilidad de corregir o retirar números **antes** de iniciar. Se eliminó de la UI el selector de diez, que V20 ofrecía aunque el SQL vigente rechaza con `INITIAL_HISTORY_RANGE`.
- Tarjetas de señales solo desde la proyección verificada de Supabase; categorización independiente color/paridad/mitad; tarjetas simultáneas; fases de intentos mostradas según datos devueltos por el backend; cuarto intento en morado y con confirmación explícita no recomendada. Los resultados de cada intento no se atribuyen a un cálculo de frontend.
- Interfaz en espera discreta, últimos cinco resultados, mensajes breves, alertas de sincronización y créditos/ventana conservados en zonas secundarias. Se conserva la ruleta/animación V20 y el branding, autenticación, consentimientos, histórico, cuentas y pagos QA **sin alterar los servicios originales**.
- Interfaz honesta para errores posteriores a sincronización: abre un diálogo de corrección que explica el bloqueo de edición de operaciones autorizadas y ofrece consulta de historial o una sesión nueva. **No implementa edición en el servidor** ni inventa anulaciones.

## Contrato y caso obligatorio

SQL fuente V16 almacenado en `sql/reference_v16/qa_additive_v16.sql`: dispara durante `spin` al cruzar de **4 a 5 ausencias**, cuando `(premium OR credits > 0)` y la ventana posterior al 0/00 siga vigente. Los verdes no afectan contadores de ausencia; sí reinician los 30 giros. Se prueban hasta tres señales de distintas categorías simultáneas, debitando un crédito por grupo. Los cuatro intentos siguen requiriendo la confirmación de la acción antes de enviar el importe manual al servidor.

Caso `00,7,5,2,4,3`: sembrar `00,7,5,2,4` como historial inicial; registrar `3` como giro. Al terminar hay **5 ausencias de 19–36**, ventana abierta desde 00 y saldo suficiente; el SQL **debe crear la señal de la mitad alta en el sexto resultado**. No se exige ninguna espera adicional de 20 giros. El test `tests/absence_contract_v21.mjs` verifica offline estas condiciones exactas contra el texto de la función SQL. **No se ejecutó RPC contra Supabase QA**: no atribuir este caso a una prueba remota.

## Pruebas ejecutadas en este paquete

| Validación | Resultado |
|---|---|
| `node tests/absence_contract_v21.mjs` (contrato SQL y simulación determinista offline) | PASA |
| `node tests/roulette_motion.cjs` (geometría y API de animación) | PASA |
| `node tests/payments_service.mjs` (transportes de pruebas simulados) | PASA |
| `python tests/static_checks.py` (CSP, sintaxis, seguridad superficial, assets, IDs) | PASA |
| `python tests/local_visual_v21.py` (Chromium con API doble, 375/390/430 px) | PASA: registro, señales, cuatro intentos, morado, menú, corrección y ausencia de desbordamiento |
| Suite completa `npm test` / DOM Auth (`jsdom`) | **NO EJECUTADA**: `npm ci` no pudo descargar todas las dependencias en este entorno |
| Playwright WebKit/Safari real en iPhone | **NO EJECUTADA** |
| RPC real de Supabase QA: Auth/RLS, créditos, ventanas y suscripciones | **NO EJECUTADA** |
| Mercado Pago externo, webhooks, premium y comisiones reales | **NO CONECTADO** |

Las capturas `docs/v21-*.png` proceden de Chromium con API *doble de pruebas* y no de una cuenta real. La lógica de simulación de pruebas está solo bajo `tests/`, **no dentro del ZIP web**.

## Pendientes verificables

1. Integración de una corrección de giro auditable en el backend, si se decide permitir edición después de confirmar. Actualmente no debe adulterarse un stream cuyos eventos y hashes ya son inmutables. Antes de iniciar la sesión sí se permite corregir.
2. Decidir si se habilitará un historial de inicio de diez números: requeriría adaptación transaccional de backend con idempotencia y evaluación de señales, no solo permitir el selector que V20 mostró sin soporte del SQL.
3. Ejecutar `npm ci && npm test` en Codespaces/Node 24, seguida de prueba funcional real QA con cuenta autorizada, verificando las reglas, RLS, concurrencia, créditos y Auth.
4. Certificar tamaño, teclado, accesibilidad, audio y animación en Safari físico de iPhone; aquí solo se verificó render Chromium de anchos móviles. No se recibieron los dos videos referidos como archivos accesibles junto al ZIP en este encargo.
5. Completar Mercado Pago en un servidor separado: `payments-server/README.md` y `payments-server/env.example` describen vendedor/comprador de prueba, webhook, token y secretos, proxy HTTPS, volumen persistente, puente transaccional Supabase para acceso Premium y eventos de renovación/reembolso. No existen cobros habilitados ni botón de pago simulado.
6. Resolver rol del administrador utilizando UUID Auth autorizado en QA (`sql/bootstrap_admin_MANUAL.sql`). No se asignó aquí.

**No se modificaron producción, GitHub, bases de datos, Mercado Pago ni cuentas externas.**
