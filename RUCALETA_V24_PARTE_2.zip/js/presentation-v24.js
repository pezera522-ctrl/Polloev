// Presentation only: move original nodes, never clone their state or replace handlers.
export function mountPresentation(actions){
 const $=id=>document.getElementById(id);
 const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;};
 const icon=name=>{const i=node('img','v24-icon');i.src=`assets/icons/${name}.svg`;i.alt='';i.setAttribute('aria-hidden','true');return i;};
 const button=(text,name,fn,cls='v24-metal')=>{const b=node('button',cls);b.type='button';b.append(icon(name),node('span','',text));b.onclick=fn;return b;};
 const replaceIcon=(el,name)=>{if(el)el.replaceChildren(icon(name));};
 replaceIcon($('rucaleta-menu-toggle'),'Menu');
 const live=$('contenido-sesion-activa'),hero=live.querySelector('.v22-live-hero');
 const toolbar=node('nav','v24-toolbar');toolbar.setAttribute('aria-label','Controles de la mesa');
 const sound=button('Sonido','Volume2',actions.sound);sound.id='v24-sound';
 const updateSound=enabled=>{sound.setAttribute('aria-pressed',String(enabled));sound.querySelector('img').src=`assets/icons/${enabled?'Volume2':'VolumeX'}.svg`;sound.querySelector('span').textContent=enabled?'Sonido':'Silenciado';};
 updateSound(actions.soundEnabled());document.addEventListener('rucaleta:sound',e=>updateSound(e.detail));
 toolbar.append(button('Volver','ArrowLeft',actions.home),button('Guía','BookOpen',actions.guide),button('Mi cuenta','UserRound',actions.account),sound);
 const controls=$('account-tools');
 const sync=$('sync-now');sync.replaceChildren(icon('RefreshCw'),node('span','','Sincronizar'));sync.classList.add('v24-sync');
 const creditWrap=node('div','v24-stat'),windowWrap=node('div','v24-stat');creditWrap.append(icon('Coins'),$('credit-info'));windowWrap.append(icon('ChartNoAxesColumnIncreasing'),$('window-info'));
 controls.prepend(creditWrap,windowWrap);controls.querySelector('#account-button').hidden=true; // Cuenta has one visible entry in the toolbar.
 const register=$('control-sesion');register.classList.add('v24-register');register.querySelector('label').textContent='Registrar nuevo resultado';register.querySelector('label').prepend(icon('Dice5'));
 $('boton-agregar-sesion').replaceChildren(node('span','','Agregar'));
 const picker=$('live-picker').parentElement;const manual=picker.querySelector('.manual-entry');
 const analysis=node('details','v24-analysis-details');analysis.append(node('summary','','Detalle del análisis'),$('panel-analisis'));
 const history=live.querySelector('.bloque-historial-sesion');const historyTitle=history.querySelector('.titulo-bloque');if(historyTitle)historyTitle.textContent='Historial sincronizado';
 live.prepend(hero,toolbar,controls,sync,$('window-meter'),$('sync-status'),live.querySelector('.cabecera-sesion'),$('panel-estado'),$('primary-signal-feed'),history,picker,analysis);
 if(manual){manual.open=false;manual.querySelector('summary').textContent='Escribir resultado con el teclado';}
 // Keep the original manual field within its native disclosure; do not duplicate the entry UI.
 const logo=$('logo-principal');logo.setAttribute('width','1000');logo.setAttribute('height','399');
 const account=$('account-dialog'),identity=node('section','v24-account-card');
 const person=node('div','v24-avatar');person.append(icon('UserRound'));const email=node('div','v24-identity');email.append(node('span','','Correo del usuario'),$('account-info'));
 const plan=node('div','v24-account-data');plan.append(icon('Crown'),node('span','','Plan actual'),$('v22-account-plan'));
 const credit=node('div','v24-account-data');credit.append(icon('Coins'),node('span','','Créditos disponibles'),$('v22-account-credits'));
 identity.append(person,email,plan,credit);account.querySelector('.dialog-header').after(identity);
 // Remove only now-empty original plan/credit labels, never their bound data nodes.
 for(const row of [...account.querySelectorAll('.v22-subscription-status > div')])if(!row.querySelector('strong'))row.remove();
 const subscription=account.querySelector('.v22-subscription-status');const processor=node('div');processor.append(node('span','','Administrador de pagos'),node('strong','','Mercado Pago'));subscription.append(processor);
 const decorate=(id,name)=>{const el=$(id);if(el){const label=el.textContent;el.replaceChildren(icon(name),node('span','v24-label',label));}};
 for(const [id,name] of [['review-documents','FileText'],['new-session','RefreshCw'],['v22-preferences','Settings'],['open-admin','ShieldCheck'],['logout','LogOut'],['v22-open-premium','Crown']])decorate(id,name);
 const historySummary=$('history-section').querySelector('summary');historySummary.prepend(icon('History'));
 for(const [id,name] of [['v22-home-register','Dice5'],['v22-home-tutorial','BookOpen'],['v22-home-history','History'],['v22-home-account','UserRound']])replaceIcon($(id).querySelector('.v22-icon'),name);
 for(const [id,name,label] of [['v22-nav-home','House','Inicio'],['v22-nav-register','Dice5','Registrar'],['v22-nav-tutorial','BookOpen','Tutorial'],['v22-nav-account','UserRound','Cuenta']])$(id).replaceChildren(icon(name),node('small','',label));
 for(const [id,label] of [['boton-agregar','Agregar'],['boton-iniciar-sesion','Abrir mesa'],['boton-login','Entrar']])$(id).replaceChildren(node('span','',label));
 const adminHeader=$('admin-dialog').querySelector('.v22-admin-section-heading');const adminRefresh=button('Sincronizar','RefreshCw',()=>document.dispatchEvent(new Event('rucaleta:admin-refresh')));adminRefresh.id='v24-admin-refresh';adminHeader.after(adminRefresh);
 $('account-dialog').dataset.presentation='v24';$('admin-dialog').dataset.presentation='v24';
}
