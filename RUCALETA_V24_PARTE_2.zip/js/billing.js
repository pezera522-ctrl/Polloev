import {sessionToken} from './supabase.js';
const endpoint='/api/billing';
async function api(path,method='GET'){
 const headers={'Accept':'application/json'};
 if(path!=='/capabilities'){
  const token=await sessionToken();if(!token)throw new Error('Inicia sesión para consultar la suscripción.');
  headers.Authorization='Bearer '+token;
 }
 const res=await fetch(endpoint+path,{method,headers,cache:'no-store',credentials:'same-origin',redirect:'error'});
 const data=await res.json().catch(()=>null);
 if(!res.ok)throw new Error(data?.error||'Servidor de pagos no disponible.');
 return data;
}
export const capabilities=()=>api('/capabilities');
export const status=()=>api('/status');
export const checkout=()=>api('/checkout','POST');
export const cancel=()=>api('/cancel','POST');
