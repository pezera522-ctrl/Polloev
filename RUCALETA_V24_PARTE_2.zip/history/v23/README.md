# RUCALETA V22 — PREVISUALIZACIÓN QA

**PRIMERO:** leer `ESTADO_V22_QA.md`.

- Base de código: RUCALETA V21 Mercado Pago QA adjunta por el usuario.
- Diseño V22 integrado en `index.html` + `app.css`, reutilizando fondos independientes en `assets/v22/` y el logotipo auténtico `logo-rucaleta.webp`.
- `v22.css`: fuente de estilos de V22, **también incorporada al final de `app.css`** para usar la misma hoja única que exige la comprobación de integridad original. No enlazar las dos a la vez.
- No se ha alterado `js/supabase.js`, `js/engine.js`, `js/billing.js`, la lógica de señales ni el servicio de pagos. No se ha desplegado.
- Para web QA usar exclusivamente `RUCALETA_V22_WEB_QA.zip` exterior de esta entrega. **No** copiar `FUENTE_COMPLETA/` a una página pública.
- Ejecutar `python3 tests/static_checks.py`, `node tests/absence_contract_v21.mjs` y `python3 tests/local_visual_v22.py` para las pruebas disponibles. Safari físico / QA real siguen pendientes.
