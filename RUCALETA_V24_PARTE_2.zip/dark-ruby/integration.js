// V23 Ruby isolated visual integration: no changes to signal/credit/payment engines.
const host=document.getElementById('dark-ruby-host');
const screen=document.getElementById('pantalla-sesion-activa');
const $=id=>document.getElementById(id);
const markup=await (await fetch(new URL('./index.html',import.meta.url))).text();
const doc=new DOMParser().parseFromString(markup,'text/html');
const shadow=host.attachShadow({mode:'open'});
const style=document.createElement('link');style.rel='stylesheet';style.href=new URL('./styles.css',import.meta.url).href;
const visual=doc.querySelector('#rucaleta').cloneNode(true);
visual.querySelector('.brand img').src=new URL('./assets/rucaleta-logo.png',import.meta.url).href;
visual.querySelector('#result').value='';
shadow.append(style,visual);
await import('./app.js');
const api=window.RucaletaDarkRuby;
api.clearDemo();
const input=shadow.querySelector('#result');input.value='';
const alert=shadow.querySelector('#error');
const safeNumber=n=>n==='00'||/^(0|[1-9]|[12][0-9]|3[0-6])$/.test(String(n));
const realState=()=>{
 const text=$('window-info')?.textContent||'';
 const windowMatch=text.match(/(\d+)\/30/);
 const credits=$('credit-info')?.textContent||'—';
 const attempts=$('numero-intento')?.textContent||'0/4';
 const session=$('estado-superior')?.textContent||'SESIÓN ACTIVA';
 api.setStatus({credits:credits.replace(/\s*CRÉDITOS/i,'').trim(),windowCount:windowMatch?windowMatch[1]+'/30':'—/30',session:session.includes('ACTIVA')?'ACTIVA':'EN ESPERA'});
 const history=[...$('historial-sesion')?.querySelectorAll('.giro-sesion')||[]].map(e=>e.textContent.trim()).filter(safeNumber);
 api.setHistory(history);
 const color=$('resultado-color')?.textContent?.trim()||'—';
 const half=$('resultado-mitades')?.textContent?.trim()||'—';
 const parity=$('resultado-paridad')?.textContent?.trim()||'—';
 const active=($('texto-estado')?.textContent||'').toLowerCase().includes('señal activa');
 // V22 does not provide a verified single hot number, split or street.
 // Never invent these values: keep the layout but show the engine's real categories.
 const heading=shadow.querySelector('#signalHeading');heading.textContent=active?'SEÑAL ACTIVA':'SIN SEÑAL ACTIVA';
 shadow.querySelector('#signalNumber').textContent=active?half:'—';
 shadow.querySelector('#signalLabel').textContent=active?'ANÁLISIS DE MESA':'ESPERANDO RESULTADOS';
 shadow.querySelector('.bet-title').textContent=active?'SEÑALES DEL MOTOR:':'ESTADO DE LA MESA';
 shadow.querySelector('.alternatives-title').textContent='ANÁLISIS VERIFICADO';
 const names=shadow.querySelectorAll('.alternative > span'); ['Color','Mitades','Paridad'].forEach((n,i)=>names[i].textContent=n);
 for(const [i,value] of [color,half,parity].entries()){
   const chips=shadow.querySelectorAll('.alternative .chips')[i];chips.replaceChildren();
   const b=document.createElement('b');b.className='dark color';b.textContent=value;chips.append(b);
 }
 const notes=shadow.querySelectorAll('.alternative small');notes.forEach(n=>n.textContent='Datos del motor');
 shadow.querySelector('.disclaimer').textContent='RUCALETA ofrece análisis estadísticos. No garantiza resultados.';
 shadow.querySelector('.signal').setAttribute('aria-label',heading.textContent+' · intento '+attempts);
};
let queued=false;const refresh=()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;realState();});};
const observer=new MutationObserver(refresh);
for(const id of ['historial-sesion','window-info','credit-info','numero-intento','estado-superior','texto-estado','resultado-color','resultado-mitades','resultado-paridad']){
 const node=$(id);if(node)observer.observe(node,{childList:true,subtree:true,characterData:true});
}
const mount=()=>{if(!screen.hidden){screen.classList.add('ruby-mounted');refresh();}};
new MutationObserver(mount).observe(screen,{attributes:true,attributeFilter:['hidden']});mount();
shadow.querySelector('#rucaleta').addEventListener('rucaleta:result-requested',e=>{
 const n=String(e.detail.number);
 if(!safeNumber(n))return;
 if($('boton-agregar-sesion').disabled){alert.textContent='Espera a que termine la operación anterior.';alert.hidden=false;return;}
 $('numero-sesion').value=n;
 $('boton-agregar-sesion').click();
 // The existing asynchronous operation owns success/failure. Never claim saved here.
 shadow.querySelector('#toast').classList.remove('show');
});
shadow.querySelector('#rucaleta').addEventListener('rucaleta:navigate',e=>{
 const action=e.detail.action;
 if(action==='guide')$('help-dialog')?.showModal();
 if(action==='account')$('account-button')?.click();
 if(action==='history'){$('account-button')?.click();$('history-section').open=true;$('full-history')?.click();}
 if(action==='roulette-type'){
  const toast=shadow.querySelector('#toast');toast.textContent='Ruleta americana: 0, 00 y 1–36.';toast.classList.add('show');
 }
});
shadow.querySelector('#menuButton').addEventListener('click',()=>{});
// Sound toggle is UI-only until mapped to existing sound preference; prevent false promise.
const sound=shadow.querySelector('#soundButton');sound.addEventListener('click',()=>{$('v22-preferences')?.click();});
refresh();
