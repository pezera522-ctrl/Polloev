import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createScreenNavigator,openDialog,mountDialogAccessibility} from '../js/ui-motion.js';
function fixture(reduced=false){
 const screens=['home','account','help'].map((id,i)=>({id,hidden:i!==0,classList:{remove(){}},animations:[],animate(frames,options){
  let finish;const finished=new Promise(r=>finish=r);const a={finished,cancel(){finish();},finish,frames,options};this.animations.push(a);return a;
 }}));
 const win={scrollY:0,matchMedia:()=>({matches:reduced}),setTimeout,clearTimeout,scrollTo({top}){this.scrollY=top;}};
 const focused=[];const navigator=createScreenNavigator({screens,win,focus:s=>focused.push(s.id)});
 return {screens,win,focused,navigator};
}
test('back navigation restores scroll without delayed focus stealing',async()=>{
 const f=fixture(true);f.win.scrollY=350;await f.navigator.go(f.screens[1]);assert.equal(f.win.scrollY,0);
 f.win.scrollY=120;await f.navigator.go(f.screens[0]);assert.equal(f.win.scrollY,350);
 assert.deepEqual(f.focused,['account','home']);assert.equal(f.screens.filter(s=>!s.hidden).length,1);
});
test('rapid navigation cancels the older animation; last destination wins',async()=>{
 const f=fixture();const a=f.navigator.go(f.screens[1]);const b=f.navigator.go(f.screens[2]);
 f.screens[2].animations[0].finish();await Promise.all([a,b]);
 assert.equal(f.screens[2].hidden,false);assert.equal(f.screens[1].hidden,true);
 assert.deepEqual(f.focused,['account','help']);
});
test('reduced motion does not animate or wait for presentation timers',async()=>{
 const f=fixture(true);await f.navigator.go(f.screens[1]);assert.equal(f.screens[1].animations.length,0);
});
test('reselecting the current screen preserves focus and scroll',async()=>{
 const f=fixture(true);f.win.scrollY=230;await f.navigator.go(f.screens[0]);assert.equal(f.win.scrollY,230);assert.deepEqual(f.focused,[]);
});
test('navigation remains usable when animation API is unavailable',async()=>{
 const f=fixture();delete f.screens[1].animate;await f.navigator.go(f.screens[1]);assert.equal(f.screens[1].hidden,false);
});
test('native modal close restores opener without stealing another dialog focus',async()=>{
 const dialog=new EventTarget();let focusCount=0,otherOpen=false;
 const opener={isConnected:true,closest:()=>null,focus:()=>focusCount++};
 const win=new EventTarget();win.matchMedia=()=>({matches:true});win.queueMicrotask=queueMicrotask;win.innerHeight=844;
 const props={};const doc={activeElement:opener,defaultView:win,documentElement:{style:{setProperty:(k,v)=>props[k]=v}},querySelectorAll:()=>[dialog],querySelector:()=>otherOpen?{}:null};
 Object.assign(dialog,{ownerDocument:doc,dataset:{},open:false,showModal(){this.open=true;},scrollTop:300});
 mountDialogAccessibility(doc,win);openDialog(dialog);assert.equal(dialog.open,true);assert.equal(dialog.scrollTop,0);
 dialog.open=false;dialog.dispatchEvent(new Event('close'));await Promise.resolve();assert.equal(focusCount,1);
 openDialog(dialog);otherOpen=true;dialog.dispatchEvent(new Event('close'));await Promise.resolve();assert.equal(focusCount,1);
 assert.equal(props['--visible-height'],'844px');
});
test('keyboard viewport updates available modal height',()=>{
 const vv=new EventTarget();vv.height=410;vv.offsetTop=25;const props={};
 const win=new EventTarget();win.visualViewport=vv;win.innerHeight=844;
 const doc={querySelectorAll:()=>[],documentElement:{style:{setProperty:(k,v)=>props[k]=v}}};
 mountDialogAccessibility(doc,win);assert.equal(props['--visible-height'],'410px');assert.equal(props['--visible-top'],'25px');
 vv.height=300;vv.dispatchEvent(new Event('resize'));assert.equal(props['--visible-height'],'300px');
});
