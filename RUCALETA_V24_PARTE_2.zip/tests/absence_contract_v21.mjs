// Offline behavioral verification of the V16 SQL contract only, NOT a live Supabase test.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {attributes,normalizeNumber} from '../js/engine.js';
const sql=readFileSync(new URL('../sql/reference_v16/qa_additive_v16.sql',import.meta.url),'utf8');
for(const clause of ["previous=4 AND next_count=5", "st.green_end IS NOT NULL AND st.seq<st.green_end", "IF created AND NOT premium THEN debit:=1", "IF val IN ('0','00') THEN", "IF attempt_no>4", "IF st.green_end IS NOT NULL AND st.seq>=st.green_end"]){assert.ok(sql.includes(clause),'Missing SQL rule '+clause);}
// Mirrors the SQL condition; diagnostic evidence, not a generator of user-visible signals.
function mirror(values,{initial=5,credits=5,premium=false}={}){
 const streaks={red:0,black:0,even:0,odd:0,low:0,high:0};let seq=0,end=null,generation=0,charged=0;
 const created=[];
 const allTargets=['red','black','even','odd','low','high'];
 for(const [i,raw] of values.entries()){
  const v=normalizeNumber(raw);seq++;
  const attr=attributes(v);if(!attr){end=seq+30;generation++;continue;}
  const old={...streaks};for(const key of allTargets)streaks[key]=Object.values(attr).includes(key)?0:streaks[key]+1;
  if(i>=initial && end!==null && seq<end && (credits>0||premium)){
    const group=[];for(const key of allTargets)if(old[key]===4&&streaks[key]===5)group.push(key);
    if(group.length){created.push({seq,targets:group});if(!premium){credits--;charged++;}}
  }
  if(end!==null&&seq>=end)end=null;
 }
 return {streaks,end,created,charged,credits,generation};
}
let x=mirror(['00','7','5','2','4','3']);assert.equal(x.streaks.high,5);assert.deepEqual(x.created,[{seq:6,targets:['high']}]);assert.equal(x.charged,1);
x=mirror(['0','2','4','6','8','10']);assert.deepEqual(new Set(x.created[0].targets),new Set(['red','odd','high']));assert.equal(x.charged,1,'simultaneous category signals cost one group credit');
x=mirror(['00','7','0','5','2','4','3'],{initial:5});assert.equal(x.streaks.high,5);assert.deepEqual(x.created,[{seq:7,targets:['high']}]);assert.equal(x.generation,2,'new green reopens 30-spin window');
x=mirror(['00','7','5','2','4','3'],{credits:0});assert.equal(x.created.length,0,'no fabricated signal without authorization');
x=mirror(['00','7','5','2','4','3'],{credits:0,premium:true});assert.equal(x.created.length,1);assert.equal(x.charged,0);
x=mirror(['7','5','2','4','3','6']);assert.equal(x.created.length,0,'no signal without green window');
assert.equal(normalizeNumber('00'),'00');assert.equal(attributes('0'),null);assert.equal(attributes('00'),null);
for(const n of ['37','-1','000'])assert.throws(()=>normalizeNumber(n));
// Document an existing server limitation: five seed entries are used for counts but
// initial seed_history does NOT create signals; all signaling is inside spin.
const fiveSeed=mirror(['00','1','3','5','7'],{initial:5});assert.equal(fiveSeed.created.length,0);
console.log('PASS SQL rule contract (offline): five absences, 0/00 neutral, reopen window, 3 concurrent targets, 1 credit/group, credit gating, 0/00 identity, no 20-spin artificial wait.');
console.log('KNOWN LIMITATION: server emits signals only in spin, not while importing the five seed results. Supabase QA not contacted.');
