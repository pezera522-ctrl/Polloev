// Execute the actual application functions with explicit API/UI doubles.
// This validates navigation decisions, not DOM layout, Safari, or live Supabase.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {completeDocuments,documentFingerprint,draftMatches} from '../js/legal-gate.js';

const source=fs.readFileSync(new URL('../java.js',import.meta.url),'utf8');
function section(start,end){
 const a=source.indexOf(start),b=source.indexOf(end,a+start.length);
 assert.ok(a>=0&&b>a,`Missing source section: ${start}`);
 return source.slice(a,b);
}
const code=[
 section('async function abrirLoginConRuleta(', '/* ========================================================= LOGIN'),
 section('function actualizarAceptacion()', 'async function continuarDesdeInstrucciones'),
 section('async function entrarMesaDesde(', '/* ========================================================= ESTILO DE NUMEROS'),
 section('async function loadAccount()', 'function renderLegalDocuments()'),
 section('async function intentarLogin()', '/* ========================================================= MOSTRAR / OCULTAR'),
 source.slice(source.indexOf('async function loadPublicLegal()'))
].join('\n');
const docs=[1,2,3].map(id=>({id,title:`Documento ${id}`,content_md:`Texto de prueba ${id}`,sha256:`hash-${id}`}));
function fixture(){
 const nodes=new Map(),calls=[];
 const element=()=>({hidden:true,disabled:false,textContent:'',classList:{toggle(){}},checked:false});
 const get=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id);};
 const c={completeDocuments,documentFingerprint,draftMatches,console,setTimeout,clearTimeout,
  signedUser:null,legal:null,legalDraft:null,publicLegalLoading:false,remote:null,
  navegacionBloqueada:false,botonIniciar:element(),transicionRuleta:element(),ruletaAnimada:element(),
  pantallaLogin:element(),pantallaLegal:element(),pantallaJugador:element(),
  checkInstrucciones:element(),checkEdad:element(),botonAceptarLegal:element(),aceptacionInstrucciones:element(),
  mensajeLogin:element(),loginUsuario:{value:'qa@example.invalid',validity:{valid:true}},loginClave:{value:'qa-password'},
  $:get,document:{getElementById:get,querySelector:()=>element()},window:{matchMedia:()=>({matches:true})},
  API:{getPublicLegal:async()=>({ready:false,required_documents:docs}),userInfo:async()=>({id:'qa',email:'qa@example.invalid'}),
   getLegal:async()=>({ready:false,required_documents:docs}),signIn:async()=>calls.push('sign-in'),
   acceptLegal:async()=>calls.push('accept')},
  prepararAudio(){},sonidoInicio(){},sonidoAcceso(){},crearParticulasAcceso(){},
  playIntro:async()=>calls.push('intro'),prepararLogin(){},setAuthMode:register=>calls.push(register?'register':'login'),
  prepararInstrucciones(){c.checkInstrucciones.checked=false;c.checkEdad.checked=false;c.botonAceptarLegal.disabled=true;},
  renderLegalDocuments:()=>calls.push('documents'),
  ocultarPantallas(){for(const n of [c.pantallaLogin,c.pantallaLegal,c.pantallaJugador])n.hidden=true;},
  transicionNormal:async(from,to)=>{from.hidden=true;to.hidden=false;calls.push(to===c.pantallaLegal?'legal-screen':'next-screen');},
  focusScreen:()=>{},refresh:async()=>{calls.push('analysis');c.remote={admin:false,premium_active:false,free_credits_remaining:4};},
  reconcile:async()=>calls.push('reconcile'),renderRemote:()=>calls.push('render'),
  task:async(fn,status)=>{try{await fn();return true;}catch(e){status.textContent=e.message;return false;}}
 };
 vm.createContext(c);vm.runInContext(code,c);
 return {c,calls,get};
}

// Start must wait for the existing intro, then reveal legal, including offline.
{
 const {c,calls}=fixture();let finish;c.playIntro=()=>new Promise(r=>finish=r);
 c.API.getPublicLegal=async()=>{throw Error('offline');};
 const start=c.abrirLoginConRuleta({type:'click'});
 assert.equal(c.pantallaLegal.hidden,true);finish();await start;await Promise.resolve();
 assert.equal(c.pantallaLegal.hidden,false);assert.equal(c.pantallaLogin.hidden,true);
 assert.equal(calls.includes('accept'),false);assert.equal(c.navegacionBloqueada,false);
 assert.match(c.$('legal-status').textContent,/Accede/);
}
{
 const {c}=fixture();await c.abrirLoginConRuleta('login');assert.equal(c.pantallaLogin.hidden,false);
 c.signedUser={id:'qa'};c.legal={ready:true};await c.abrirLoginConRuleta();
 assert.equal(c.pantallaJugador.hidden,false);assert.equal(c.pantallaLegal.hidden,true);
}
// Neither one checkbox nor missing original text can create a consent.
{
 const {c,calls}=fixture();c.legal={ready:false,required_documents:docs};
 for(const [terms,age,enabled] of [[false,false,false],[true,false,false],[false,true,false],[true,true,true]]){
  c.checkInstrucciones.checked=terms;c.checkEdad.checked=age;c.actualizarAceptacion();
  assert.equal(!c.botonAceptarLegal.disabled,enabled);
  if(!enabled)await c.continuarDesdeLegal();
 }
 assert.equal(calls.includes('accept'),false);
 await c.continuarDesdeLegal();assert.equal(c.legalDraft,documentFingerprint(docs));
 assert.equal(c.pantallaLogin.hidden,false);assert.equal(calls.includes('accept'),false);
 c.legal.required_documents=[];c.actualizarAceptacion();assert.equal(c.botonAceptarLegal.disabled,true);
}
// Loading legal does not touch analysis or an outbox before renewed consent.
{
 const {c,calls}=fixture();c.refresh=async()=>{throw Error('analysis unavailable');};
 await c.loadAccount();assert.equal(calls.includes('documents'),true);
 assert.equal(calls.includes('reconcile'),false);assert.equal(c.$('account-info').textContent,'qa@example.invalid');
 await c.entrarMesaDesde(c.pantallaLogin);assert.equal(c.pantallaLegal.hidden,false);
 assert.equal(c.pantallaJugador.hidden,true);
}
// Version-matched draft is saved through the existing RPC only after sign-in.
{
 const {c,calls}=fixture();let accepted=false;c.legalDraft=documentFingerprint(docs);
 c.API.acceptLegal=async()=>{calls.push('accept');accepted=true;};
 c.API.getLegal=async()=>({ready:accepted,required_documents:docs});
 await c.intentarLogin();assert.ok(calls.indexOf('sign-in')<calls.indexOf('accept'));
 assert.equal(c.pantallaJugador.hidden,false);assert.equal(c.legalDraft,null);
 assert.ok(calls.indexOf('reconcile')>calls.indexOf('accept'));
}
// A changed document or rejected server confirmation never grants entry.
{
 const {c,calls}=fixture();c.legalDraft=documentFingerprint(docs);
 c.API.getLegal=async()=>({ready:false,required_documents:docs.map(d=>({...d,sha256:'new-'+d.id}))});
 await c.intentarLogin();assert.equal(calls.includes('accept'),false);assert.equal(c.pantallaLegal.hidden,false);
 c.checkInstrucciones.checked=true;c.checkEdad.checked=true;c.actualizarAceptacion();
 await c.continuarDesdeLegal();assert.equal(c.pantallaJugador.hidden,true);
 assert.equal(c.checkInstrucciones.checked,false);assert.equal(c.botonAceptarLegal.disabled,true);
}
{
 const {c,calls}=fixture();c.API.getLegal=async()=>({ready:true,required_documents:docs});
 await c.intentarLogin();assert.equal(calls.includes('accept'),false);assert.equal(c.pantallaJugador.hidden,false);
}
console.log('PASS V24 source-function scenarios: intro -> legal; offline fallback; existing account; two independent confirmations; no anonymous consent; version changes; server rejection; no outbox replay before consent. API/UI doubles, not browser/live tests.');
