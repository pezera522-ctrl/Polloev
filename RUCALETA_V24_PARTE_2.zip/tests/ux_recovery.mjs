import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createReadRecovery} from '../js/read-recovery.js';

function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
function fixture(){
 const win=new EventTarget(),doc=new EventTarget(),timers=new Map();let serial=0;
 win.navigator={onLine:true};doc.visibilityState='visible';
 win.setTimeout=fn=>{timers.set(++serial,fn);return serial;};win.clearTimeout=id=>timers.delete(id);
 const data={owner:'user-a',busy:false,pending:false,requests:[],commits:[],states:[]};
 const recovery=createReadRecovery({win,doc,scope:()=>data.owner,canRead:()=>!!data.owner&&!data.busy,hasPending:()=>data.pending,
  read:()=>{const d=deferred();data.requests.push(d);return d.promise;},
  commit:x=>{data.commits.push(x);return true;},onState:x=>data.states.push(x)});
 const drain=()=>{for(const [id,fn] of [...timers]){timers.delete(id);fn();}};
 return {win,doc,data,recovery,timers,drain};
}
test('one read for simultaneous retry requests; confirmed only after a response',async()=>{
 const f=fixture(),a=f.recovery.retry(),b=f.recovery.retry();
 assert.equal(f.data.requests.length,1);assert.equal(f.recovery.state,'verifying');assert.equal(f.data.commits.length,0);
 f.data.requests[0].resolve({revision:7});await Promise.all([a,b]);
 assert.deepEqual(f.data.commits,[{revision:7}]);assert.equal(f.recovery.state,'fresh');f.recovery.destroy();
});
test('offline blocks reads and invalidates previously confirmed values',async()=>{
 const f=fixture();f.recovery.confirmed();f.win.navigator.onLine=false;f.win.dispatchEvent(new Event('offline'));
 assert.equal(f.recovery.state,'offline');assert.equal(await f.recovery.retry(),false);assert.equal(f.data.requests.length,0);f.recovery.destroy();
});
test('online never equals confirmed without a server response',async()=>{
 const f=fixture();f.win.dispatchEvent(new Event('online'));f.drain();
 assert.equal(f.recovery.state,'verifying');assert.equal(f.data.commits.length,0);
 const done=f.recovery.retry();f.data.requests[0].resolve({revision:1});await done;
 assert.equal(f.recovery.state,'fresh');f.recovery.destroy();
});
test('a late response after disconnect cannot commit',async()=>{
 const f=fixture(),done=f.recovery.retry();f.win.navigator.onLine=false;f.win.dispatchEvent(new Event('offline'));
 f.data.requests[0].resolve({revision:1});await done;
 assert.equal(f.data.commits.length,0);assert.equal(f.recovery.state,'offline');f.recovery.destroy();
});
test('restoring a page verifies by read only and keeps pending operations pending',async()=>{
 const f=fixture();f.data.pending=true;f.win.dispatchEvent(new Event('pageshow'));f.drain();
 const done=f.recovery.retry();f.data.requests[0].resolve({revision:8});await done;
 assert.equal(f.recovery.state,'pending');assert.equal(f.data.pending,true);assert.equal(f.data.requests.length,1);f.recovery.destroy();
});
test('suspension invalidates a read; resume schedules a fresh read',async()=>{
 const f=fixture(),done=f.recovery.retry();f.doc.visibilityState='hidden';f.doc.dispatchEvent(new Event('visibilitychange'));
 f.data.requests[0].resolve({revision:1});await done;assert.equal(f.data.commits.length,0);
 f.doc.visibilityState='visible';f.doc.dispatchEvent(new Event('visibilitychange'));f.drain();
 const next=f.recovery.retry();assert.equal(f.data.requests.length,2);f.data.requests[1].resolve({revision:2});await next;
 assert.deepEqual(f.data.commits,[{revision:2}]);f.recovery.destroy();
});
test('account switch cannot commit the previous account response',async()=>{
 const f=fixture(),done=f.recovery.retry();f.data.owner='user-b';f.data.requests[0].resolve({private:'a'});await done;
 assert.equal(f.data.commits.length,0);f.recovery.destroy();
});
test('foreground confirmation wins over an older in-flight read',async()=>{
 const f=fixture(),done=f.recovery.retry();f.recovery.confirmed();f.data.requests[0].resolve({revision:1});await done;
 assert.equal(f.data.commits.length,0);assert.equal(f.recovery.state,'fresh');f.recovery.destroy();
});
test('busy foreground operation postpones recovery without starting another operation',async()=>{
 const f=fixture();f.data.busy=true;f.win.dispatchEvent(new Event('online'));f.drain();assert.equal(f.data.requests.length,0);
 f.data.busy=false;f.recovery.flush();f.drain();const done=f.recovery.retry();f.data.requests[0].resolve({revision:3});await done;
 assert.equal(f.recovery.state,'fresh');f.recovery.destroy();
});
test('operation starting during read prevents committing that read',async()=>{
 const f=fixture(),done=f.recovery.retry();f.data.busy=true;f.data.requests[0].resolve({revision:1});await done;
 assert.equal(f.data.commits.length,0);assert.equal(f.recovery.state,'stale');f.recovery.destroy();
});
test('read failure stays uncertain and does not retry in a loop',async()=>{
 const f=fixture(),done=f.recovery.retry();f.data.requests[0].reject(Error('network'));await done;
 assert.equal(f.recovery.state,'error');assert.equal(f.timers.size,0);assert.equal(f.data.commits.length,0);f.recovery.destroy();
});
test('logout and disposal do not commit outstanding requests',async()=>{
 const f=fixture(),done=f.recovery.retry();f.data.owner=null;f.recovery.destroy();f.data.requests[0].resolve({revision:1});await done;
 f.win.dispatchEvent(new Event('online'));f.drain();assert.equal(f.data.commits.length,0);assert.equal(f.data.requests.length,1);
});
