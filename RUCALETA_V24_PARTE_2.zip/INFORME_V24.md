# RUCALETA V24 — cambios, pruebas y límites

20 de octubre de 2026. Reconstrucción sobre el ZIP V23 adjunto. Sin modificación de producción ni de Supabase QA. El propietario autorizó continuar sin acceso a la página; por ello se entrega implementación QA con validación visual pendiente, no una versión certificada pixel-perfect.

## Resultado implementado

- app.css sustituye la cascada de versiones por un sistema visual único. El anterior queda en history/v23/app.css, sin cargarse.
- index.html carga la nueva hoja y java.js con marcador V24; elimina la integración Shadow DOM de Dark Ruby. Los históricos permanecen en el ZIP completo.
- js/presentation-v24.js reorganiza los nodos reales: encabezado, cuatro accesos, saldo, ventana, sincronización, intentos, registro manual, estado, acciones de señales, historial y los 38 números.
- Logo auténtico logo-rucaleta.webp. No se usa el logo alternativo de dark-ruby/assets.
- Fondos existentes: bienvenida en portada y detalles de ruleta; casino en mesa y modales; legal como base de «Antes de continuar», con casino en su cabecera; legal también en acceso, guía y preparación; rubí en pie decorativo de mesa. Ninguna captura aprobada se usa como interfaz plana.
- Cuenta presenta identidad, plan y créditos mediante los mismos elementos que actualiza renderRemote; conserva suscripción, historial, preferencias, documentos, cierre, nueva sesión y administración autorizada.
- Premium conserva $199 MXN/mes, códigos, consulta del servidor y checkout externo. No hay campos de tarjeta ni activación local de Premium.
- Administración conserva tablas, filtros, selección, formularios y permisos. Añade un botón para volver a consultar la RPC real. No se agregan estadísticas o pagos ficticios para copiar la fotografía.
- SVG de ruleta: esmaltes rojos/negros y tonos de metal; las posiciones, figuras y números no cambian. js/roulette-motion.js y su CSS de geometría y animación se conservan exactamente.

## Navegación legal

Comenzar lleva a «Antes de continuar» después de la animación existente. «Ya tengo cuenta» lleva al acceso. El estado remoto decide si se requiere aceptación.

La lectura anterior de documentos exigía autenticación. Se añadió una consulta de solo lectura a la tabla legal existente mediante los permisos anónimos ya configurados. No se alteran permisos. Si la consulta devuelve los tres documentos completos, las dos casillas se habilitan. La selección previa al login solo vive como borrador de IDs/hashes; no concede acceso. Tras autenticarse se verifica que sigan siendo las mismas versiones y se utiliza accept_current_legal_documents. El servidor vuelve a confirmar ready.

Si la tabla no admite lectura anónima, o sus columnas no coinciden con la proyección esperada, la pantalla legal informa que los originales deben cargarse con sesión. «Acceder para cargar documentos» conduce al login; después se exige aceptar los originales antes de abrir la mesa. No se afirma que la aceptación previa al login funcione en el servidor actual: ese permiso y esquema no pudieron verificarse. Los mensajes de carga de las tres tarjetas no sustituyen los documentos legales.

## Tabla de control

| Problema original | Causa/evidencia | Archivos corregidos | Solución | Prueba y resultado |
|---|---|---|---|---|
| Comenzar abre directamente acceso | Destino explícito en abrirLoginConRuleta | java.js | Selección legal por defecto, acceso separado para cuenta existente | Contrato de código comprobado; navegación en navegador pendiente |
| Legal dependía del login | getLegal exige token | js/supabase.js, js/legal-gate.js, java.js, index.html | Consulta pública sin cambios de permisos; carga autenticada si no está disponible; borrador por versiones | Pruebas puras de documentos completos/hashes aprobadas; RPC real pendiente |
| Un solo checkbox no debe bastar | Dos confirmaciones independientes | java.js / app.css | Ambas necesarias, además de tres documentos completos | Condición estática comprobada; interacción real pendiente |
| Fondo eliminado en sesión | ruby-mounted forzaba fondo sólido | app.css, index.html | Eliminar capa de ocultación y asignar fondos a las superficies visibles | Rutas CSS comprobadas; render pendiente |
| Logo distinto | Dark Ruby usaba otro recurso | index.html, js/presentation-v24.js | Logo auténtico en pantallas reales | Archivo original inspeccionado y conservado |
| Teclado/acciones ocultos | Regla escondía todos los nodos fuera del host | index.html, js/presentation-v24.js | Reubicar nodos originales sin clonar handlers; mantener feed de confirmación | Contratos y referencias estáticos; operación remota pendiente |
| Estilos acumulados | app.css V23 contenía 1251 !important | app.css, motion.css | Hoja visual nueva; movimiento original separado | Sintaxis JS, referencias y preservación CSS de movimiento aprobadas |
| Ruleta plana | Colores y materiales SVG | ruleta-americana-premium.svg | Cambios de pintura únicamente | XML comparado: formas, transformaciones y números idénticos; test de movimiento aprobado |
| Sonido incoherente entre dos interfaces | Estado local duplicado en Dark Ruby | java.js, js/presentation-v24.js | Una preferencia y un control de sonido compartido; reanuda audio al activar | Revisión estática; reproducción en Safari pendiente |
| Canciones ausentes | No existen archivos musicales | Ninguno | Se conservan los efectos Web Audio, sin inventar pistas | Inventario confirmado |
| Cuenta y Premium | Presentación alejada de referencia | app.css, js/presentation-v24.js | Nueva composición con datos ligados a nodos existentes | Lógica de pagos preservada por comparación de bytes; pruebas simuladas aprobadas |
| Admin | Presentación y navegación | app.css, js/presentation-v24.js, java.js | Estilo uniforme y actualización real; controles previos preservados | Backend/SQL idénticos; permisos remotos pendientes |
| Versión difícil de identificar | Marcadores 22/23 mezclados | VERSION.json, package.json, index.html, _headers | Marcador V24 y revalidación HTTP donde el host admita _headers | Archivos inspeccionados; Codespaces no verificado |
| Evidencia visual antigua insuficiente | Pruebas V22 retiraban scripts reales y simulaban API | design-qa.md / este informe | Separar explícitamente evidencia histórica de V24 | No se reutilizan capturas viejas como pruebas nuevas |
| Tarjetas legales heredaban estilos de otros desplegables | Cada tarjeta tenía ui-details y legal-entry; las reglas posteriores sobrescribían borde, padding y resumen | app.css | Excluir tarjetas legales del estilo genérico y separar el margen del botón de guía | Selectores revisados; comprobación estática aprobada; render pendiente |
| Una operación pendiente podía impedir llegar al consentimiento actualizado | loadAccount ejecutaba reconcile antes de la aceptación; la operación remota exige CURRENT_LEGAL_CONSENT_REQUIRED | java.js | Consultar primero documentos y diferir lectura de análisis/reconciliación hasta tener consentimiento válido | Escenario ejecutado con análisis no disponible y sin consentimiento: legal carga, no se reproduce la operación |
| Estado accesible del menú no se cerraba al elegir una opción | El menú ocultaba el panel sin actualizar aria-expanded | js/presentation-v24.js | Un único cierre actualiza ambos estados | Revisión de código y sintaxis aprobadas; interacción DOM pendiente |

## Pruebas ejecutadas

- PASS: tests/legal_gate_v24.mjs — documentos incompletos, duplicados, cambio de hash, orden y borrador.
- PASS: tests/legal_flow_v24.mjs — ejecución de las funciones reales con dobles de API/UI: espera de animación, destino legal, carga fallida, ambas casillas, ausencia de aceptación anónima, cambio de versión, rechazo del servidor, consentimiento previo y operación pendiente diferida. No es una prueba de navegador.
- PASS: tests/roulette_motion.cjs — 38 casillas, ceros opuestos, alineación, movimiento final, espera de animaciones y movimiento reducido.
- PASS: tests/static_checks.py — referencias, IDs, sintaxis y comprobaciones del script existente.
- PASS: tests/release_v24.py — recursos CSS/importaciones, ausencia de capa Shadow DOM activa y comparación de archivos protegidos con la base.
- PASS: 26 archivos protegidos idénticos por SHA256 a V23, incluidos motor, movimiento, backend, pagos, configuración, logo y fondos. Todos los identificadores HTML originales permanecen salvo dark-ruby-host, la capa retirada.
- PASS: tests/payments_service.mjs — proveedor simulado; no contacto con Mercado Pago real.
- No ejecutadas: integración DOM basada en jsdom (dependencia no disponible), capturas Playwright, Safari, 375/390/393/430 en navegador, Supabase, RLS y pagos reales.

La comprobación de código no prueba el resultado visual ni que la configuración del servidor remoto sea compatible. Los tests históricos se conservan, pero contienen expectativas del flujo anterior y no certifican esta reconstrucción.

## Pendientes materiales

1. Comparar capturas reales contra las referencias a igual viewport y ajustar proporciones.
2. Confirmar lectura pública de los documentos legales o decidir su exposición de solo lectura en QA. Sin ella, la aceptación auténtica requiere login.
3. Probar registro, conservación de créditos, cuatro intentos y acceso administrativo con cuentas QA.
4. Probar Safari real y sonido tras gesto; confirmar que las teclas estrechas del patrón visual resulten cómodas en iPhone.
5. Verificar proxy /api/billing, suscripción y webhooks en QA. No se activó cobro alguno.
6. Referencias separadas de bienvenida, inicio y Premium: no venían entre las cinco imágenes adjuntas de este turno; se armonizaron con la identidad y recursos existentes.

No se produjeron capturas V24 ni imágenes falsas de comparación. La fidelidad exacta sigue pendiente.

## Contenido de la entrega

Un único RUCALETA_V24_FINAL.zip con el proyecto completo, originales históricos sin carga activa, este informe, instrucciones en README.md, inventario de cambios en CAMBIOS_V24.json, salida real de pruebas en docs/PRUEBAS_V24.txt y manifiesto SHA256 actualizado. docs/referencias contiene las cuatro fotografías objetivo disponibles, identificadas como referencias, no capturas de implementación. El informe de auditoría inicial se conserva en docs/AUDITORIA_BASE_V23.md.
