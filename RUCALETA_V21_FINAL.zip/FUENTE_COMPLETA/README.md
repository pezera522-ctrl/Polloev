# RUCALETA V21 · aplicación web móvil QA

Rediseño profundo sobre la V20 original: una mesa sencilla, selector completo 0/00/1–36, estado de espera discreto y tarjetas de señales confirmadas por el servidor.

## Contenido del ZIP de entrega

- `RUCALETA_V21_WEB_QA.zip`: **la carpeta web publicable** ya comprimida. Para Pages, sube **este ZIP interior** a una cuenta/entorno separado de QA; incluye `index.html` y no contiene servicio Node, SQL, registros de prueba, secretos ni dependencias de desarrollo.
- Carpeta completa restante: fuente, servicio de pagos QA separado, migraciones históricas, pruebas y evidencias. **No publicar la carpeta completa** en un hosting estático: expondría archivos de desarrollo.

Para pruebas locales de la fuente, ejecuta `python3 -m http.server 8767`, abre `http://localhost:8767`, o usa Codespaces. `file://` no es válido para importar módulos. Nada en la entrega hace cambios automáticos a QA o producción.

Consulta `ESTADO_V21.md` para resultados y restricciones. Las pruebas de navegador incluyen dobles de API exclusivamente bajo `tests`, no son pruebas de Supabase conectado ni de Safari físico. Los pagos de suscripción siguen deshabilitados y el precio de $199 MXN/mes es informativo, no un enlace de compra.
