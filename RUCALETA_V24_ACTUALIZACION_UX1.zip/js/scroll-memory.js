// View-only state. Never stores account, consent, or game data.
export function createScrollMemory(getY, restore) {
  const positions = new WeakMap();
  return {
    save(screen) {
      if (screen && !screen.hidden) positions.set(screen, Math.max(0, getY() || 0));
    },
    restore(screen) {
      if (screen && !screen.hidden) restore(positions.get(screen) ?? 0);
    }
  };
}
