# RUCALETA V24 — actualización UX1

Actualización incremental para la copia V24 actualizada. No es una aplicación completa.
Extraer en la misma carpeta que el index.html activo, reemplazando únicamente los
archivos incluidos. No contiene credenciales, fondos, cambios de backend ni pagos.
No instalar sobre otra versión sin comparar primero. No modifica producción por sí sola.

Cambios: memoria temporal de posición por pantalla; foco accesible sin desplazamiento
automático al inicio; transiciones de navegación más cortas; scroll programático sin
interpolación; overscroll vertical desactivado en navegadores compatibles; altura mínima
estable con svh. Índice actualizado para invalidar caché de CSS y JavaScript.
Ruleta, bola, fondos, identidad, motor y lógica de apuestas sin modificaciones en esta actualización.

No incluye recomendaciones de importes, progresiones ni promoción de casinos.
No garantiza bloquear la recarga nativa en todas las versiones de Safari.

Pruebas: ver resultado comunicado con la entrega. Pendiente: Safari físico, fluidez
visual, navegación con teclado virtual, servicios reales y comparación de capturas.
En iPhone: bajar en una pantalla, salir y volver; comprobar posición y probar el
arrastre superior. Abrir/cerrar documentos y formularios; verificar que no se bloquee
el scroll. La primera visita a cada pantalla comienza arriba.
