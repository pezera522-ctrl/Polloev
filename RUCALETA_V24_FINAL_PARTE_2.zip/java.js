import {mountPresentation} from './js/presentation-v24.js?v=24-final';
import {completeDocuments,documentFingerprint,draftMatches} from './js/legal-gate.js?v=24-final';
import {playIntro} from './js/roulette-motion.js';
import * as API from './js/supabase.js?v=24-final';
import * as Billing from './js/billing.js';
import {normalizeNumber,friendly} from './js/engine.js';
"use strict";
/* ========================================================= LA RUCALETA JAVA PRINCIPAL ========================================================= */
/* ========================================================= ELEMENTOS GENERALES ========================================================= */
const pantallaInicio = document.getElementById("pantalla-inicio"); const pantallaLogin = document.getElementById("pantalla-login"); const pantallaInstrucciones = document.getElementById("pantalla-instrucciones"); const pantallaLegal = document.getElementById("pantalla-legal"); const pantallaSesion = document.getElementById("pantalla-sesion"); const pantallaSesionActiva = document.getElementById("pantalla-sesion-activa");
const overlayTransicion = document.getElementById("overlay-transicion"); const transicionRuleta = document.getElementById("transicion-ruleta"); const ruletaAnimada = document.getElementById("ruleta-animada"); const ruletaBolaOrbita = document.querySelector(".ruleta-bola-orbita"); const capaEfectos = document.getElementById("capa-efectos");
/* ========================================================= PORTADA ========================================================= */
const contenedorLogo = document.getElementById("contenedor-logo"); const logoPrincipal = document.getElementById("logo-principal"); const botonIniciar = document.getElementById("boton-iniciar");
/* ========================================================= LOGIN ========================================================= */
const loginPanel = document.getElementById("login-panel"); const loginUsuario = document.getElementById("login-usuario"); const loginClave = document.getElementById("login-clave"); const botonVerClave = document.getElementById("boton-ver-clave"); const botonLogin = document.getElementById("boton-login"); const mensajeLogin = document.getElementById("mensaje-login"); const loginCarga = document.getElementById("login-carga");

/* ========================================================= INSTRUCCIONES ========================================================= */
const checkInstrucciones = document.getElementById("check-instrucciones");
const checkEdad = document.getElementById("check-edad");
const pantallaJugador = document.getElementById("pantalla-jugador");
const aceptacionInstrucciones = document.getElementById("aceptacion-instrucciones");
const botonContinuarInstrucciones = document.getElementById("boton-continuar-instrucciones"); const botonAceptarLegal = document.getElementById("boton-aceptar-legal");
/* ========================================================= ULTIMOS 10 NUMEROS ========================================================= */
const contadorInicial = document.getElementById("contador-inicial");
const historialNumeros = document.getElementById("historial-numeros");
const casillasHistorial = Array.from(document.querySelectorAll(".casilla-historial"));
const numeroRuleta = document.getElementById("numero-ruleta");
const botonAgregar = document.getElementById("boton-agregar");
const mensajeInicial = document.getElementById("mensaje-inicial");
const contenedorIniciarSesion = document.getElementById("contenedor-iniciar-sesion");
const botonIniciarSesion = document.getElementById("boton-iniciar-sesion");
/* ========================================================= SESION ACTIVA ========================================================= */
const contenidoSesionActiva = document.getElementById("contenido-sesion-activa");
const contadorIntentos = document.getElementById("contador-intentos");
const numeroIntento = document.getElementById("numero-intento");
const panelEstado = document.getElementById("panel-estado");
const textoEstado = document.getElementById("texto-estado");
const descripcionEstado = document.getElementById("descripcion-estado");
const nivelSenal = document.getElementById("nivel-senal");
const opcionColor = document.getElementById("opcion-color");
const opcionMitades = document.getElementById("opcion-mitades");
const opcionParidad = document.getElementById("opcion-paridad");
const resultadoColor = document.getElementById("resultado-color");
const resultadoMitades = document.getElementById("resultado-mitades");
const resultadoParidad = document.getElementById("resultado-paridad");
const historialSesion = document.getElementById("historial-sesion");
const girosSesion = Array.from(document.querySelectorAll(".giro-sesion"));
const confirmarAnalisis = document.getElementById("confirmar-analisis");
const contenedorConfirmarApuesta = document.getElementById("contenedor-confirmar-apuesta");
const numeroSesion = document.getElementById("numero-sesion");
const botonAgregarSesion = document.getElementById("boton-agregar-sesion");
const mensajeSesion = document.getElementById("mensaje-sesion");
/* ========================================================= RULETA ========================================================= */
const ROJOS = new Set([ 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 ]);
const NEGROS = new Set([ 2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35 ]);
/* ========================================================= ESTADO GENERAL ========================================================= */
let numerosIniciales = [];
let initialTarget=5;
let historialCompleto = [];
let intentoActual = 0;
let secuenciaActiva = false;
let esperandoResultadoApuesta = false;
let apuestaCongelada = null;
let estadoVisualActual = "ESPERAR";
let navegacionBloqueada = false;
let cerrandoSecuencia = false;
let audioContext = null;
let soundEnabled=true;try{soundEnabled=localStorage.getItem("rucaleta-sound")!=="off";}catch{}
const ORDEN_RULETA_AMERICANA = ["0", 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1, "00", 27, 10, 25, 29, 12, 8, 19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2];
const PASO_RULETA_AMERICANA = 360 / ORDEN_RULETA_AMERICANA.length;
/* ========================================================= UTILIDADES ========================================================= */
function esperar(ms) {
return new Promise((resolve) => {

    setTimeout(resolve, ms);

});
}
function normalizarNumero(valor){try{const v=normalizeNumber(valor);return v==='00'?'00':Number(v);}catch{return null;}}
function esVerde(numero) {
return numero === 0 || numero === "00";
}
function obtenerColor(numero) {
if (esVerde(numero)) {
    return "VERDE";
}

if (ROJOS.has(numero)) {
    return "ROJO";
}

if (NEGROS.has(numero)) {
    return "NEGRO";
}

return null;
}
function obtenerParidad(numero) {
if (esVerde(numero)) {
    return null;
}

return numero % 2 === 0 ? "PAR" : "IMPAR";
}
function obtenerMitad(numero) {
if (esVerde(numero)) {
    return null;
}

if (numero >= 1 && numero <= 18) {
    return "1-18";
}

if (numero >= 19 && numero <= 36) {
    return "19-36";
}

return null;
}
/* ========================================================= AUDIO ========================================================= */
function prepararAudio() {
if(!soundEnabled)return;
try {

    if (!audioContext) {

        const AudioContext =
            window.AudioContext ||
            window.webkitAudioContext;

        if (!AudioContext) {
            return;
        }

        audioContext = new AudioContext();

    }

    if (audioContext.state === "suspended") {

        audioContext.resume();

    }

} catch (error) {

    console.warn("Audio no disponible");

}
}
function tono({
     frecuencia = 440, 
     duracion = 0.08,
      volumen = 0.035,
       tipo = "sine",
        retraso = 0 } = {}) {
if (!soundEnabled || !audioContext) {
    return;
}

try {

    const inicio =
        audioContext.currentTime + retraso;

    const oscilador =
        audioContext.createOscillator();

    const ganancia =
        audioContext.createGain();

    oscilador.type = tipo;

    oscilador.frequency.setValueAtTime(
        frecuencia,
        inicio
    );

    ganancia.gain.setValueAtTime(
        0.0001,
        inicio
    );

    ganancia.gain.exponentialRampToValueAtTime(
        volumen,
        inicio + 0.015
    );

    ganancia.gain.exponentialRampToValueAtTime(
        0.0001,
        inicio + duracion
    );

    oscilador.connect(ganancia);

    ganancia.connect(audioContext.destination);

    oscilador.start(inicio);

    oscilador.stop(
        inicio + duracion + 0.03
    );
    } catch (error) {

    console.warn("No se pudo reproducir sonido");

}
}
function sonidoClick() {
tono({
    frecuencia: 310,
    duracion: 0.055,
    volumen: 0.025,
    tipo: "triangle"
});

tono({
    frecuencia: 520,
    duracion: 0.07,
    volumen: 0.018,
    tipo: "sine",
    retraso: 0.025
});
}
function sonidoInicio() {
tono({
    frecuencia: 180,
    duracion: 0.13,
    volumen: 0.035,
    tipo: "sine"
});

tono({
    frecuencia: 360,
    duracion: 0.16,
    volumen: 0.028,
    tipo: "triangle",
    retraso: 0.07
});

tono({
    frecuencia: 620,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.15
});
}
function sonidoRuleta() {
tono({
    frecuencia: 110,
    duracion: 0.55,
    volumen: 0.03,
    tipo: "sawtooth"
});

tono({
    frecuencia: 170,
    duracion: 0.45,
    volumen: 0.018,
    tipo: "triangle",
    retraso: 0.18
});
}
function sonidoAcceso() {
tono({
    frecuencia: 390,
    duracion: 0.09,
    volumen: 0.03,
    tipo: "triangle"
});

tono({
    frecuencia: 560,
    duracion: 0.12,
    volumen: 0.025,
    tipo: "triangle",
    retraso: 0.08
});

tono({
    frecuencia: 790,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.16
});
}
function sonidoError() {
tono({
    frecuencia: 150,
    duracion: 0.12,
    volumen: 0.035,
    tipo: "square"
});

tono({
    frecuencia: 115,
    duracion: 0.16,
    volumen: 0.025,
    tipo: "square",
    retraso: 0.1
});
}
function sonidoCondicion() {
tono({
    frecuencia: 290,
    duracion: 0.12,
    volumen: 0.03,
    tipo: "triangle"
});

tono({
    frecuencia: 410,
    duracion: 0.15,
    volumen: 0.024,
    tipo: "triangle",
    retraso: 0.08
});
}
function sonidoEntrada() {
tono({
    frecuencia: 360,
    duracion: 0.11,
    volumen: 0.035,
    tipo: "triangle"
});

tono({
    frecuencia: 620,
    duracion: 0.18,
    volumen: 0.027,
    tipo: "sine",
    retraso: 0.08
});
}
function sonidoConfirmacion() {
tono({
    frecuencia: 240,
    duracion: 0.07,
    volumen: 0.035,
    tipo: "square"
});

tono({
    frecuencia: 480,
    duracion: 0.11,
    volumen: 0.025,
    tipo: "triangle",
    retraso: 0.06
});
}
function sonidoUltimoIntento() {
tono({
    frecuencia: 170,
    duracion: 0.16,
    volumen: 0.04,
    tipo: "sawtooth"
});

tono({
    frecuencia: 220,
    duracion: 0.16,
    volumen: 0.032,
    tipo: "sawtooth",
    retraso: 0.14
});

tono({
    frecuencia: 300,
    duracion: 0.2,
    volumen: 0.026,
    tipo: "triangle",
    retraso: 0.28
});
}
function sonidoGanada() {
tono({
    frecuencia: 420,
    duracion: 0.13,
    volumen: 0.035,
    tipo: "triangle"
});

tono({
    frecuencia: 620,
    duracion: 0.16,
    volumen: 0.032,
    tipo: "triangle",
    retraso: 0.1
});

tono({
    frecuencia: 850,
    duracion: 0.24,
    volumen: 0.027,
    tipo: "sine",
    retraso: 0.2
});
}
function sonidoCierre() {
tono({
    frecuencia: 320,
    duracion: 0.11,
    volumen: 0.027,
    tipo: "triangle"
});

tono({
    frecuencia: 210,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.1
});
}
/* ========================================================= NAVEGACION ========================================================= */
function ocultarPantallas() {
pantallaInicio.hidden = true;
pantallaJugador.hidden = true;
pantallaLogin.hidden = true;
pantallaInstrucciones.hidden = true;
pantallaLegal.hidden = true;
pantallaSesion.hidden = true;
pantallaSesionActiva.hidden = true;
}
async function mostrarPantalla( pantalla, claseEntrada = "pantalla-entrando" ) {
ocultarPantallas();

pantalla.hidden = false;

pantalla.classList.remove(
    "pantalla-entrando",
    "pantalla-entrando-profunda",
    "pantalla-saliendo"
);

void pantalla.offsetWidth;

pantalla.classList.add(claseEntrada);

await esperar(420);

pantalla.classList.remove(claseEntrada);focusScreen(pantalla);
}
async function transicionNormal( pantallaActual, pantallaSiguiente ) {
if (navegacionBloqueada) {
    return;
}

navegacionBloqueada = true;

overlayTransicion.classList.add(
    "overlay-activo"
);

pantallaActual.classList.add(
    "pantalla-saliendo"
);

await esperar(420);

pantallaActual.hidden = true;
pantallaActual.classList.remove(
    "pantalla-saliendo"
);

pantallaSiguiente.hidden = false;

pantallaSiguiente.classList.add(
    "pantalla-entrando"
);

await esperar(180);

overlayTransicion.classList.remove(
    "overlay-activo"
);

await esperar(500);

pantallaSiguiente.classList.remove(
    "pantalla-entrando"
);

navegacionBloqueada = false;focusScreen(pantallaSiguiente);
}
/* ========================================================= TRANSICION DE RULETA PORTADA -> LOGIN ========================================================= */
async function abrirLoginConRuleta(mode = "legal") {
 if(typeof mode!=="string")mode="legal";
 let destination=pantallaLogin;
 if(navegacionBloqueada)return;
 navegacionBloqueada=true;botonIniciar.disabled=true;prepararAudio();sonidoInicio();
 try{
  transicionRuleta.hidden=false;
  await playIntro({wheel:ruletaAnimada,orbit:document.querySelector('.ruleta-bola-orbita'),ball:document.querySelector('.ruleta-bola'),reduced:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches});
  prepararLogin();
  if(mode==='legal'){
   if(signedUser&&legal?.ready){destination=pantallaJugador;}
   else{destination=pantallaLegal;prepararInstrucciones();renderLegalDocuments();void loadPublicLegal();}
  }
  ocultarPantallas();destination.hidden=false;
  if(transicionRuleta.animate&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){const fade=transicionRuleta.animate([{opacity:1},{opacity:0}],{duration:180,fill:'forwards'});let timer;try{await Promise.race([fade.finished,new Promise(r=>timer=setTimeout(r,400))]);}finally{clearTimeout(timer);fade.cancel();}}
 }finally{transicionRuleta.hidden=true;botonIniciar.disabled=false;navegacionBloqueada=false;}
 // Do not summon the mobile keyboard automatically after the intro.
 focusScreen(destination);
}
/* ========================================================= LOGIN ========================================================= */


function prepararLogin() {
loginUsuario.value = "";

loginClave.value = "";

loginClave.type = "password";

botonVerClave.textContent = "VER";

botonLogin.disabled = false;

loginUsuario.disabled = false;

loginClave.disabled = false;

mensajeLogin.textContent =
    "ACCESO REQUERIDO";

loginPanel.classList.remove(
    "login-error",
    "login-correcto",
    "login-validando"
);

loginCarga.classList.remove(
    "login-carga-activa"
);
}
function mostrarErrorLogin( texto = "USUARIO O CLAVE INCORRECTOS" ) {
mensajeLogin.textContent = texto;

loginPanel.classList.remove(
    "login-error"
);

void loginPanel.offsetWidth;

loginPanel.classList.add(
    "login-error"
);

sonidoError();

setTimeout(() => {

    loginPanel.classList.remove(
        "login-error"
    );

}, 650);
}
async function intentarLogin(){
 await task(async()=>{
  if(!loginUsuario.value.trim()||!loginUsuario.validity.valid)throw Error('Introduce un correo electrónico válido.');
  if(!loginClave.value)throw Error('Escribe tu contraseña.');
  await API.signIn(loginUsuario.value.trim(),loginClave.value);loginClave.value='';await loadAccount();sonidoAcceso();crearParticulasAcceso();
  if(!legal.ready&&draftMatches(legalDraft,legal.required_documents)){
   await API.acceptLegal(legal.required_documents);legal=await API.getLegal();
  }
  legalDraft=null;
  if(legal.ready){await entrarMesaDesde(pantallaLogin);}
  else{prepararInstrucciones();renderLegalDocuments();await transicionNormal(pantallaLogin,pantallaLegal);}

 },mensajeLogin);
}
/* ========================================================= MOSTRAR / OCULTAR CLAVE ========================================================= */
function alternarClave() {
prepararAudio();

sonidoClick();

const mostrando =
    loginClave.type === "text";

loginClave.type =
    mostrando
        ? "password"
        : "text";

botonVerClave.textContent = mostrando ? "VER" : "OCULTAR";
botonVerClave.setAttribute("aria-label",mostrando?"Mostrar contraseña":"Ocultar contraseña");
botonVerClave.setAttribute("aria-pressed",String(!mostrando));
}
/* ========================================================= INSTRUCCIONES ========================================================= */
function prepararInstrucciones() {
 checkInstrucciones.checked = false;
 checkEdad.checked = false;
 botonAceptarLegal.disabled = true;
 aceptacionInstrucciones.classList.remove("aceptacion-activa");
}
function actualizarAceptacion() {
 const ok = checkInstrucciones.checked && checkEdad.checked && completeDocuments(legal?.required_documents);
 botonAceptarLegal.disabled = !ok;
 aceptacionInstrucciones.classList.toggle("aceptacion-activa", checkInstrucciones.checked);
 document.getElementById('aceptacion-edad').classList.toggle('aceptacion-activa',checkEdad.checked);
}
async function continuarDesdeInstrucciones(){
 if(!legal){document.getElementById('legal-status').textContent='No se pudieron cargar los documentos.';return;}
 if(legal.ready){await entrarMesaDesde(pantallaInstrucciones);return;}
 await transicionNormal(pantallaInstrucciones,pantallaLegal);
}
async function entrarMesaDesde(origen){
 if(!signedUser||!legal?.ready){prepararInstrucciones();renderLegalDocuments();await transicionNormal(origen,pantallaLegal);return;}
 await loadPlayerAccount();
 await transicionNormal(origen,pantallaJugador);
 renderRemote();
}
async function continuarDesdeLegal(){
 if(!checkInstrucciones.checked || !checkEdad.checked || botonAceptarLegal.disabled || !completeDocuments(legal?.required_documents))return;
 if(!signedUser){
  legalDraft=documentFingerprint(legal.required_documents);
  prepararLogin();setAuthMode(true);await transicionNormal(pantallaLegal,pantallaLogin);
  mensajeLogin.textContent='Confirma tu cuenta para guardar la aceptación de estos documentos.';return;
 }
 await task(async()=>{
  if(!legal.ready){
   await API.acceptLegal(legal.required_documents);
   legal=await API.getLegal();
   if(!legal.ready){await loadAccount();checkInstrucciones.checked=false;checkEdad.checked=false;actualizarAceptacion();throw Error('Los documentos cambiaron. Revisa las versiones actualizadas y vuelve a aceptar.');}
  }
  await entrarMesaDesde(pantallaLegal);
 },document.getElementById('legal-status'));
}
/* ========================================================= ESTILO DE NUMEROS ========================================================= */
function aplicarEstiloNumero( elemento, numero ) {
elemento.classList.remove(
    "numero-rojo",
    "numero-negro",
    "numero-verde"
);

if (
    numero === null ||
    numero === undefined ||
    numero === ""
) {
    return;
}

const color =
    obtenerColor(numero);

if (color === "ROJO") {

    elemento.classList.add(
        "numero-rojo"
    );

} else if (color === "NEGRO") {

    elemento.classList.add(
        "numero-negro"
    );

} else if (color === "VERDE") {

    elemento.classList.add(
        "numero-verde"
    );

}
}
/* ========================================================= ULTIMOS 10 NUMEROS ========================================================= */
function actualizarHistorialInicial() {
casillasHistorial.forEach(
    (casilla, indice) => {

        casilla.hidden = indice >= initialTarget;
        casilla.disabled = numerosIniciales[indice] === undefined;
        casilla.setAttribute('aria-label', numerosIniciales[indice] === undefined ? `Resultado ${indice+1} vacío` : `Editar resultado ${indice+1}: ${numerosIniciales[indice]}`);
        const numero =
            numerosIniciales[indice];

        casilla.textContent =
            numero !== undefined
                ? String(numero)
                : "";

        aplicarEstiloNumero(
            casilla,
            numero
        );

        casilla.classList.toggle(
            "casilla-ocupada",
            numero !== undefined
        );

    }
);

contadorInicial.textContent =
    `${numerosIniciales.length}/${initialTarget}`;

const completo =
    numerosIniciales.length === initialTarget;

numeroRuleta.disabled = completo;

botonAgregar.disabled = completo;

contenedorIniciarSesion.hidden =
    !completo;

if (numerosIniciales.length === 0) {

    mensajeInicial.textContent =
        "Toca el primer resultado";

} else if (!completo) {

    const faltan = initialTarget - numerosIniciales.length;

    mensajeInicial.textContent =
        `Faltan ${faltan} resultados`;

} else {

    mensajeInicial.textContent =
        "Listo. Puedes abrir tu mesa.";

    pulsoElemento(
        contenedorIniciarSesion
    );

    sonidoAcceso();

}
}
function agregarNumeroInicial() {
if(busy)return;
if (numerosIniciales.length >= initialTarget) {
    return;
}

prepararAudio();

const numero =
    normalizarNumero(
        numeroRuleta.value
    );

if (numero === null) {

    mensajeInicial.textContent =
        "NUMERO NO VALIDO";

    pulsoElemento(
        numeroRuleta
    );

    sonidoError();

    numeroRuleta.select();

    return;

}

numerosIniciales.push(numero);

numeroRuleta.value = "";

sonidoClick();

actualizarHistorialInicial();

if (numerosIniciales.length < initialTarget) {

    if(!document.documentElement.classList.contains("quick-entry"))numeroRuleta.focus();

}
}
function editarNumeroInicial(index){
 if(busy||numerosIniciales[index]===undefined)return;
 const dialog=document.getElementById('edit-result');
 document.getElementById('edit-result-title').textContent=`Corregir resultado ${index+1}`;
 const input=document.getElementById('edit-result-value');input.value=String(numerosIniciales[index]);
 document.getElementById('edit-result-status').textContent='Solo se modifica esta posición; el orden se conserva.';
 document.getElementById('edit-result-form').onsubmit=e=>{e.preventDefault();const n=normalizarNumero(input.value);if(n===null){document.getElementById('edit-result-status').textContent='Escribe 0, 00 o un número del 1 al 36.';input.focus();return;}numerosIniciales[index]=n;actualizarHistorialInicial();dialog.close();};
 document.getElementById('delete-result').onclick=()=>{eliminarNumeroInicial(index);dialog.close();};
 document.getElementById('cancel-edit-result').onclick=()=>dialog.close();dialog.showModal();
}
function eliminarNumeroInicial(indice) {
if (
    indice < 0 ||
    indice >= numerosIniciales.length
) {
    return;
}

prepararAudio();

numerosIniciales.splice(
    indice,
    1
);

sonidoClick();

actualizarHistorialInicial();

numeroRuleta.disabled = false;

botonAgregar.disabled = false;

if(!document.documentElement.classList.contains("quick-entry"))numeroRuleta.focus();
}
/* ========================================================= HISTORIAL SESION ACTIVA ========================================================= */
function actualizarHistorialSesion() {
const ultimos =
    historialCompleto.slice(-5);

const espacios =
    5 - ultimos.length;

girosSesion.forEach(
    (giro, indice) => {

        const indiceNumero =
            indice - espacios;

        if (indiceNumero < 0) {

            giro.textContent = "";

            aplicarEstiloNumero(
                giro,
                null
            );

            return;

        }

        const numero =
            ultimos[indiceNumero];

        giro.textContent =
            String(numero);

        aplicarEstiloNumero(
            giro,
            numero
        );

    }
);
}
/* ========================================================= REINICIO POR VERDE ========================================================= */

/* ========================================================= AUSENCIAS ========================================================= */


/* ========================================================= MEJOR OPCION ========================================================= */


/* ========================================================= APUESTA DETECTADA ========================================================= */

/* ========================================================= COMPROBAR RESULTADO DE APUESTA ========================================================= */

/* ========================================================= PANEL DE ANALISIS ========================================================= */
function limpiarClasesSenal( elemento ) {
elemento.classList.remove(
    "senal-3",
    "senal-5"
);
}

function limpiarResultadosAnalisis() {
resultadoColor.textContent = "-";

resultadoMitades.textContent = "-";

resultadoParidad.textContent = "-";

limpiarClasesSenal(
    opcionColor
);

limpiarClasesSenal(
    opcionMitades
);

limpiarClasesSenal(
    opcionParidad
);
}

/* ========================================================= ESTADOS VISUALES ========================================================= */
const CLASES_ESTADO = [
"estado-esperar",
"estado-condicion",
"estado-entrada",
"estado-intento-1",
"estado-intento-2",
"estado-ultimo",
"estado-ganada",
"estado-cierre"
];
function limpiarEstadosVisuales() {
CLASES_ESTADO.forEach(
    (clase) => {

        panelEstado.classList.remove(
            clase
        );

        contenidoSesionActiva.classList.remove(
            clase
        );

    }
);
}
function establecerEstadoVisual( estado, { titulo = "ESPERAR", descripcion = "ANALIZANDO LA MESA", indicador = "EN ESPERA" } = {} ) {
const estadoAnterior =
    estadoVisualActual;

estadoVisualActual = estado;

limpiarEstadosVisuales();

const mapaClases = {

    ESPERAR:
        "estado-esperar",

    CONDICION:
        "estado-condicion",

    ENTRADA:
        "estado-entrada",

    INTENTO_1:
        "estado-intento-1",

    INTENTO_2:
        "estado-intento-2",

    ULTIMO:
        "estado-ultimo",

    GANADA:
        "estado-ganada",

    CIERRE:
        "estado-cierre"

};

const clase =
    mapaClases[estado] ||
    "estado-esperar";

panelEstado.classList.add(
    clase
);

contenidoSesionActiva.classList.add(
    clase
);

textoEstado.textContent =
    titulo;

descripcionEstado.textContent =
    descripcion;

nivelSenal.textContent =
    indicador;

nivelSenal.classList.remove(
    "nivel-espera",
    "nivel-condicion",
    "nivel-entrada",
    "nivel-intento",
    "nivel-ganada",
    "nivel-cierre"
);

if (estado === "CONDICION") {

    nivelSenal.classList.add(
        "nivel-condicion"
    );

    if (
        estadoAnterior !==
        "CONDICION"
    ) {

        sonidoCondicion();

    }

} else if (
    estado === "ENTRADA"
) {

    nivelSenal.classList.add(
        "nivel-entrada"
    );

    if (
        estadoAnterior !==
        "ENTRADA"
    ) {

        sonidoEntrada();

        crearImpacto();

    }

} else if (
    estado === "INTENTO_1" ||
    estado === "INTENTO_2" ||
    estado === "ULTIMO"
) {

    nivelSenal.classList.add(
        "nivel-intento"
    );

} else if (
    estado === "GANADA"
) {

    nivelSenal.classList.add(
        "nivel-ganada"
    );

} else if (
    estado === "CIERRE"
) {

    nivelSenal.classList.add(
        "nivel-cierre"
    );

} else {

    nivelSenal.classList.add(
        "nivel-espera"
    );

}
}
/* ========================================================= ANALIZAR MESA ========================================================= */
function analizarMesa(){if(remote)renderRemote();}
  /* ========================================================= INTENTOS ========================================================= */
function actualizarIntentoVisual(){numeroIntento.textContent="0/4";}
/* ========================================================= EFECTOS ========================================================= */
function pulsoElemento(elemento) {
if (!elemento) {
    return;
}

elemento.classList.remove(
    "pulso-elemento"
);

void elemento.offsetWidth;

elemento.classList.add(
    "pulso-elemento"
);

setTimeout(() => {

    elemento.classList.remove(
        "pulso-elemento"
    );

}, 500);
}
function crearImpacto() {
const impacto =
    document.createElement("span");

impacto.className =
    "impacto-global";

capaEfectos.appendChild(
    impacto
);

setTimeout(() => {

    impacto.remove();

}, 900);
}
function crearParticulasAcceso() {
for (
    let i = 0;
    i < 18;
    i++
) {

    const particula =
        document.createElement("span");

    particula.className =
        "particula-acceso";

    particula.style.setProperty(
        "--x",
        `${Math.random() * 100}%`
    );

    particula.style.setProperty(
        "--delay",
        `${Math.random() * 0.35}s`
    );

    particula.style.setProperty(
        "--duracion",
        `${0.8 + Math.random() * 0.8}s`
    );

    capaEfectos.appendChild(
        particula
    );

    setTimeout(() => {

        particula.remove();

    }, 1900);

}
}
function crearParticulasGanada() {
for (
    let i = 0;
    i < 28;
    i++
) {

    const particula =
        document.createElement("span");

    particula.className =
        "particula-ganada";

    particula.style.setProperty(
        "--x",
       `${Math.random() * 100}%`
    );

    particula.style.setProperty(
        "--desplazamiento",
       `${-90 + Math.random() * 180}px`
    );

    particula.style.setProperty(
        "--delay",
       `${Math.random() * 0.35}s`
    );

    particula.style.setProperty(
        "--duracion",
       `${0.8 + Math.random() * 1.1}s`
    );

    capaEfectos.appendChild(
        particula
    );

    setTimeout(() => {

        particula.remove();

    }, 2300);

}
}
/* ========================================================= CONFIRMAR APUESTA ========================================================= */
async function confirmarApuesta(){const active=remote?.state.signals.find(s=>s.status==='active'&&!remote.state.attempts.some(a=>a.signalId===s.id&&a.status==='pending'));if(active)await confirmSignal(active.id);}
/* ========================================================= CERRAR SECUENCIA ========================================================= */

/* ========================================================= PROCESAR RESULTADO DE APUESTA ========================================================= */

/* ========================================================= AGREGAR RESULTADO EN SESION ========================================================= */
async function agregarNumeroSesion(){if(busy)return;await task(async()=>{const value=normalizeNumber(numeroSesion.value);numeroSesion.disabled=true;botonAgregarSesion.disabled=true;try{await operate('spin',{value});numeroSesion.value='';sonidoClick();renderRemote();}finally{numeroSesion.disabled=false;botonAgregarSesion.disabled=false;if(!document.documentElement.classList.contains("quick-entry"))numeroSesion.focus();}},mensajeSesion);}
/* ========================================================= INICIAR SESION ACTIVA ========================================================= */
async function iniciarSesionActiva(){if(numerosIniciales.length!==initialTarget)return;await task(async()=>{await operate('seed_history',{values:numerosIniciales.map(String)});sonidoInicio();await transicionNormal(pantallaSesion,pantallaSesionActiva);renderRemote();},mensajeInicial);}
/* ========================================================= EVENTOS ========================================================= */
/* PORTADA */
botonIniciar.addEventListener( "click", abrirLoginConRuleta );
/* LOGIN */
botonLogin.addEventListener( "click", intentarLogin );
botonVerClave.addEventListener( "click", alternarClave );
loginUsuario.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        loginClave.focus();

    }

}
);
loginClave.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {
        if(recoveryMode){document.getElementById('save-password')?.click();return;}
        if (loginPanel.classList.contains('is-registering')) {
            document.getElementById('signup').click();
        } else {
            intentarLogin();
        }
    }

}
);
loginUsuario.addEventListener("input", () => { if (!busy) mensajeLogin.textContent = ""; });
loginClave.addEventListener("input", () => { if (!busy) mensajeLogin.textContent = ""; });
/* INSTRUCCIONES */
checkInstrucciones.addEventListener( "change", actualizarAceptacion );
checkEdad.addEventListener("change",actualizarAceptacion);
botonContinuarInstrucciones.addEventListener( "click", continuarDesdeInstrucciones );
botonAceptarLegal.addEventListener("click", continuarDesdeLegal);
document.getElementById("volver-tutorial").addEventListener("click", ()=>transicionNormal(pantallaLegal,signedUser?pantallaInstrucciones:pantallaInicio));
/* 10 NUMEROS */
botonAgregar.addEventListener( "click", agregarNumeroInicial );
numeroRuleta.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        agregarNumeroInicial();

    }

}
);
casillasHistorial.forEach( (casilla, indice) => {
    casilla.addEventListener(
        "click",
        () => {

            editarNumeroInicial(indice);

        }
    );

}
);
botonIniciarSesion.addEventListener( "click", iniciarSesionActiva );
/* SESION ACTIVA */
confirmarAnalisis.addEventListener( "click", confirmarApuesta );
botonAgregarSesion.addEventListener( "click", agregarNumeroSesion );
numeroSesion.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        agregarNumeroSesion();

    }

}
);
/* ========================================================= MICROINTERACCIONES ========================================================= */
const botonesInteractivos = document.querySelectorAll( "button" );
botonesInteractivos.forEach( (boton) => {
    boton.addEventListener(
        "pointerdown",
        () => {

            prepararAudio();

            boton.classList.add(
                "boton-presionado"
            );

        }
    );


    const liberar = () => {

        boton.classList.remove(
            "boton-presionado"
        );

    };


    boton.addEventListener(
        "pointerup",
        liberar
    );

    boton.addEventListener(
        "pointercancel",
        liberar
    );

    boton.addEventListener(
        "pointerleave",
        liberar
    );

}
);    
/* ========================================================= ESTADO INICIAL ========================================================= */
function prepararEstadoInicial() {
pantallaInicio.hidden = false;

pantallaLogin.hidden = true;

pantallaInstrucciones.hidden = true;
pantallaLegal.hidden = true;

pantallaSesion.hidden = true;

pantallaSesionActiva.hidden = true;

transicionRuleta.hidden = true;

numerosIniciales = [];

historialCompleto = [];

intentoActual = 0;

secuenciaActiva = false;

esperandoResultadoApuesta = false;

apuestaCongelada = null;

cerrandoSecuencia = false;

navegacionBloqueada = false;

estadoVisualActual =
    "ESPERAR";

actualizarHistorialInicial();

actualizarIntentoVisual();

limpiarResultadosAnalisis();
}
prepararEstadoInicial();
/* V16 integration. Domain state is authoritative in Supabase, never editable locally. */
let remote=null, legal=null, signedUser=null, busy=false, adminOffset=0, recoveryMode=false;
let legalDraft=null,publicLegalLoading=false;
const $=id=>document.getElementById(id);
const outboxKey=()=>`rucaleta-v16-outbox-${signedUser.id}`;
let syncState='idle';
function pendingOperation(){if(!signedUser)return null;try{return localStorage.getItem(outboxKey());}catch{throw Error('El navegador bloquea el almacenamiento. Habilítalo antes de registrar resultados.');}}
function syncStatus(state){syncState=state;const bar=$('sync-status');if(!bar)return;bar.dataset.state=state;bar.textContent={idle:'',saving:'Guardando en tu cuenta…',pending:'Envío pendiente de confirmar. Sincroniza antes de añadir otro resultado.',synced:'Historial sincronizado con tu cuenta.'}[state]||'';bar.hidden=state==='idle';}

function element(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function readableError(e){const message=e?.message||'No se pudo completar la operación.';
 const known=[[/REVISION_CONFLICT/,'La sesión cambió en otra pestaña. Ya se actualizó; revisa los resultados antes de continuar.'],[/CURRENT_LEGAL/,'Hay documentos actualizados. Abre «Documentos de uso» en Mi cuenta.'],[/Failed to fetch|NetworkError|Abort|fetch failed/i,'No se pudo confirmar la conexión. Pulsa Sincronizar antes de repetir el resultado.'],[/Invalid login credentials/i,'El correo o la contraseña no son correctos.'],[/Email not confirmed/i,'Confirma tu correo antes de entrar.'],[/USER_BLOCKED|ACCOUNT_BLOCKED/,'Esta cuenta tiene el acceso bloqueado.'],[/AUTH_REQUIRED|JWT expired/i,'Tu sesión venció. Inicia sesión nuevamente.']];
 return known.find(([r])=>r.test(message))?.[1]||message;
}
async function task(fn,status=mensajeSesion){
 if(busy)return;busy=true;document.documentElement.setAttribute('aria-busy','true');
 try{await fn();return true;}catch(e){status.textContent=readableError(e);status.setAttribute('role','alert');sonidoError();return false;}
 finally{busy=false;document.documentElement.removeAttribute('aria-busy');}
}
async function refresh(){remote=await API.analysisApi();return remote;}
function withOperationLock(fn){return navigator.locks?navigator.locks.request(outboxKey(),fn):fn();}
async function reconcile(){return withOperationLock(reconcileUnlocked);}
async function reconcileUnlocked(){const saved=pendingOperation();if(!saved)return;
 const p=JSON.parse(saved);try{remote=await API.analysisApi(p.action,p.payload,p.id,p.revision);localStorage.removeItem(outboxKey());syncStatus('synced');}
 catch(e){if(/REVISION_CONFLICT|INVALID_|INITIAL_HISTORY_RANGE|SIGNAL_NOT_ACTIVE|ATTEMPT_ALREADY_PENDING|ATTEMPTS_EXHAUSTED|CURRENT_LEGAL/.test(e.message)){localStorage.removeItem(outboxKey());syncStatus('idle');await refresh();renderRemote();}else syncStatus('pending');throw e;}
}
async function operate(action,payload){
 const run=async()=>{const saved=pendingOperation();if(saved){const pending=JSON.parse(saved);await reconcileUnlocked();renderRemote();if(pending.action===action&&JSON.stringify(pending.payload)===JSON.stringify(payload))return;throw Error('Se recuperó la operación anterior. Revisa el historial antes de continuar.');}
 const p={action,payload,id:crypto.randomUUID(),revision:remote.revision};
 localStorage.setItem(outboxKey(),JSON.stringify(p));syncStatus('saving');
 const previous=new Map(remote.state.signals.map(s=>[s.id,s.status]));await reconcileUnlocked();
 for(const s of remote.state.signals){if(s.status!==previous.get(s.id)){if(s.status==='won'){sonidoGanada();crearParticulasGanada();}else if(s.status==='lost')sonidoCierre();}}
 renderRemote();};
 return withOperationLock(run);
}
async function loadAccount(){signedUser=await API.userInfo();if(!signedUser)throw Error('Inicia sesión nuevamente.');
 legal=await API.getLegal();renderLegalDocuments();
 $('account-info').textContent=signedUser.email;
 // A queued result must never be replayed (or discarded) before renewed consent.
 // Legal loading also remains independent of analysis availability.
 if(!legal.ready)return;
 await loadPlayerAccount();
}
async function loadPlayerAccount(){
 await refresh();$('account-tools').hidden=false;$('open-admin').hidden=!remote.admin;
 const plan=$('account-plan-status');if(plan)plan.textContent=remote.premium_active?'Tu premium está activo.':'Plan gratuito · '+remote.free_credits_remaining+' créditos disponibles.';try{await reconcile();}finally{renderRemote();}
}

function renderLegalDocuments(){
const holder=$('legal-docs');holder.replaceChildren();
 const available=completeDocuments(legal?.required_documents);
 if(available)$('legal-status').textContent='';
 const documents=available?legal.required_documents:[
 {title:'Términos y condiciones',content_md:'Los términos oficiales se cargarán desde el servidor. Si la consulta pública no está disponible, accede a tu cuenta para leerlos y aceptarlos.'},
 {title:'Política de privacidad',content_md:'La política original se mostrará al consultar los documentos del servidor. No se ha registrado ninguna aceptación.'},
 {title:'Juego responsable',content_md:'El aviso original se mostrará al consultar el servidor. RUCALETA ofrece análisis estadísticos y no garantiza resultados.'}];
 $('legal-auth-load').hidden=available||!!signedUser;
 $('legal-retry').hidden=available;

 // V23: semantic accordions preserve the current server-provided legal document text.
 const iconSpecs={
  terms:[['rect',{x:5,y:3,width:14,height:18,rx:1.3}],['path',{d:'M8 8h8M8 12h8M8 16h6'}]],
  privacy:[['path',{d:'M12 2 20 5v6c0 5.3-3.6 8.5-8 11-4.4-2.5-8-5.7-8-11V5z'}],['rect',{x:9,y:11,width:6,height:6,rx:1}],['path',{d:'M10 11V9a2 2 0 0 1 4 0v2'}]],
  responsible:[['circle',{cx:12,cy:12,r:9}],['path',{d:'M12 5c-.8 2.2-4.5 4.9-4.5 7.4a2.5 2.5 0 0 0 4.2 1.9l.3-.4.3.4a2.5 2.5 0 0 0 4.2-1.9C16.5 9.9 12.8 7.2 12 5Z'}],['path',{d:'M10.5 16h3'}]]
 };
 const iconSvg=(spec,strokeWidth='1.4')=>{
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');
  for(const [k,v] of Object.entries({viewBox:'0 0 24 24',fill:'none',stroke:'currentColor','stroke-width':strokeWidth,'stroke-linecap':'round','stroke-linejoin':'round'}))svg.setAttribute(k,v);
  for(const [name,attrs] of spec){const child=document.createElementNS(ns,name);for(const [key,val] of Object.entries(attrs))child.setAttribute(key,String(val));svg.append(child);}return svg;
 };
 const subtext={terms:'Conoce las reglas de uso de RUCALETA.',privacy:'Cómo protegemos y utilizamos tus datos.',responsible:'Información importante para utilizar el servicio de manera consciente.'};
 for(const d of documents){
  const details=element('details',undefined,'ui-details legal-entry'),title=element('summary'),body=element('div',undefined,'legal-document');
  renderLegalText(body,d.content_md||'');
  const docTitle=d.title.toLocaleLowerCase('es');
  const kind=/privaci|datos persona/.test(docTitle)?'privacy':/responsab|riesgo/.test(docTitle)?'responsible':'terms';
  details.dataset.docType=kind;
  const circle=element('span',undefined,'v23-doc-icon');circle.setAttribute('aria-hidden','true');
  circle.append(iconSvg(iconSpecs[kind]));
  const labels=element('span',undefined,'v23-doc-labels');
  labels.append(element('strong',d.title),element('small',subtext[kind]));
  const chevron=element('span',undefined,'v23-doc-chevron');chevron.setAttribute('aria-hidden','true');
  chevron.append(iconSvg([['path',{d:'m5 9 7 7 7-7'}]],'2'));
  title.append(circle,labels,chevron);
  details.append(title,body);holder.append(details);
 }
 checkInstrucciones.disabled=!available;
 checkEdad.disabled=!available;
 actualizarAceptacion();

}
/** Render legal text as real document structure without trusting backend HTML. */
function renderLegalText(node,source){
 const lines=String(source).replace(/\r/g,'').split('\n');let paragraph=[];let list=null;
 const flush=()=>{if(paragraph.length){node.append(element('p',paragraph.join(' ')));paragraph=[];}list=null;};
 for(const raw of lines){const line=raw.trim();if(!line){flush();continue;}
  const heading=line.match(/^(#{1,5})\s+(.+)$/);
  if(heading){flush();node.append(element(heading[1].length<=2?'h3':'h4',heading[2]));continue;}
  const bullet=line.match(/^(?:[-*] |\d+\. )(.+)$/);
  if(bullet){if(paragraph.length)flush();if(!list){list=element('ul');node.append(list);}list.append(element('li',bullet[1]));continue;}
  if(list)list=null;paragraph.push(line);
 }
 flush();
}
function showRecordTable(node,entries,columns){
 node.replaceChildren();if(!Array.isArray(entries)||!entries.length){node.append(element('p','Todavía no hay registros.','empty-records'));return;}
 const wrap=element('div',undefined,'table-scroll'),table=element('table',undefined,'admin-record-table'),thead=element('thead'),tr=element('tr');
 for(const [name] of columns)tr.append(element('th',name));thead.append(tr);table.append(thead);
 const tbody=element('tbody');for(const item of entries){const row=element('tr');for(const [,key,formatter] of columns){let val=item?.[key];if(formatter)val=formatter(val,item);else if(val===true)val='Sí';else if(val===false)val='No';else if(val&&typeof val==='object')val='Detalles en servidor';const td=element('td',String(val??'—'));td.dataset.label=columns[row.children.length][0];row.append(td);}tbody.append(row);}
 table.append(tbody);wrap.append(table);node.append(wrap);
}
const formatTime=v=>{if(!v)return '—';const date=new Date(v);return Number.isFinite(date.getTime())?date.toLocaleString('es-MX',{year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):String(v);};
const moneyCents=v=>'$'+((Number(v)||0)/100).toLocaleString('es-MX',{minimumFractionDigits:2,maximumFractionDigits:2});
let historyEvents=[],historyPage=0;
function showHistory(events){historyEvents=[...events].reverse();historyPage=0;renderHistoryPage();}
function renderHistoryPage(){const holder=$('history-full');holder.replaceChildren();
 if(!historyEvents.length){holder.append(element('p','Todavía no hay movimientos.','empty-records'));return;}
 const list=element('ol',undefined,'history-timeline');
 for(const e of historyEvents.slice(historyPage*25,(historyPage+1)*25)){
 const row=element('li'),labels={seed_history:'Inicio de mesa',spin:'Resultado',confirm:'Confirmación',new_session:'Nueva sesión'};
 let detail=e.action==='seed_history'?e.payload.values.join(' · '):e.action==='spin'?e.payload.value:e.action==='confirm'?`Importe: ${e.payload.stake}`:'Ventana cerrada; saldo conservado';
 row.append(element('strong',`${labels[e.action]||e.action} · ${detail}`),element('span',`${formatTime(e.at)} · ${Number(e.debit)||0} créditos consumidos`));list.append(row);}
 const nav=element('div',undefined,'dialog-actions'),prev=element('button','Anterior','v16-button'),next=element('button','Siguiente','v16-button');prev.disabled=historyPage===0;next.disabled=(historyPage+1)*25>=historyEvents.length;prev.onclick=()=>{historyPage--;renderHistoryPage();};next.onclick=()=>{historyPage++;renderHistoryPage();};nav.append(prev,element('span',`${historyPage+1} / ${Math.ceil(historyEvents.length/25)}`),next);holder.append(list,nav);
}
function renderRemote(){if(!remote)return;
 const plan=$('account-plan-status');if(plan)plan.textContent=remote.premium_active?'Premium activo · señales ilimitadas':`Plan gratuito · ${remote.free_credits_remaining??'—'} créditos disponibles`;
 const isPremium=remote.premium_active===true;
 const planName=isPremium?'Premium mensual':'Gratuito';
 for(const id of ['v22-home-plan','v22-account-plan'])if($(id))$(id).textContent=planName;
 for(const id of ['v22-home-credits','v22-account-credits'])if($(id))$(id).textContent=`${remote.free_credits_remaining??'—'} créditos`;
 $('v22-premium-badge').textContent=isPremium?'Premium confirmado':'Premium no activo';
 // Renewal date is not exposed by the authenticated V21 projection.
 $('v22-account-renew').textContent='No confirmada';
 const s=remote.state;historialCompleto=s.results.map(r=>r.value==='00'?'00':Number(r.value));actualizarHistorialSesion();
 const remaining=s.window.endSeq===null?0:Math.max(0,s.window.endSeq-s.seq);
 const active=s.signals.filter(x=>x.status==='active');
 renderSignalFeed(s,active);
 if($('recent-result')){const recent=s.results.at(-1);$('recent-result').textContent=recent?`Último resultado: ${recent.value}`:'Registra tu primer giro';}
 if($('app-credit'))$('app-credit').textContent=remote.premium_active?'Premium activo':`${remote.free_credits_remaining??'—'} créditos`;
 $('credit-info').textContent=remote.premium_active?'PREMIUM ILIMITADO':`${remote.free_credits_remaining??'—'} CRÉDITOS`;
 $('window-info').textContent=remaining?`VENTANA · ${remaining}/30`:'ESPERANDO 0 / 00';
 establecerEstadoVisual(active.length?'ENTRADA':'ESPERAR',{titulo:active.length?'Señal activa':'Sin señal activa',descripcion:remaining?`${remaining} giros restantes en esta ventana`:'Registra el siguiente resultado para continuar',indicador:active.length?`${active.length} SEÑALES`:'EN ESPERA'});
 for(const [cat,rowId,outId] of [['color','opcion-color','resultado-color'],['half','opcion-mitades','resultado-mitades'],['parity','opcion-paridad','resultado-paridad']]){
  const sig=active.find(x=>x.category===cat);$(outId).textContent=sig?friendly[sig.target]:'—';$(rowId).querySelector('.v16-signal-actions')?.remove();
 }
 confirmarAnalisis.hidden=true;contenedorConfirmarApuesta.hidden=true;
 confirmarAnalisis.disabled=!active.some(x=>!s.attempts.some(a=>a.signalId===x.id&&a.status==='pending'));
 numeroIntento.textContent=`${Math.max(0,...active.map(x=>s.attempts.filter(a=>a.signalId===x.id).length))}/4`;
 mensajeSesion.textContent=pendingOperation()?'OPERACIÓN PENDIENTE · SINCRONIZA PARA CONTINUAR':remote.free_credits_remaining===0&&!remote.premium_active?'SIN CRÉDITOS · PUEDES SEGUIR REGISTRANDO GIROS':(s.results.length?'Historial actualizado':'Mesa lista · registra el primer resultado');
 $('open-admin').hidden=!remote.admin;
 $('panel-estado').classList.toggle('with-confirmed-signal',active.length>0);
 const windowMeter=$('window-meter');if(windowMeter){windowMeter.value=remaining;windowMeter.setAttribute('aria-valuetext',`${remaining} giros disponibles de 30`);}
 if(pendingOperation())syncStatus('pending');
}
async function confirmSignal(id){await task(async()=>{const attempts=remote.state.attempts.filter(x=>x.signalId===id),scheme=attempts[0]?.scheme||$(`scheme-${id}`)?.value||'A';
 if(attempts.length===3&&!await askConfirmation('Cuarto intento','Este intento no se recomienda. ¿Quieres registrar la confirmación de todos modos?'))return;
 await operate('confirm',{signal_id:id,stake:(scheme==='A'?4:5)*2**attempts.length});if(attempts.length===3)sonidoUltimoIntento();else sonidoConfirmacion();crearImpacto();renderRemote();},mensajeSesion);}
// Add account controls to the existing layout, leaving the cover and original assets intact.
const tools=element('div',undefined,'v16-tools');tools.id='account-tools';tools.hidden=true;
for(const id of ['credit-info','window-info']){const span=element('span');span.id=id;span.className='v16-info-pill';tools.append(span);}
const account=element('button','MI CUENTA','v16-button');account.id='account-button';account.onclick=()=>{openAccountBilling();$('account-dialog').showModal();};tools.append(account);
const recover=element('button','SINCRONIZAR','v16-button');recover.id='sync-now';recover.onclick=()=>task(async()=>{await reconcile();await refresh();renderRemote();syncStatus('synced');});tools.append(recover);
contenidoSesionActiva.prepend(tools);
const syncBar=element('p',undefined,'sync-status');syncBar.id='sync-status';syncBar.setAttribute('role','status');syncBar.hidden=true;tools.after(syncBar);
const meter=element('progress');meter.id='window-meter';meter.max=30;meter.value=0;meter.setAttribute('aria-label','Giros restantes en la ventana');syncBar.after(meter);

// V21: a one-touch number picker. A real server receipt is required before the next tap.
// The native keyboard remains available under an optional disclosure for accessibility.
document.documentElement.classList.add('quick-entry');
function createQuickPicker(target,input,submit){
 const picker=element('div',undefined,'quick-picker');picker.id=target==='initial'?'initial-picker':'live-picker';picker.setAttribute('role','group');picker.setAttribute('aria-label',target==='initial'?'Resultados iniciales, del más antiguo al más reciente':'Elegir resultado de la ruleta');
 for(const value of ['0','00',...Array.from({length:36},(_,i)=>String(i+1))]){
  const b=element('button',value,'pocket');b.type='button';b.dataset.value=value;
  b.dataset.color=value==='0'||value==='00'?'green':(ROJOS.has(Number(value))?'red':'black');
  b.setAttribute('aria-label',`Registrar ${value==='00'?'doble cero':value}`);
  b.onclick=()=>{let pending;try{pending=pendingOperation();}catch(error){(target==='live'?mensajeSesion:mensajeInicial).textContent=readableError(error);return;}if(busy||pending||input.disabled||submit.disabled){if(pending)syncStatus('pending');return;}input.value=value;submit.click();};picker.append(b);
 }
 const wrap=element('div',undefined,'quick-picker-wrap');const hint=element('p',target==='initial'?'Toca los resultados en orden · 0 y 00 incluidos':'Un toque guarda el resultado en tu cuenta','quick-picker-hint');wrap.append(hint,picker);
 const manual=element('details',undefined,'manual-entry'),summary=element('summary','Escribir número manualmente');manual.append(summary);const node=input.parentElement;if(target==='live'){
  const label=node.querySelector('.control-sesion-titulo');if(label)label.textContent='Número manual';
 }else node.classList.add('manual-entry-fields');
 manual.append(node);wrap.append(manual);return wrap;
}
const seedPicker=createQuickPicker('initial',numeroRuleta,botonAgregar);$('historial-numeros').after(seedPicker);
const livePicker=createQuickPicker('live',numeroSesion,botonAgregarSesion);$('panel-estado').before(livePicker);
const signalFeed=element('div',undefined,'primary-signal-feed');signalFeed.id='primary-signal-feed';signalFeed.setAttribute('role','region');signalFeed.setAttribute('aria-label','Señales confirmadas');$('panel-estado').after(signalFeed);
const recent=element('p','Registra tu primer giro','recent-result');recent.id='recent-result';$('historial-sesion').after(recent);
const appCredit=element('span','— créditos','app-credit');appCredit.id='app-credit';$('estado-superior').append(appCredit);
const safetyNote=element('p','Las señales son estadísticas descriptivas; no garantizan un acierto.','player-disclaimer');$('mensaje-sesion').after(safetyNote);
const corrected=element('button','¿Ingresaste un número incorrecto?','correction-link');corrected.id='request-correction';corrected.type='button';corrected.onclick=()=>{const d=$('correction-dialog');if(d)d.showModal();};$('historial-sesion').parentElement.after(corrected);
function renderSignalFeed(s,active){
 const node=$('primary-signal-feed');if(!node)return;node.replaceChildren();node.hidden=!active.length;
 for(const sig of active){
  const attempts=s.attempts.filter(a=>a.signalId===sig.id).sort((a,b)=>a.attemptNumber-b.attemptNumber);
  const pending=attempts.some(a=>a.status==='pending');const next=attempts.length+1;
  const card=element('article',undefined,'player-signal-card');if(next===4)card.classList.add('last-attempt');
  const kicker=element('span','APUESTA A:','signal-kicker');
  const category=element('span',sig.category==='color'?'COLOR':sig.category==='parity'?'PARIDAD':'MITADES','signal-category');
  const target=element('strong',friendly[sig.target]||sig.target,'signal-target');
  const sub=element('p',pending?`Intento ${attempts.length} de 4 · registra el giro para comprobar`:`Señal válida · intento ${Math.min(next,4)} de 4${next===4?' · no recomendado':''}`,'signal-sub');
  const progress=element('div',undefined,'signal-progress');progress.setAttribute('aria-label','Progreso de intentos');
  for(let i=1;i<=4;i++){const a=attempts.find(x=>x.attemptNumber===i),item=element('span',String(i),'signal-step');if(i===4)item.classList.add('purple-step');if(a)item.dataset.status=a.status;else if(i===next)item.dataset.status='next';progress.append(item);}
  card.append(element('h2','SEÑAL ENCONTRADA','signal-headline'),kicker,target,category,sub,progress);
  if(!pending&&next<=4){
   const actions=element('div',undefined,'player-signal-actions'),scheme=element('select');scheme.id=`scheme-${sig.id}`;scheme.setAttribute('aria-label',`Secuencia para ${friendly[sig.target]}`);
   for(const [value,label] of [['A','Secuencia A · 4 / 8 / 16 / 32'],['B','Secuencia B · 5 / 10 / 20 / 40']]){const o=element('option',label);o.value=value;scheme.append(o);}
   if(attempts.length){scheme.value=attempts[0].scheme;scheme.hidden=true;}
   const b=element('button',next===4?'Confirmar cuarto intento':'Confirmar intento','signal-confirm');b.type='button';b.onclick=()=>confirmSignal(sig.id);
   if(next===4)b.classList.add('purple-button');actions.append(scheme,b);card.append(actions);
  }
  node.append(card);
 }
 const latest=s.signals.filter(x=>x.status!=='active').at(-1);
 if(!active.length&&latest&&latest.completedSeq===s.seq){node.hidden=false;const end=element('div',`${friendly[latest.target]||latest.target}: ${latest.status==='won'?'acierto':latest.status==='lost'?'cuatro intentos finalizados':'señal cerrada'}`,'signal-completed');node.append(end);}
}
// Single card, two distinct modes. Nothing related to signup appears under login.
const phone=element('input');phone.id='register-phone';phone.className='v16-phone';phone.type='tel';phone.autocomplete='tel';phone.inputMode='tel';phone.placeholder='+52 000 000 0000';phone.setAttribute('aria-label','Teléfono de contacto');phone.hidden=true;
const phoneLabel=element('label','Teléfono de contacto (opcional, sin verificación SMS)','register-phone-label');phoneLabel.htmlFor='register-phone';phoneLabel.hidden=true;
const confirmField=element('div',undefined,'register-confirm');confirmField.id='register-confirm';confirmField.hidden=true;
const confirmLabel=element('label','Repetir contraseña');confirmLabel.htmlFor='register-confirm-password';
const confirmPassword=element('input');confirmPassword.id='register-confirm-password';confirmPassword.type='password';confirmPassword.autocomplete='new-password';confirmPassword.placeholder='Confirma tu contraseña';confirmField.append(confirmLabel,confirmPassword);confirmPassword.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();if(recoveryMode)$('save-password')?.click();else signup.click();}});
const signup=element('button','Crear cuenta','v16-button');signup.id='signup';signup.type='button';signup.hidden=true;
const reset=element('button','¿Olvidaste tu contraseña?','v16-button button-quiet');reset.id='recover-password';reset.type='button';
const openSignup=element('button','Crear cuenta','auth-tab');openSignup.id='show-signup';openSignup.type='button';
const backLogin=element('button','Iniciar sesión','auth-tab');backLogin.id='show-login';backLogin.type='button';
const tabs=element('div',undefined,'auth-tabs');tabs.setAttribute('role','group');tabs.setAttribute('aria-label','Elegir acceso');tabs.append(backLogin,openSignup);
loginPanel.insertBefore(tabs,loginPanel.querySelector('.login-encabezado'));
const description=loginPanel.querySelector('.login-descripcion');
const authFoot=element('div',undefined,'auth-footer');authFoot.append(reset);
loginPanel.insertBefore(phoneLabel,botonLogin);loginPanel.insertBefore(phone,botonLogin);loginPanel.insertBefore(confirmField,botonLogin);
botonLogin.after(signup);loginPanel.append(authFoot);
function setAuthMode(register){
 loginPanel.classList.toggle('is-registering',register);
 phone.hidden=!register;phoneLabel.hidden=!register;confirmField.hidden=!register;signup.hidden=!register;botonLogin.hidden=register;
 reset.hidden=register;
 backLogin.classList.toggle('is-selected',!register);openSignup.classList.toggle('is-selected',register);
 backLogin.setAttribute('aria-pressed',String(!register));openSignup.setAttribute('aria-pressed',String(register));
 $('auth-heading').textContent=register?'Crear una cuenta':'Iniciar sesión';
 description.textContent=register?'Crea tu acceso con tus datos reales.':'Bienvenido de nuevo. Accede a tu mesa.';
 loginClave.autocomplete=register?'new-password':'current-password';
 mensajeLogin.textContent=register?'Usa una contraseña de al menos 10 caracteres.':'Introduce tus datos para continuar.';
}
openSignup.onclick=()=>setAuthMode(true);backLogin.onclick=()=>setAuthMode(false);setAuthMode(false);
signup.onclick=()=>task(async()=>{
 if(!loginUsuario.value.trim()||!loginUsuario.validity.valid)throw Error('Ingresa un correo electrónico válido.');
 if(loginClave.value.length<10)throw Error('Usa una contraseña de al menos 10 caracteres.');
 if(loginClave.value!==confirmPassword.value)throw Error('Las contraseñas no coinciden.');
 if(phone.value.trim()&&!/^\+?[0-9 ()-]{7,20}$/.test(phone.value.trim()))throw Error('Ingresa un teléfono de contacto válido.');
 await API.signUp(loginUsuario.value.trim(),loginClave.value,phone.value.trim());
 loginClave.value='';confirmPassword.value='';setAuthMode(false);mensajeLogin.textContent='Solicitud recibida. Comprueba tu correo y después inicia sesión.';
},mensajeLogin);
reset.onclick=()=>task(async()=>{if(!loginUsuario.value.trim()||!loginUsuario.validity.valid)throw Error('Escribe primero tu correo electrónico.');await API.requestPasswordReset(loginUsuario.value.trim());mensajeLogin.textContent='Si existe esa cuenta, recibirás un correo con las instrucciones.';},mensajeLogin);
function askConfirmation(title,message){return new Promise(resolve=>{const d=$('request-confirm');$('request-title').textContent=title;$('request-message').textContent=message;d.returnValue='cancel';const close=()=>{d.removeEventListener('close',close);resolve(d.returnValue==='yes');};d.addEventListener('close',close);$('request-yes').onclick=()=>d.close('yes');$('request-cancel').onclick=()=>d.close('cancel');d.showModal();});}
const subscriptionEnabled=$('subscription-form').elements.namedItem('enabled');subscriptionEnabled.onchange=()=>{$('subscription-form').elements.namedItem('expires_at').required=subscriptionEnabled.checked;};
$('close-account').onclick=()=>$('account-dialog').close();$('close-admin').onclick=()=>$('admin-dialog').close();
$('v22-open-premium').onclick=()=>{$('account-dialog').close();$('premium-dialog').showModal();void openAccountBilling();};
$('v22-close-premium').onclick=()=>$('premium-dialog').close();
$('v22-premium-legal').onclick=()=>task(async()=>{await loadAccount();$('premium-dialog').close();prepararInstrucciones();await mostrarPantalla(pantallaLegal);},$('billing-state'));
$('logout').onclick=()=>task(async()=>{try{await API.logout();}finally{location.reload();}} ,$('quote-info'));
$('new-session').onclick=()=>task(async()=>{if(!await askConfirmation('¿Abrir una nueva mesa?','Se cerrarán la ventana y las señales actuales. El historial y tu saldo se conservarán.'))return;await operate('new_session',{});numerosIniciales=[];actualizarHistorialInicial();$('account-dialog').close();await mostrarPantalla(pantallaSesion);},$('quote-info'));
function quoteText(q){return `${q.discount_pct}% de descuento recurrente · $${(q.monthly_cents/100).toFixed(2)} MXN/mes. ${q.applied_code?'Código vinculado: '+q.applied_code+'. ':''}Cobros reales desactivados.`;}
// Billing QA: feature-detected against the same-origin HTTPS proxy. Never grants premium from the client.
async function openAccountBilling(){
 const label=$('billing-state'),buy=$('billing-buy'),refreshButton=$('billing-refresh'),cancelButton=$('billing-cancel');
 buy.hidden=refreshButton.hidden=cancelButton.hidden=true;
 try{
  const cfg=await Billing.capabilities();
  if(!cfg.configured||cfg.mode!=='test'||!cfg.premium_activation){label.textContent='Pagos desactivados hasta configurar el servidor y el puente Premium en QA.';return;}
  const state=await Billing.status();
  refreshButton.hidden=false;
  buy.hidden=state.state!=='none'&&state.state!=='cancelled';
  cancelButton.hidden=!['pending','authorized','paused'].includes(state.state);
  const translations={none:'Aún no hay una suscripción de prueba.',pending:'Suscripción de prueba pendiente de pago.',authorized:'Suscripción autorizada. Solo un pago aprobado activará Premium.',cancelled:'Suscripción cancelada.',paused:'Suscripción pausada.',creation_uncertain:'Creación pendiente de revisión técnica.'};
  label.textContent=(translations[state.state]||'Consulta la suscripción con soporte.')+(state.premium_activated?' Premium activo en QA.':'');
 }catch{label.textContent='El servidor de pagos no está conectado a esta web. Sin cobros habilitados.';}
}
$('billing-refresh').onclick=()=>task(async()=>{await openAccountBilling();await refresh();renderRemote();},$('billing-state'));
$('billing-buy').onclick=()=>task(async()=>{
 if(!await askConfirmation('Suscripción de prueba','Esta función es SOLO para usuarios de prueba de Mercado Pago y RUCALETA-QA. No utilices una tarjeta real. ¿Continuar?'))return;
 const x=await Billing.checkout();const target=new URL(x.checkout_url);
 if(target.protocol!=='https:'||!['www.mercadopago.com.mx','www.mercadopago.com'].includes(target.hostname))throw Error('Enlace de pago no confiable.');
 window.location.assign(target.href);
},$('billing-state'));
$('billing-cancel').onclick=()=>task(async()=>{
 if(!await askConfirmation('Cancelar suscripción de prueba','Se desactivarán las futuras renovaciones. El periodo ya pagado podrá seguir vigente.'))return;
 await Billing.cancel();await openAccountBilling();
},$('billing-state'));

$('quote-code').onclick=()=>task(async()=>{{const q=await API.rpc('rucaleta_v16_quote',{p_code:$('creator-code').value});$('quote-info').textContent=quoteText(q);$('v22-discount').textContent=`${q.discount_pct??0}% · ${moneyCents(q.monthly_cents)}/mes`; }},$('quote-info'));
$('redeem-code').onclick=()=>task(async()=>{if(!$('creator-code').value.trim())throw Error('Escribe un código.');if(!await askConfirmation('Vincular código de creador','El código quedará asociado a tu cuenta para los descuentos recurrentes. No se realizará ningún cobro.'))return;{const q=await API.rpc('rucaleta_v16_redeem',{p_code:$('creator-code').value});$('quote-info').textContent=quoteText(q);$('v22-discount').textContent=`${q.discount_pct??0}% · ${moneyCents(q.monthly_cents)}/mes`; }},$('quote-info'));
$('full-history').onclick=()=>task(async()=>{const r=await API.rpc('rucaleta_v16_read');showHistory(r.events);},$('quote-info'));
async function renderAdmin(action='read',payload={offset:adminOffset}){const d=await API.rpc('rucaleta_v16_admin',{p_action:action,p_payload:payload});
 const stats=$('admin-statistics');stats.replaceChildren();for(const [label,value] of [['Usuarios',d.statistics.users],['Premium activo',d.statistics.premium_active],['Grupos de señales',d.statistics.groups],['Créditos consumidos',d.statistics.credits_used],['Importes conciliados QA',d.statistics.collected_cents==null?'—':moneyCents(d.statistics.collected_cents)],['Comisiones',d.statistics.commissions_cents==null?'—':moneyCents(d.statistics.commissions_cents)]]){
 const metric=element('div',undefined,'metric');metric.append(element('span',label),element('strong',String(value??'—')));stats.append(metric);
 }
 const table=$('admin-users');table.replaceChildren();const head=element('tr');for(const label of ['Usuario','Correo','Créditos','Premium hasta','Bloqueado','Gestionar'])head.append(element('th',label));table.append(head);
 for(const u of d.users){const row=element('tr');for(const value of [u.id,u.email,u.credits,u.enabled?(new Date(u.expires_at)>new Date()?'Activo hasta ':'Vencido · ')+formatTime(u.expires_at):'Inactivo',u.blocked?'Sí':'No'])row.append(element('td',String(value??'—')));const cell=element('td'),choose=element('button','Seleccionar','v16-button');for(const [i,td] of [...row.children].entries())td.dataset.label=['ID','Correo','Créditos','Premium hasta','Bloqueado'][i];cell.dataset.label='Gestionar';choose.onclick=()=>{for(const id of ['subscription-form','block-form'])$(id).elements.namedItem('user_id').value=u.id;$('block-form').elements.namedItem('blocked').checked=!!u.blocked;$('subscription-form').elements.namedItem('enabled').checked=!!u.enabled;subscriptionEnabled.onchange();$('subscription-form').elements.namedItem('expires_at').value='';$('code-form').elements.namedItem('creator_id').value=$('code-form').elements.namedItem('creator_id').readOnly?$('code-form').elements.namedItem('creator_id').value:u.id;if(u.expires_at){const dt=new Date(u.expires_at);$('subscription-form').elements.namedItem('expires_at').value=new Date(dt.getTime()-dt.getTimezoneOffset()*60000).toISOString().slice(0,16);} $('admin-selected-user').textContent=`Usuario seleccionado: ${u.email||u.id}`; $('subscription-form').closest('details').open=true;$('subscription-form').scrollIntoView({block:'nearest'});};cell.append(choose);row.append(cell);table.append(row);} 
 showRecordTable($('admin-codes'),d.codes,[['Código','code'],['Creador','creator_id'],['Descuento','discount_pct',v=>`${v??0}%`],['Comisión','commission_pct',v=>`${v??0}%`],['Activo','active']]);
 const codeTable=$('admin-codes').querySelector('table');if(codeTable){codeTable.querySelector('thead tr').append(element('th','Gestionar'));for(const [i,row] of [...codeTable.querySelectorAll('tbody tr')].entries()){const td=element('td'),edit=element('button','Editar','v16-button');td.dataset.label='Gestionar';edit.onclick=()=>{const c=d.codes[i],f=$('code-form');for(const name of ['code','creator_id','discount_pct','commission_pct'])f.elements.namedItem(name).value=c[name];f.elements.namedItem('active').checked=c.active;f.elements.namedItem('code').readOnly=true;f.elements.namedItem('creator_id').readOnly=true;$('code-edit-status').textContent=`Editando ${c.code}. Se conserva el creador original.`;f.scrollIntoView({block:'nearest'});};td.append(edit);row.append(td);}}

 showRecordTable($('admin-commissions'),d.commissions,[['Creado','created_at',formatTime],['Código','code'],['Importe','net_cents',moneyCents],['Comisión','commission_cents',moneyCents],['Referencia','provider_reference']]);
 showRecordTable($('admin-audit'),d.audit,[['Fecha','at',formatTime],['Acción','action'],['Responsable','actor']]);
 adminOffset=d.offset;$('admin-page').textContent=d.users.length?`Usuarios ${adminOffset+1}–${adminOffset+d.users.length}`:'Sin usuarios en esta página';$('admin-prev').disabled=adminOffset===0;$('admin-next').disabled=d.users.length<50;
 $('admin-status').textContent='Datos reales de QA · Los cobros están desactivados.';filterAdminUsers();
}
function filterAdminUsers(){const q=$('admin-filter').value.trim().toLocaleLowerCase('es');const rows=[...$('admin-users').querySelectorAll('tr')].slice(1);for(const row of rows)row.hidden=q!==''&&!row.textContent.toLocaleLowerCase('es').includes(q);$('admin-filter-status').textContent=q?`${rows.filter(r=>!r.hidden).length} coincidencias en esta página`:'';}
$('admin-filter').oninput=filterAdminUsers;
$('open-admin').onclick=()=>task(async()=>{await renderAdmin();$('account-dialog').close();$('admin-dialog').showModal();},$('quote-info'));
document.addEventListener('rucaleta:admin-refresh',()=>task(()=>renderAdmin(),$('admin-status')));
$('admin-prev').onclick=()=>task(()=>renderAdmin('read',{offset:Math.max(0,adminOffset-50)}),$('admin-status'));
$('admin-next').onclick=()=>task(()=>renderAdmin('read',{offset:adminOffset+50}),$('admin-status'));
$('code-new').onclick=()=>{const f=$('code-form');f.reset();for(const name of ['code','creator_id'])f.elements.namedItem(name).readOnly=false;$('code-edit-status').textContent='Crear un código nuevo.';f.elements.namedItem('code').focus();};
for(const b of document.querySelectorAll('[data-admin-section]'))b.onclick=()=>{const section=$(b.dataset.adminSection);section.open=true;section.scrollIntoView({block:'start',behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});section.querySelector('summary')?.focus();};
for(const [id,action] of [['subscription-form','subscription'],['block-form','block'],['code-form','code']])$(id).onsubmit=e=>{e.preventDefault();task(async()=>{const f=e.currentTarget;if(!f.reportValidity())return;const data=Object.fromEntries(new FormData(f));for(const c of f.querySelectorAll('input[type=checkbox]'))data[c.name]=c.checked;if(action==='subscription'&&data.enabled&&new Date(data.expires_at).getTime()<=Date.now())throw Error('La vigencia de una suscripción activa debe ser futura.');if(action==='subscription'&&!data.enabled&&!data.expires_at)data.expires_at=new Date().toISOString();else if(data.expires_at)data.expires_at=new Date(data.expires_at).toISOString();const detail=action==='subscription'?`${data.enabled?'Activar':'Desactivar'} premium para ${data.user_id}. Vigencia: ${formatTime(data.expires_at)}.`:action==='block'?`${data.blocked?'Bloquear':'Desbloquear'} el acceso de ${data.user_id}.`:`Código ${data.code}: descuento recurrente ${data.discount_pct}%, comisión ${data.commission_pct}%. ${data.active?'Activo':'Inactivo'}. Los vínculos previos conservan las condiciones ya guardadas.`;if(!await askConfirmation('Confirmar cambio en QA',detail))return;await renderAdmin(action,data);$('admin-status').textContent='Cambio guardado y verificado en el servidor QA.';},$('admin-status'));};
function focusScreen(screen){const title=screen.querySelector('h1,h2');if(title){title.tabIndex=-1;title.focus({preventScroll:true});}window.scrollTo?.(0,0);}
const globalNav=element('nav',undefined,'rucaleta-nav');globalNav.setAttribute('aria-label','Navegación de RUCALETA');
const brand=element('div',undefined,'rucaleta-brand'),logo=element('img');logo.src='logo-rucaleta.webp';logo.alt='RUCALETA';logo.width=124;logo.height=36;brand.append(logo);
const menuButton=element('button','☰','rucaleta-menu-button');menuButton.setAttribute('aria-label','Abrir menú');menuButton.id='rucaleta-menu-toggle';menuButton.type='button';menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-controls','rucaleta-menu');
const menu=element('div',undefined,'rucaleta-menu');menu.id='rucaleta-menu';menu.hidden=true;
const back=element('button','← Volver','v16-button'),help=element('button','Guía','v16-button'),profile=element('button','Mi cuenta','v16-button'),mute=element('button','Sonido','v16-button'),historyLink=element('button','Historial','v16-button');
profile.id='global-account';profile.hidden=true;mute.setAttribute('aria-pressed',String(soundEnabled));
function closeAppMenu(){menu.hidden=true;menuButton.setAttribute('aria-expanded','false');}
menuButton.onclick=()=>{if(busy)return;menu.hidden=!menu.hidden;menuButton.setAttribute('aria-expanded',String(!menu.hidden));};
back.onclick=()=>{closeAppMenu();if(busy||navegacionBloqueada||recoveryMode)return;if(!pantallaLogin.hidden){mostrarPantalla(pantallaInicio);}else if(!pantallaLegal.hidden){mostrarPantalla(signedUser?pantallaInstrucciones:pantallaInicio);}else if(signedUser&&legal?.ready){mostrarPantalla(pantallaJugador);}else{mostrarPantalla(pantallaLogin);}};
help.onclick=()=>{closeAppMenu();if(busy)return;$('help-dialog').showModal();};
profile.onclick=()=>{closeAppMenu();openAccountBilling();$('account-dialog').showModal();};
mute.id='sound-toggle';
mute.onclick=()=>{soundEnabled=!soundEnabled;if(soundEnabled){prepararAudio();sonidoClick();}try{localStorage.setItem('rucaleta-sound',soundEnabled?'on':'off');}catch{}mute.setAttribute('aria-pressed',String(soundEnabled));mute.textContent=soundEnabled?'Sonido: activado':'Sonido: silenciado';document.dispatchEvent(new CustomEvent('rucaleta:sound',{detail:soundEnabled}));};
$('v22-preferences').onclick=()=>{mute.click();const label=$('v22-preferences').querySelector('.v24-label')||$('v22-preferences');label.textContent=soundEnabled?'Preferencias · silenciar sonido':'Preferencias · activar sonido';};
historyLink.onclick=()=>{closeAppMenu();$('account-dialog').showModal();$('history-section').open=true;$('full-history').click();};
menu.append(profile,historyLink,help,mute,back);globalNav.append(brand,menuButton,menu);document.body.prepend(globalNav);
const observer=new MutationObserver(()=>{globalNav.hidden=!pantallaInicio.hidden||!pantallaLegal.hidden||!pantallaSesionActiva.hidden;profile.hidden=!signedUser;historyLink.hidden=!signedUser;back.hidden=!pantallaSesionActiva.hidden||!pantallaSesion.hidden;});for(const screen of [pantallaInicio,pantallaLogin,pantallaInstrucciones,pantallaLegal,pantallaJugador,pantallaSesion,pantallaSesionActiva])observer.observe(screen,{attributes:true,attributeFilter:['hidden']});globalNav.hidden=true;
document.addEventListener('pointerdown',e=>{if(!globalNav.contains(e.target))closeAppMenu();});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAppMenu();});
function showPlayerTable(){if(!signedUser||!legal?.ready||busy)return;mostrarPantalla(remote.state.seq>remote.state.sessionStartSeq?pantallaSesionActiva:pantallaSesion);renderRemote();}
function showV22Home(){if(!signedUser||!legal?.ready||busy)return;mostrarPantalla(pantallaJugador);renderRemote();}
function showV22Tutorial(){if(!signedUser||busy)return;mostrarPantalla(pantallaInstrucciones);}
function showV22Account(){if(!signedUser||busy)return;$('account-dialog').showModal();void openAccountBilling();}
function showV22History(){if(!signedUser||busy)return;showV22Account();$('history-section').open=true;$('full-history').click();}
for(const id of ['v22-home-register','v22-nav-register'])$(id).onclick=showPlayerTable;
for(const id of ['v22-home-tutorial','v22-nav-tutorial'])$(id).onclick=showV22Tutorial;
for(const id of ['v22-home-account','v22-nav-account'])$(id).onclick=showV22Account;
$('v22-home-history').onclick=showV22History;
$('v22-nav-home').onclick=showV22Home;
$('v22-already').onclick=()=>{setAuthMode(false);abrirLoginConRuleta('login');};
$('close-help').onclick=()=>$('help-dialog').close();
$('close-correction').onclick=()=>$('correction-dialog').close();$('correction-history').onclick=()=>{$('correction-dialog').close();$('account-dialog').showModal();$('history-section').open=true;$('full-history').click();};$('correction-new-session').onclick=()=>{$('correction-dialog').close();$('account-dialog').showModal();$('new-session').click();};
$('initial-count').onchange=e=>{const target=Number(e.target.value);if(target!==5)return;if(numerosIniciales.length>target){e.target.value=String(initialTarget);mensajeInicial.textContent='Retira los resultados sobrantes antes de cambiar a cinco.';return;}initialTarget=target;actualizarHistorialInicial();};
$('review-documents').onclick=()=>task(async()=>{await loadAccount();$('account-dialog').close();prepararInstrucciones();await mostrarPantalla(pantallaLegal);},$('quote-info'));
window.addEventListener('offline',()=>{$('connection-status').hidden=false;});window.addEventListener('online',()=>{$('connection-status').hidden=true;if(signedUser&&!busy&&pendingOperation())syncStatus('pending');});
$('connection-status').hidden=navigator.onLine!==false;
prepararEstadoInicial();
mountPresentation({home:showV22Home,guide:()=>help.click(),account:showV22Account,sound:()=>mute.click(),soundEnabled:()=>soundEnabled,menu:()=>menuButton.click()});
$('legal-auth-load').onclick=()=>{prepararLogin();setAuthMode(false);mostrarPantalla(pantallaLogin);mensajeLogin.textContent='Accede para cargar los documentos oficiales. Los revisarás antes de entrar a la mesa.';};
$('legal-retry').onclick=()=>signedUser?task(async()=>{await loadAccount();prepararInstrucciones();},$('legal-status')):loadPublicLegal();
try{const recovery=await API.receiveAuthLink();if(recovery){recoveryMode=true;await mostrarPantalla(pantallaLogin);mensajeLogin.textContent='Escribe tu nueva contraseña y pulsa GUARDAR.';botonLogin.hidden=true;signup.hidden=true;reset.hidden=true;phone.hidden=true;phoneLabel.hidden=true;tabs.hidden=true;confirmField.hidden=false;$('auth-heading').textContent='Nueva contraseña';description.textContent='Elige una contraseña de al menos 10 caracteres y confírmala.';loginClave.autocomplete='new-password';loginUsuario.closest('.login-campo').hidden=true;const save=element('button','GUARDAR CONTRASEÑA','v16-button');save.id='save-password';save.onclick=()=>task(async()=>{if(loginClave.value.length<10)throw Error('Usa al menos 10 caracteres.');if(loginClave.value!==confirmPassword.value)throw Error('Las contraseñas no coinciden.');await API.updatePassword(loginClave.value);await API.logout();location.reload();},mensajeLogin);loginPanel.append(save);}
 else if(await API.userInfo()){await loadAccount();if(legal.ready){await refresh();await mostrarPantalla(pantallaJugador);renderRemote();}else{prepararInstrucciones();await mostrarPantalla(pantallaLegal);}}}
catch(e){await mostrarPantalla(pantallaLogin);mensajeLogin.textContent=readableError(e);}

async function loadPublicLegal(){
 if(publicLegalLoading||signedUser)return;
 publicLegalLoading=true;$('legal-status').textContent='Cargando documentos oficiales…';
 try{
  const result=await API.getPublicLegal();
  if(!completeDocuments(result.required_documents))throw Error('Los tres documentos vigentes no están disponibles.');
  // Do not replace authenticated state if sign-in completed during the request.
  if(signedUser)return;
  legal=result;prepararInstrucciones();renderLegalDocuments();$('legal-status').textContent='';
 }catch(error){
  if(signedUser)return;
  legal=null;renderLegalDocuments();
  $('legal-status').textContent='No se pudieron cargar los documentos sin una sesión. Accede para consultar y aceptar los originales antes de entrar a la mesa.';
 }finally{publicLegalLoading=false;}
}
