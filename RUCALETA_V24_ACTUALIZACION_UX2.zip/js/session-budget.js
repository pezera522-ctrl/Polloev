// Manual session ledger only. This module never reads signals or sends an API action.
export const formatMXN = cents => `$${new Intl.NumberFormat('es-MX', {
  minimumFractionDigits: 2, maximumFractionDigits: 2
}).format(cents / 100)} MXN`;

export function parseMXN(value) {
  const raw = String(value).trim();
  if (!/^(?:\d{1,8})(?:[.,]\d{1,2})?$/.test(raw)) return null;
  const [whole, fraction = ''] = raw.replace(',', '.').split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  return Number.isSafeInteger(cents) && cents > 0 ? cents : null;
}

export function remainingMXN(budget, expenses) {
  return budget - expenses.reduce((sum, entry) => sum + entry, 0);
}

export function mountSessionBudget(root, storage = null) {
  const $ = id => root.querySelector(`#${id}`);
  const budgetInput = $('manual-budget'), expenseInput = $('manual-expense');
  const message = $('budget-message'), total = $('budget-total');
  const spent = $('budget-spent'), left = $('budget-left');
  let key = null, state = {budget: null, expenses: []};
  const render = () => {
    total.textContent = state.budget === null ? 'Sin confirmar' : formatMXN(state.budget);
    spent.textContent = formatMXN(state.expenses.reduce((a,b) => a+b, 0));
    left.textContent = state.budget === null ? '—' : formatMXN(remainingMXN(state.budget, state.expenses));
    $('manual-expense-submit').disabled = state.budget === null;
  };
  const save = () => {
    let persisted = false;
    try { if (key && storage) { storage.setItem(key, JSON.stringify(state)); persisted = true; } }
    catch { /* Storage availability is not guaranteed in mobile privacy modes. */ }
    render(); return persisted;
  };
  $('manual-budget-submit').onclick = () => {
    const value = parseMXN(budgetInput.value);
    if (value === null) { message.textContent = 'Introduce un importe válido mayor que cero, en MXN.'; return; }
    if (value < state.expenses.reduce((a,b) => a+b, 0)) {
      message.textContent = 'El presupuesto no puede ser menor que los gastos ya registrados.'; return;
    }
    state.budget = value;
    message.textContent = save() ? 'Presupuesto manual guardado para esta pestaña.' : 'Presupuesto visible solo mientras esta página permanezca abierta.';
  };
  $('manual-expense-submit').onclick = () => {
    const value = parseMXN(expenseInput.value);
    if (state.budget === null || value === null || value > remainingMXN(state.budget, state.expenses)) {
      message.textContent = 'Revisa el importe: no puede superar el saldo disponible.'; return;
    }
    state.expenses.push(value); const persisted = save(); expenseInput.value = '';
    message.textContent = persisted ? 'Gasto manual registrado.' : 'Gasto visible solo mientras esta página permanezca abierta.';
  };
  render();
  return {
    setUser(id) {
      if (!id) return;
      const nextKey = `rucaleta:manual-budget:v1:${id}`;
      if (nextKey === key) return;
      key = nextKey; state = {budget: null, expenses: []};
      try {
        const data = JSON.parse(storage?.getItem(key) || 'null');
        if (data && Number.isSafeInteger(data.budget) && data.budget > 0 &&
            Array.isArray(data.expenses) && data.expenses.every(x => Number.isSafeInteger(x) && x > 0) &&
            remainingMXN(data.budget, data.expenses) >= 0) state = data;
      } catch { /* Corrupt or unavailable storage must not affect the app. */ }
      budgetInput.value = state.budget === null ? '' : (state.budget / 100).toFixed(2);
      message.textContent = 'Registro personal, independiente de créditos y señales.';
      render();
    }
  };
}
