# RUCALETA V24 · UX2 (parche incremental)

Extraer en la carpeta de la V24 actualizada donde está el `index.html` activo.
Sustituir `index.html`, `app.css` y `java.js`; añadir `js/scroll-memory.js`
y `js/session-budget.js`. Los dos archivos `tests/` son verificaciones locales.
No borrar otros archivos. El parche incluye los cambios UX1; no hace falta
instalar UX1 por separado. No es una instalación completa ni contiene fondos.

## Incluido

- Presupuesto de sesión en Mi cuenta: captura voluntaria, confirmación,
  modificación, gasto manual y restante en MXN. Separado de créditos, señales,
  historial y pagos. Persistencia por cuenta y pestaña con sessionStorage; no
  se sincroniza al backend ni a otros dispositivos. Si el navegador restringe
  almacenamiento, la interfaz avisa que el valor solo vive durante la página.
- Memoria de desplazamiento por pantalla, menor espera de navegación, fondo
  oscuro durante la transición, entrada con opacidad/desplazamiento 10 px,
  respuesta táctil de botones y aviso visual del resultado únicamente después
  de concluir su operación. Preferencia de movimiento reducido respetada.
- Profundidad rubí/metal refinada en superficies existentes; sin alterar las
  imágenes originales, ruleta, bola ni tiempos de su animación.

## Expresamente pendiente

El selector de Estrategia A/B sigue en las señales: sus valores alimentan la
confirmación de intentos del motor actual. El presupuesto independiente no
calcula importes de intentos ni reemplaza ese contrato. Tampoco se añadió
promoción de casinos ni recomendación de apuestas.

## QA

Tests locales `node tests/session_budget.mjs`, `node tests/scroll_memory.mjs`
y `npm run test:v24`. Estos validan la lógica de entrada/persistencia y
contratos estáticos con dobles del backend; no constituyen prueba en Safari.
`node tests/browser_mobile.cjs` no pudo arrancar: el ejecutable de Chromium
no está instalado en el entorno. Pendientes: 375/390/393/430 px, teclado
visible, gesto de recarga de Safari, captura visual de todas las pantallas,
Supabase y Mercado Pago reales.

En iPhone: abrir Mi cuenta, confirmar un presupuesto, anotar un gasto y
volver a abrir el diálogo; actualizar la pestaña y comprobar el restante.
Desplazarse abajo en Inicio/Mesa, salir y regresar. En la mesa, registrar un
resultado y observar que solo aparece después de guardarse. Si Safari recarga
con el gesto de arrastre superior, anotar versión exacta de iOS/Safari.
