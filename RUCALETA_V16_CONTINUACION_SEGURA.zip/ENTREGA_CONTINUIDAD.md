# RUCALETA V16 — continuidad segura tras dos interrupciones

## Punto de partida
Se trabajó a partir del archivo `RUCALETA_V16_RULETA_CORREGIDA_PARCIAL.zip` dejado por Work, NO desde un proyecto nuevo. El ZIP parcial original se conserva separado, sin sobrescritura.

## Cambios de esta continuación
- El archivo `index.html` incorpora una organización nueva de cuenta, historial, administración y accesos, además de una pista de bola independiente para la animación.
- `ux-v16.css` es una capa de diseño móvil oscuro/rojo para acceso, tutorial, términos, sesión, premium e interfaz administrativa; corrige la alineación de los campos de contraseña y el botón de visibilidad.
- `java.js` presenta documentos legales y tablas de administración mediante nodos de texto seguros; añade flujo de creación de cuenta y recuperación por correo, e historial legible. Mantiene las llamadas API V16 existentes.
- `style.css` conserva su base de Work y cambia únicamente el origen angular del gradiente para alinear las 38 casillas y sus números.

## Lo que NO se cambió
No se modificaron los módulos `js/`, los archivos `sql/` ni las reglas de señales y créditos. Tampoco se ejecutó SQL, se alteró Supabase QA, GitHub o producción, ni se habilitaron cobros.

## Comprobaciones realizadas
- Comprobación estática del proyecto (`python3 tests/static_checks.py`): correcta.
- Sintaxis JavaScript con `node --check`: correcta.
- Archivos e imágenes vinculados: presentes; ids HTML no duplicados.
- Inspección de diseño a anchos 375, 390, 430 y 768 px: sin desbordamiento horizontal en las pantallas inspeccionadas; campo de contraseña y botón VER corregidos.
- La prueba de interacción completa con doble de API no terminó en este entorno; por ello NO se declara superada.
- No se han comprobado las operaciones en un Supabase QA real ni el flujo en Safari real.

## Abrir y probar
Este proyecto es una versión de laboratorio QA. Para servirlo localmente, desde la carpeta:
`python3 -m http.server 8767`
Abrir `http://localhost:8767` en tu propio navegador. Requiere conexión y credenciales válidas del Supabase QA configurado; no contiene usuarios ficticios de acceso ni simula pagos.

Antes de publicar, probar inicio de sesión, consentimiento, registro de 5 resultados, 0/00, señales, crédito, historial y panel administrador con cuentas QA autorizadas. No ejecutar SQL ni publicar en producción sin revisión separada.
