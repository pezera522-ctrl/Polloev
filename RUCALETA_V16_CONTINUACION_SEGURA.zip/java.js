import * as API from './js/supabase.js';
import {normalizeNumber,friendly} from './js/engine.js';
"use strict";
/* ========================================================= LA RUCALETA JAVA PRINCIPAL ========================================================= */
/* ========================================================= ELEMENTOS GENERALES ========================================================= */
const pantallaInicio = document.getElementById("pantalla-inicio"); const pantallaLogin = document.getElementById("pantalla-login"); const pantallaInstrucciones = document.getElementById("pantalla-instrucciones"); const pantallaSesion = document.getElementById("pantalla-sesion"); const pantallaSesionActiva = document.getElementById("pantalla-sesion-activa");
const overlayTransicion = document.getElementById("overlay-transicion"); const transicionRuleta = document.getElementById("transicion-ruleta"); const ruletaAnimada = document.getElementById("ruleta-animada"); const capaEfectos = document.getElementById("capa-efectos");
/* ========================================================= PORTADA ========================================================= */
const contenedorLogo = document.getElementById("contenedor-logo"); const logoPrincipal = document.getElementById("logo-principal"); const botonIniciar = document.getElementById("boton-iniciar");
/* ========================================================= LOGIN ========================================================= */
const loginPanel = document.getElementById("login-panel"); const loginUsuario = document.getElementById("login-usuario"); const loginClave = document.getElementById("login-clave"); const botonVerClave = document.getElementById("boton-ver-clave"); const botonLogin = document.getElementById("boton-login"); const mensajeLogin = document.getElementById("mensaje-login"); const loginCarga = document.getElementById("login-carga");

/* ========================================================= INSTRUCCIONES ========================================================= */
const checkInstrucciones = document.getElementById("check-instrucciones");
const aceptacionInstrucciones = document.getElementById("aceptacion-instrucciones");
const botonContinuarInstrucciones = document.getElementById("boton-continuar-instrucciones");
/* ========================================================= ULTIMOS 10 NUMEROS ========================================================= */
const contadorInicial = document.getElementById("contador-inicial");
const historialNumeros = document.getElementById("historial-numeros");
const casillasHistorial = Array.from(document.querySelectorAll(".casilla-historial"));
const numeroRuleta = document.getElementById("numero-ruleta");
const botonAgregar = document.getElementById("boton-agregar");
const mensajeInicial = document.getElementById("mensaje-inicial");
const contenedorIniciarSesion = document.getElementById("contenedor-iniciar-sesion");
const botonIniciarSesion = document.getElementById("boton-iniciar-sesion");
/* ========================================================= SESION ACTIVA ========================================================= */
const contenidoSesionActiva = document.getElementById("contenido-sesion-activa");
const contadorIntentos = document.getElementById("contador-intentos");
const numeroIntento = document.getElementById("numero-intento");
const panelEstado = document.getElementById("panel-estado");
const textoEstado = document.getElementById("texto-estado");
const descripcionEstado = document.getElementById("descripcion-estado");
const nivelSenal = document.getElementById("nivel-senal");
const opcionColor = document.getElementById("opcion-color");
const opcionMitades = document.getElementById("opcion-mitades");
const opcionParidad = document.getElementById("opcion-paridad");
const resultadoColor = document.getElementById("resultado-color");
const resultadoMitades = document.getElementById("resultado-mitades");
const resultadoParidad = document.getElementById("resultado-paridad");
const historialSesion = document.getElementById("historial-sesion");
const girosSesion = Array.from(document.querySelectorAll(".giro-sesion"));
const confirmarAnalisis = document.getElementById("confirmar-analisis");
const contenedorConfirmarApuesta = document.getElementById("contenedor-confirmar-apuesta");
const numeroSesion = document.getElementById("numero-sesion");
const botonAgregarSesion = document.getElementById("boton-agregar-sesion");
const mensajeSesion = document.getElementById("mensaje-sesion");
/* ========================================================= RULETA ========================================================= */
const ROJOS = new Set([ 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 ]);
const NEGROS = new Set([ 2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35 ]);
/* ========================================================= ESTADO GENERAL ========================================================= */
let numerosIniciales = [];
let historialCompleto = [];
let intentoActual = 0;
let secuenciaActiva = false;
let esperandoResultadoApuesta = false;
let apuestaCongelada = null;
let estadoVisualActual = "ESPERAR";
let navegacionBloqueada = false;
let cerrandoSecuencia = false;
let audioContext = null;
/* ========================================================= UTILIDADES ========================================================= */
function esperar(ms) {
return new Promise((resolve) => {

    setTimeout(resolve, ms);

});
}
function normalizarNumero(valor) {
const texto = String(valor).trim();

if (texto === "00") {
    return "00";
}

if (!/^\d{1,2}$/.test(texto)) {
    return null;
}

const numero = Number(texto);

if (!Number.isInteger(numero)) {
    return null;
}

if (numero < 0 || numero > 36) {
    return null;
}

return numero;
}
function esVerde(numero) {
return numero === 0 || numero === "00";
}
function obtenerColor(numero) {
if (esVerde(numero)) {
    return "VERDE";
}

if (ROJOS.has(numero)) {
    return "ROJO";
}

if (NEGROS.has(numero)) {
    return "NEGRO";
}

return null;
}
function obtenerParidad(numero) {
if (esVerde(numero)) {
    return null;
}

return numero % 2 === 0 ? "PAR" : "IMPAR";
}
function obtenerMitad(numero) {
if (esVerde(numero)) {
    return null;
}

if (numero >= 1 && numero <= 18) {
    return "1-18";
}

if (numero >= 19 && numero <= 36) {
    return "19-36";
}

return null;
}
/* ========================================================= AUDIO ========================================================= */
function prepararAudio() {
try {

    if (!audioContext) {

        const AudioContext =
            window.AudioContext ||
            window.webkitAudioContext;

        if (!AudioContext) {
            return;
        }

        audioContext = new AudioContext();

    }

    if (audioContext.state === "suspended") {

        audioContext.resume();

    }

} catch (error) {

    console.warn("Audio no disponible");

}
}
function tono({
     frecuencia = 440, 
     duracion = 0.08,
      volumen = 0.035,
       tipo = "sine",
        retraso = 0 } = {}) {
if (!audioContext) {
    return;
}

try {

    const inicio =
        audioContext.currentTime + retraso;

    const oscilador =
        audioContext.createOscillator();

    const ganancia =
        audioContext.createGain();

    oscilador.type = tipo;

    oscilador.frequency.setValueAtTime(
        frecuencia,
        inicio
    );

    ganancia.gain.setValueAtTime(
        0.0001,
        inicio
    );

    ganancia.gain.exponentialRampToValueAtTime(
        volumen,
        inicio + 0.015
    );

    ganancia.gain.exponentialRampToValueAtTime(
        0.0001,
        inicio + duracion
    );

    oscilador.connect(ganancia);

    ganancia.connect(audioContext.destination);

    oscilador.start(inicio);

    oscilador.stop(
        inicio + duracion + 0.03
    );
    } catch (error) {

    console.warn("No se pudo reproducir sonido");

}
}
function sonidoClick() {
tono({
    frecuencia: 310,
    duracion: 0.055,
    volumen: 0.025,
    tipo: "triangle"
});

tono({
    frecuencia: 520,
    duracion: 0.07,
    volumen: 0.018,
    tipo: "sine",
    retraso: 0.025
});
}
function sonidoInicio() {
tono({
    frecuencia: 180,
    duracion: 0.13,
    volumen: 0.035,
    tipo: "sine"
});

tono({
    frecuencia: 360,
    duracion: 0.16,
    volumen: 0.028,
    tipo: "triangle",
    retraso: 0.07
});

tono({
    frecuencia: 620,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.15
});
}
function sonidoRuleta() {
tono({
    frecuencia: 110,
    duracion: 0.55,
    volumen: 0.03,
    tipo: "sawtooth"
});

tono({
    frecuencia: 170,
    duracion: 0.45,
    volumen: 0.018,
    tipo: "triangle",
    retraso: 0.18
});
}
function sonidoAcceso() {
tono({
    frecuencia: 390,
    duracion: 0.09,
    volumen: 0.03,
    tipo: "triangle"
});

tono({
    frecuencia: 560,
    duracion: 0.12,
    volumen: 0.025,
    tipo: "triangle",
    retraso: 0.08
});

tono({
    frecuencia: 790,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.16
});
}
function sonidoError() {
tono({
    frecuencia: 150,
    duracion: 0.12,
    volumen: 0.035,
    tipo: "square"
});

tono({
    frecuencia: 115,
    duracion: 0.16,
    volumen: 0.025,
    tipo: "square",
    retraso: 0.1
});
}
function sonidoCondicion() {
tono({
    frecuencia: 290,
    duracion: 0.12,
    volumen: 0.03,
    tipo: "triangle"
});

tono({
    frecuencia: 410,
    duracion: 0.15,
    volumen: 0.024,
    tipo: "triangle",
    retraso: 0.08
});
}
function sonidoEntrada() {
tono({
    frecuencia: 360,
    duracion: 0.11,
    volumen: 0.035,
    tipo: "triangle"
});

tono({
    frecuencia: 620,
    duracion: 0.18,
    volumen: 0.027,
    tipo: "sine",
    retraso: 0.08
});
}
function sonidoConfirmacion() {
tono({
    frecuencia: 240,
    duracion: 0.07,
    volumen: 0.035,
    tipo: "square"
});

tono({
    frecuencia: 480,
    duracion: 0.11,
    volumen: 0.025,
    tipo: "triangle",
    retraso: 0.06
});
}
function sonidoUltimoIntento() {
tono({
    frecuencia: 170,
    duracion: 0.16,
    volumen: 0.04,
    tipo: "sawtooth"
});

tono({
    frecuencia: 220,
    duracion: 0.16,
    volumen: 0.032,
    tipo: "sawtooth",
    retraso: 0.14
});

tono({
    frecuencia: 300,
    duracion: 0.2,
    volumen: 0.026,
    tipo: "triangle",
    retraso: 0.28
});
}
function sonidoGanada() {
tono({
    frecuencia: 420,
    duracion: 0.13,
    volumen: 0.035,
    tipo: "triangle"
});

tono({
    frecuencia: 620,
    duracion: 0.16,
    volumen: 0.032,
    tipo: "triangle",
    retraso: 0.1
});

tono({
    frecuencia: 850,
    duracion: 0.24,
    volumen: 0.027,
    tipo: "sine",
    retraso: 0.2
});
}
function sonidoCierre() {
tono({
    frecuencia: 320,
    duracion: 0.11,
    volumen: 0.027,
    tipo: "triangle"
});

tono({
    frecuencia: 210,
    duracion: 0.18,
    volumen: 0.022,
    tipo: "sine",
    retraso: 0.1
});
}
/* ========================================================= NAVEGACION ========================================================= */
function ocultarPantallas() {
pantallaInicio.hidden = true;
pantallaLogin.hidden = true;
pantallaInstrucciones.hidden = true;
pantallaSesion.hidden = true;
pantallaSesionActiva.hidden = true;
}
async function mostrarPantalla( pantalla, claseEntrada = "pantalla-entrando" ) {
ocultarPantallas();

pantalla.hidden = false;

pantalla.classList.remove(
    "pantalla-entrando",
    "pantalla-entrando-profunda",
    "pantalla-saliendo"
);

void pantalla.offsetWidth;

pantalla.classList.add(claseEntrada);

await esperar(650);

pantalla.classList.remove(claseEntrada);
}
async function transicionNormal( pantallaActual, pantallaSiguiente ) {
if (navegacionBloqueada) {
    return;
}

navegacionBloqueada = true;

overlayTransicion.classList.add(
    "overlay-activo"
);

pantallaActual.classList.add(
    "pantalla-saliendo"
);

await esperar(420);

pantallaActual.hidden = true;
pantallaActual.classList.remove(
    "pantalla-saliendo"
);

pantallaSiguiente.hidden = false;

pantallaSiguiente.classList.add(
    "pantalla-entrando"
);

await esperar(180);

overlayTransicion.classList.remove(
    "overlay-activo"
);

await esperar(500);

pantallaSiguiente.classList.remove(
    "pantalla-entrando"
);

navegacionBloqueada = false;
}
/* ========================================================= TRANSICION DE RULETA PORTADA -> LOGIN ========================================================= */
async function abrirLoginConRuleta() {
if (navegacionBloqueada) {
    return;
}

navegacionBloqueada = true;

prepararAudio();

sonidoInicio();

botonIniciar.disabled = true;

contenedorLogo.classList.add(
    "logo-preparando-salida"
);

botonIniciar.classList.add(
    "boton-preparando-salida"
);

await esperar(260);

transicionRuleta.hidden = false;

void transicionRuleta.offsetWidth;

transicionRuleta.classList.add(
    "ruleta-transicion-activa"
);

sonidoRuleta();

await esperar(1100);

pantallaInicio.hidden = true;

prepararLogin();

pantallaLogin.hidden = false;

pantallaLogin.classList.add(
    "pantalla-login-revelada"
);

await esperar(420);

transicionRuleta.classList.add(
    "ruleta-transicion-final"
);

await esperar(650);

transicionRuleta.hidden = true;

transicionRuleta.classList.remove(
    "ruleta-transicion-activa",
    "ruleta-transicion-final"
);

pantallaLogin.classList.remove(
    "pantalla-login-revelada"
);

contenedorLogo.classList.remove(
    "logo-preparando-salida"
);

botonIniciar.classList.remove(
    "boton-preparando-salida"
);

botonIniciar.disabled = false;

navegacionBloqueada = false;

setTimeout(() => {

    loginUsuario.focus();

}, 150);
}
/* ========================================================= LOGIN ========================================================= */


function prepararLogin() {
loginUsuario.value = "";

loginClave.value = "";

loginClave.type = "password";

botonVerClave.textContent = "VER";

botonLogin.disabled = false;

loginUsuario.disabled = false;

loginClave.disabled = false;

mensajeLogin.textContent =
    "ACCESO REQUERIDO";

loginPanel.classList.remove(
    "login-error",
    "login-correcto",
    "login-validando"
);

loginCarga.classList.remove(
    "login-carga-activa"
);
}
function mostrarErrorLogin( texto = "USUARIO O CLAVE INCORRECTOS" ) {
mensajeLogin.textContent = texto;

loginPanel.classList.remove(
    "login-error"
);

void loginPanel.offsetWidth;

loginPanel.classList.add(
    "login-error"
);

sonidoError();

setTimeout(() => {

    loginPanel.classList.remove(
        "login-error"
    );

}, 650);
}
async function intentarLogin(){
 await task(async()=>{await API.signIn(loginUsuario.value.trim(),loginClave.value);loginClave.value='';await loadAccount();sonidoAcceso();crearParticulasAcceso();prepararInstrucciones();await transicionNormal(pantallaLogin,pantallaInstrucciones);},mensajeLogin);
}
/* ========================================================= MOSTRAR / OCULTAR CLAVE ========================================================= */
function alternarClave() {
prepararAudio();

sonidoClick();

const mostrando =
    loginClave.type === "text";

loginClave.type =
    mostrando
        ? "password"
        : "text";

botonVerClave.textContent =
    mostrando
        ? "VER"
        : "OCULTAR";
}
/* ========================================================= INSTRUCCIONES ========================================================= */
function prepararInstrucciones() {
checkInstrucciones.checked = false;

botonContinuarInstrucciones.disabled = true;

aceptacionInstrucciones.classList.remove(
    "aceptacion-activa"
);
}
function actualizarAceptacion() {
prepararAudio();

const aceptado =
    checkInstrucciones.checked;

botonContinuarInstrucciones.disabled =
    !aceptado;

aceptacionInstrucciones.classList.toggle(
    "aceptacion-activa",
    aceptado
);

if (aceptado) {

    sonidoAcceso();

    pulsoElemento(
        aceptacionInstrucciones
    );

} else {

    sonidoClick();

}
}
async function continuarDesdeInstrucciones(){if(!checkInstrucciones.checked)return;
 await task(async()=>{if(!legal.ready){await API.acceptLegal(legal.required_documents);legal=await API.getLegal();if(!legal.ready)throw Error('No se pudo registrar la aceptación.');}await refresh();await transicionNormal(pantallaInstrucciones,remote.state.seq>remote.state.sessionStartSeq?pantallaSesionActiva:pantallaSesion);renderRemote();},document.getElementById('legal-status'));
}
/* ========================================================= ESTILO DE NUMEROS ========================================================= */
function aplicarEstiloNumero( elemento, numero ) {
elemento.classList.remove(
    "numero-rojo",
    "numero-negro",
    "numero-verde"
);

if (
    numero === null ||
    numero === undefined ||
    numero === ""
) {
    return;
}

const color =
    obtenerColor(numero);

if (color === "ROJO") {

    elemento.classList.add(
        "numero-rojo"
    );

} else if (color === "NEGRO") {

    elemento.classList.add(
        "numero-negro"
    );

} else if (color === "VERDE") {

    elemento.classList.add(
        "numero-verde"
    );

}
}
/* ========================================================= ULTIMOS 10 NUMEROS ========================================================= */
function actualizarHistorialInicial() {
casillasHistorial.forEach(
    (casilla, indice) => {

        const numero =
            numerosIniciales[indice];

        casilla.textContent =
            numero !== undefined
                ? String(numero)
                : "";

        aplicarEstiloNumero(
            casilla,
            numero
        );

        casilla.classList.toggle(
            "casilla-ocupada",
            numero !== undefined
        );

    }
);

contadorInicial.textContent =
    `${numerosIniciales.length}/5`;

const completo =
    numerosIniciales.length === 5;

numeroRuleta.disabled = completo;

botonAgregar.disabled = completo;

contenedorIniciarSesion.hidden =
    !completo;

if (numerosIniciales.length === 0) {

    mensajeInicial.textContent =
        "AGREGA EL PRIMER NUMERO";

} else if (!completo) {

    const faltan = 5 - numerosIniciales.length;

    mensajeInicial.textContent =
        `FALTAN ${faltan} NUMEROS`;

} else {

    mensajeInicial.textContent =
        "MESA PREPARADA";

    pulsoElemento(
        contenedorIniciarSesion
    );

    sonidoAcceso();

}
}
function agregarNumeroInicial() {
if (numerosIniciales.length >= 5) {
    return;
}

prepararAudio();

const numero =
    normalizarNumero(
        numeroRuleta.value
    );

if (numero === null) {

    mensajeInicial.textContent =
        "NUMERO NO VALIDO";

    pulsoElemento(
        numeroRuleta
    );

    sonidoError();

    numeroRuleta.select();

    return;

}

numerosIniciales.push(numero);

numeroRuleta.value = "";

sonidoClick();

actualizarHistorialInicial();

if (numerosIniciales.length < 5) {

    numeroRuleta.focus();

}
}
function eliminarNumeroInicial(indice) {
if (
    indice < 0 ||
    indice >= numerosIniciales.length
) {
    return;
}

prepararAudio();

numerosIniciales.splice(
    indice,
    1
);

sonidoClick();

actualizarHistorialInicial();

numeroRuleta.disabled = false;

botonAgregar.disabled = false;

numeroRuleta.focus();
}
/* ========================================================= HISTORIAL SESION ACTIVA ========================================================= */
function actualizarHistorialSesion() {
const ultimos =
    historialCompleto.slice(-5);

const espacios =
    5 - ultimos.length;

girosSesion.forEach(
    (giro, indice) => {

        const indiceNumero =
            indice - espacios;

        if (indiceNumero < 0) {

            giro.textContent = "";

            aplicarEstiloNumero(
                giro,
                null
            );

            return;

        }

        const numero =
            ultimos[indiceNumero];

        giro.textContent =
            String(numero);

        aplicarEstiloNumero(
            giro,
            numero
        );

    }
);
}
/* ========================================================= REINICIO POR VERDE ========================================================= */

/* ========================================================= AUSENCIAS ========================================================= */


/* ========================================================= MEJOR OPCION ========================================================= */


/* ========================================================= APUESTA DETECTADA ========================================================= */

/* ========================================================= COMPROBAR RESULTADO DE APUESTA ========================================================= */

/* ========================================================= PANEL DE ANALISIS ========================================================= */
function limpiarClasesSenal( elemento ) {
elemento.classList.remove(
    "senal-3",
    "senal-5"
);
}

function limpiarResultadosAnalisis() {
resultadoColor.textContent = "-";

resultadoMitades.textContent = "-";

resultadoParidad.textContent = "-";

limpiarClasesSenal(
    opcionColor
);

limpiarClasesSenal(
    opcionMitades
);

limpiarClasesSenal(
    opcionParidad
);
}

/* ========================================================= ESTADOS VISUALES ========================================================= */
const CLASES_ESTADO = [
"estado-esperar",
"estado-condicion",
"estado-entrada",
"estado-intento-1",
"estado-intento-2",
"estado-ultimo",
"estado-ganada",
"estado-cierre"
];
function limpiarEstadosVisuales() {
CLASES_ESTADO.forEach(
    (clase) => {

        panelEstado.classList.remove(
            clase
        );

        contenidoSesionActiva.classList.remove(
            clase
        );

    }
);
}
function establecerEstadoVisual( estado, { titulo = "ESPERAR", descripcion = "ANALIZANDO LA MESA", indicador = "EN ESPERA" } = {} ) {
const estadoAnterior =
    estadoVisualActual;

estadoVisualActual = estado;

limpiarEstadosVisuales();

const mapaClases = {

    ESPERAR:
        "estado-esperar",

    CONDICION:
        "estado-condicion",

    ENTRADA:
        "estado-entrada",

    INTENTO_1:
        "estado-intento-1",

    INTENTO_2:
        "estado-intento-2",

    ULTIMO:
        "estado-ultimo",

    GANADA:
        "estado-ganada",

    CIERRE:
        "estado-cierre"

};

const clase =
    mapaClases[estado] ||
    "estado-esperar";

panelEstado.classList.add(
    clase
);

contenidoSesionActiva.classList.add(
    clase
);

textoEstado.textContent =
    titulo;

descripcionEstado.textContent =
    descripcion;

nivelSenal.textContent =
    indicador;

nivelSenal.classList.remove(
    "nivel-espera",
    "nivel-condicion",
    "nivel-entrada",
    "nivel-intento",
    "nivel-ganada",
    "nivel-cierre"
);

if (estado === "CONDICION") {

    nivelSenal.classList.add(
        "nivel-condicion"
    );

    if (
        estadoAnterior !==
        "CONDICION"
    ) {

        sonidoCondicion();

    }

} else if (
    estado === "ENTRADA"
) {

    nivelSenal.classList.add(
        "nivel-entrada"
    );

    if (
        estadoAnterior !==
        "ENTRADA"
    ) {

        sonidoEntrada();

        crearImpacto();

    }

} else if (
    estado === "INTENTO_1" ||
    estado === "INTENTO_2" ||
    estado === "ULTIMO"
) {

    nivelSenal.classList.add(
        "nivel-intento"
    );

} else if (
    estado === "GANADA"
) {

    nivelSenal.classList.add(
        "nivel-ganada"
    );

} else if (
    estado === "CIERRE"
) {

    nivelSenal.classList.add(
        "nivel-cierre"
    );

} else {

    nivelSenal.classList.add(
        "nivel-espera"
    );

}
}
/* ========================================================= ANALIZAR MESA ========================================================= */
function analizarMesa(){if(remote)renderRemote();}
  /* ========================================================= INTENTOS ========================================================= */
function actualizarIntentoVisual(){numeroIntento.textContent="0/4";}
/* ========================================================= EFECTOS ========================================================= */
function pulsoElemento(elemento) {
if (!elemento) {
    return;
}

elemento.classList.remove(
    "pulso-elemento"
);

void elemento.offsetWidth;

elemento.classList.add(
    "pulso-elemento"
);

setTimeout(() => {

    elemento.classList.remove(
        "pulso-elemento"
    );

}, 500);
}
function crearImpacto() {
const impacto =
    document.createElement("span");

impacto.className =
    "impacto-global";

capaEfectos.appendChild(
    impacto
);

setTimeout(() => {

    impacto.remove();

}, 900);
}
function crearParticulasAcceso() {
for (
    let i = 0;
    i < 18;
    i++
) {

    const particula =
        document.createElement("span");

    particula.className =
        "particula-acceso";

    particula.style.setProperty(
        "--x",
        `${Math.random() * 100}%`
    );

    particula.style.setProperty(
        "--delay",
        `${Math.random() * 0.35}s`
    );

    particula.style.setProperty(
        "--duracion",
        `${0.8 + Math.random() * 0.8}s`
    );

    capaEfectos.appendChild(
        particula
    );

    setTimeout(() => {

        particula.remove();

    }, 1900);

}
}
function crearParticulasGanada() {
for (
    let i = 0;
    i < 28;
    i++
) {

    const particula =
        document.createElement("span");

    particula.className =
        "particula-ganada";

    particula.style.setProperty(
        "--x",
       `${Math.random() * 100}%`
    );

    particula.style.setProperty(
        "--desplazamiento",
       `${-90 + Math.random() * 180}px`
    );

    particula.style.setProperty(
        "--delay",
       `${Math.random() * 0.35}s`
    );

    particula.style.setProperty(
        "--duracion",
       `${0.8 + Math.random() * 1.1}s`
    );

    capaEfectos.appendChild(
        particula
    );

    setTimeout(() => {

        particula.remove();

    }, 2300);

}
}
/* ========================================================= CONFIRMAR APUESTA ========================================================= */
async function confirmarApuesta(){const active=remote?.state.signals.find(s=>s.status==='active'&&!remote.state.attempts.some(a=>a.signalId===s.id&&a.status==='pending'));if(active)await confirmSignal(active.id);}
/* ========================================================= CERRAR SECUENCIA ========================================================= */

/* ========================================================= PROCESAR RESULTADO DE APUESTA ========================================================= */

/* ========================================================= AGREGAR RESULTADO EN SESION ========================================================= */
async function agregarNumeroSesion(){await task(async()=>{const value=normalizeNumber(numeroSesion.value);await operate('spin',{value});numeroSesion.value='';sonidoClick();renderRemote();numeroSesion.focus();},mensajeSesion);}
/* ========================================================= INICIAR SESION ACTIVA ========================================================= */
async function iniciarSesionActiva(){if(numerosIniciales.length!==5)return;await task(async()=>{await operate('seed_history',{values:numerosIniciales.map(String)});sonidoInicio();await transicionNormal(pantallaSesion,pantallaSesionActiva);renderRemote();},mensajeInicial);}
/* ========================================================= EVENTOS ========================================================= */
/* PORTADA */
botonIniciar.addEventListener( "click", abrirLoginConRuleta );
/* LOGIN */
botonLogin.addEventListener( "click", intentarLogin );
botonVerClave.addEventListener( "click", alternarClave );
loginUsuario.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        loginClave.focus();

    }

}
);
loginClave.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        intentarLogin();

    }

}
);
loginUsuario.addEventListener( "input", () => {
    mensajeLogin.textContent =
        "ACCESO REQUERIDO";

}
);
loginClave.addEventListener( "input", () => {
    mensajeLogin.textContent =
        "ACCESO REQUERIDO";

}
);
/* INSTRUCCIONES */
checkInstrucciones.addEventListener( "change", actualizarAceptacion );
botonContinuarInstrucciones.addEventListener( "click", continuarDesdeInstrucciones );
/* 10 NUMEROS */
botonAgregar.addEventListener( "click", agregarNumeroInicial );
numeroRuleta.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        agregarNumeroInicial();

    }

}
);
casillasHistorial.forEach( (casilla, indice) => {
    casilla.addEventListener(
        "click",
        () => {

            eliminarNumeroInicial(
                indice
            );

        }
    );

}
);
botonIniciarSesion.addEventListener( "click", iniciarSesionActiva );
/* SESION ACTIVA */
confirmarAnalisis.addEventListener( "click", confirmarApuesta );
botonAgregarSesion.addEventListener( "click", agregarNumeroSesion );
numeroSesion.addEventListener( "keydown", (evento) => {
    if (evento.key === "Enter") {

        agregarNumeroSesion();

    }

}
);
/* ========================================================= MICROINTERACCIONES ========================================================= */
const botonesInteractivos = document.querySelectorAll( "button" );
botonesInteractivos.forEach( (boton) => {
    boton.addEventListener(
        "pointerdown",
        () => {

            prepararAudio();

            boton.classList.add(
                "boton-presionado"
            );

        }
    );


    const liberar = () => {

        boton.classList.remove(
            "boton-presionado"
        );

    };


    boton.addEventListener(
        "pointerup",
        liberar
    );

    boton.addEventListener(
        "pointercancel",
        liberar
    );

    boton.addEventListener(
        "pointerleave",
        liberar
    );

}
);    
/* ========================================================= ESTADO INICIAL ========================================================= */
function prepararEstadoInicial() {
pantallaInicio.hidden = false;

pantallaLogin.hidden = true;

pantallaInstrucciones.hidden = true;

pantallaSesion.hidden = true;

pantallaSesionActiva.hidden = true;

transicionRuleta.hidden = true;

numerosIniciales = [];

historialCompleto = [];

intentoActual = 0;

secuenciaActiva = false;

esperandoResultadoApuesta = false;

apuestaCongelada = null;

cerrandoSecuencia = false;

navegacionBloqueada = false;

estadoVisualActual =
    "ESPERAR";

actualizarHistorialInicial();

actualizarIntentoVisual();

limpiarResultadosAnalisis();
}
prepararEstadoInicial();
/* V16 integration. Domain state is authoritative in Supabase, never editable locally. */
let remote=null, legal=null, signedUser=null, busy=false, adminOffset=0;
const $=id=>document.getElementById(id);
const outboxKey=()=>`rucaleta-v16-outbox-${signedUser.id}`;
function element(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
async function task(fn,status=mensajeSesion){
 if(busy)return;busy=true;document.documentElement.setAttribute('aria-busy','true');
 try{await fn();}catch(e){status.textContent=e.message||'No se pudo completar la operación.';sonidoError();}
 finally{busy=false;document.documentElement.removeAttribute('aria-busy');}
}
async function refresh(){remote=await API.analysisApi();return remote;}
async function reconcile(){const saved=localStorage.getItem(outboxKey());if(!saved)return;
 const p=JSON.parse(saved);try{remote=await API.analysisApi(p.action,p.payload,p.id,p.revision);localStorage.removeItem(outboxKey());}
 catch(e){if(/REVISION_CONFLICT|INVALID_|SIGNAL_NOT_ACTIVE|ATTEMPT_ALREADY_PENDING|ATTEMPTS_EXHAUSTED|CURRENT_LEGAL/.test(e.message)){localStorage.removeItem(outboxKey());await refresh();}throw e;}
}
async function operate(action,payload){
 const run=async()=>{if(localStorage.getItem(outboxKey())){await reconcile();throw Error('Se recuperó la operación anterior. Revisa el historial antes de continuar.');}
 const p={action,payload,id:crypto.randomUUID(),revision:remote.revision};
 localStorage.setItem(outboxKey(),JSON.stringify(p));
 const previous=new Map(remote.state.signals.map(s=>[s.id,s.status]));await reconcile();
 for(const s of remote.state.signals){if(s.status!==previous.get(s.id)){if(s.status==='won'){sonidoGanada();crearParticulasGanada();}else if(s.status==='lost')sonidoCierre();}}
 renderRemote();};
 if(navigator.locks)return navigator.locks.request(outboxKey(),run);return run();
}
async function loadAccount(){signedUser=await API.userInfo();if(!signedUser)throw Error('Inicia sesión nuevamente.');
 legal=await API.getLegal();const holder=$('legal-docs');holder.replaceChildren();
 const heading=element('div',undefined,'legal-docs-heading');heading.append(element('h2','Documentos de uso'),element('p','Consulta los documentos vigentes antes de aceptar. Puedes abrir cada sección para leerla.'));
 holder.append(heading);
 for(const d of legal.required_documents){const details=element('details',undefined,'ui-details legal-entry'),title=element('summary',d.title),body=element('div',undefined,'legal-document');
 renderLegalText(body,d.content_md||'');details.append(title,body);holder.append(details);}
 if(!legal.required_documents.length){holder.append(element('p','No se recibieron documentos legales del servidor.','ui-feedback'));}
 checkInstrucciones.disabled=!legal.required_documents.length&&!legal.ready;

 await refresh();$('account-tools').hidden=false;$('open-admin').hidden=!remote.admin;
 $('account-info').textContent=signedUser.email;try{await reconcile();}finally{renderRemote();}
}
/** Render legal text as real document structure without trusting backend HTML. */
function renderLegalText(node,source){
 const lines=String(source).replace(/\r/g,'').split('\n');let paragraph=[];let list=null;
 const flush=()=>{if(paragraph.length){node.append(element('p',paragraph.join(' ')));paragraph=[];}list=null;};
 for(const raw of lines){const line=raw.trim();if(!line){flush();continue;}
  const heading=line.match(/^(#{1,5})\s+(.+)$/);
  if(heading){flush();node.append(element(heading[1].length<=2?'h3':'h4',heading[2]));continue;}
  const bullet=line.match(/^(?:[-*] |\d+\. )(.+)$/);
  if(bullet){if(paragraph.length)flush();if(!list){list=element('ul');node.append(list);}list.append(element('li',bullet[1]));continue;}
  if(list)list=null;paragraph.push(line);
 }
 flush();
}
function showRecordTable(node,entries,columns){
 node.replaceChildren();if(!Array.isArray(entries)||!entries.length){node.append(element('p','Todavía no hay registros.','empty-records'));return;}
 const wrap=element('div',undefined,'table-scroll'),table=element('table',undefined,'admin-record-table'),thead=element('thead'),tr=element('tr');
 for(const [name] of columns)tr.append(element('th',name));thead.append(tr);table.append(thead);
 const tbody=element('tbody');for(const item of entries){const row=element('tr');for(const [,key,formatter] of columns){let val=item?.[key];if(formatter)val=formatter(val,item);else if(val===true)val='Sí';else if(val===false)val='No';else if(val&&typeof val==='object')val='Detalles en servidor';row.append(element('td',String(val??'—')));}tbody.append(row);}
 table.append(tbody);wrap.append(table);node.append(wrap);
}
const formatTime=v=>{if(!v)return '—';const date=new Date(v);return Number.isFinite(date.getTime())?date.toLocaleString('es-MX',{year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):String(v);};
const moneyCents=v=>'$'+((Number(v)||0)/100).toLocaleString('es-MX',{minimumFractionDigits:2,maximumFractionDigits:2});
function showHistory(events){const holder=$('history-full');holder.replaceChildren();
 if(!Array.isArray(events)||!events.length){holder.append(element('p','Aún no hay movimientos en esta cuenta.','empty-records'));return;}
 const list=element('ol',undefined,'history-timeline');for(const event of events){const li=element('li');
  const name=element('strong',String(event.action||'Movimiento').replaceAll('_',' '));
  const meta=element('span',formatTime(event.at)+(Number(event.debit)>0?' · '+event.debit+' crédito(s)':' · sin consumo de créditos'));
  li.append(name,meta);list.append(li);
 }holder.append(list);
}
function renderRemote(){if(!remote)return;
 const s=remote.state;historialCompleto=s.results.map(r=>r.value==='00'?'00':Number(r.value));actualizarHistorialSesion();
 const remaining=s.window.endSeq===null?0:Math.max(0,s.window.endSeq-s.seq);
 const active=s.signals.filter(x=>x.status==='active');
 $('credit-info').textContent=remote.premium_active?'PREMIUM ILIMITADO':`${remote.free_credits_remaining??5} CRÉDITOS`;
 $('window-info').textContent=remaining?`VENTANA · ${remaining}/30`:'ESPERANDO 0 / 00';
 establecerEstadoVisual(active.length?'ENTRADA':'ESPERAR',{titulo:active.length?'Señal activa':'Sin señal activa',descripcion:remaining?`${remaining} giros restantes en esta ventana`:'Registra el siguiente resultado para continuar',indicador:active.length?`${active.length} SEÑALES`:'EN ESPERA'});
 for(const [cat,rowId,outId] of [['color','opcion-color','resultado-color'],['half','opcion-mitades','resultado-mitades'],['parity','opcion-paridad','resultado-paridad']]){
 const row=$(rowId);row.querySelector('.v16-signal-actions')?.remove();const sig=active.find(x=>x.category===cat);
 $(outId).textContent=sig?friendly[sig.target]:'—';if(!sig)continue;
 const attempts=s.attempts.filter(a=>a.signalId===sig.id),pending=attempts.some(a=>a.status==='pending'),next=attempts.length+1;
 const actions=element('div',undefined,'v16-signal-actions');
 actions.append(element('span',pending?`INTENTO ${attempts.length}/4 · ESPERANDO RESULTADO`:`INTENTO ${next}/4`));
 if(!pending&&next<=4){const scheme=element('select');scheme.setAttribute('aria-label',`Secuencia de ${friendly[sig.target]}`);
 for(const [value,label] of [['A','4 / 8 / 16 / 32'],['B','5 / 10 / 20 / 40']]){const o=element('option',label);o.value=value;scheme.append(o);}
 if(attempts.length){scheme.value=attempts[0].scheme;scheme.disabled=true;}
 scheme.id=`scheme-${sig.id}`;const b=element('button',next===4?'NO RECOMENDADO · CONFIRMAR':'CONFIRMAR','v16-button');b.type='button';if(next===4)b.classList.add('v16-fourth');b.onclick=()=>confirmSignal(sig.id);actions.append(scheme,b);
 }row.append(actions);
 }
 confirmarAnalisis.disabled=!active.some(x=>!s.attempts.some(a=>a.signalId===x.id&&a.status==='pending'));
 numeroIntento.textContent=`${Math.max(0,...active.map(x=>s.attempts.filter(a=>a.signalId===x.id).length))}/4`;
 mensajeSesion.textContent=remote.free_credits_remaining===0&&!remote.premium_active?'SIN CRÉDITOS · PUEDES SEGUIR REGISTRANDO GIROS':'HISTORIAL SINCRONIZADO';
 $('open-admin').hidden=!remote.admin;
}
async function confirmSignal(id){await task(async()=>{const attempts=remote.state.attempts.filter(x=>x.signalId===id),scheme=attempts[0]?.scheme||$(`scheme-${id}`)?.value||'A';
 await operate('confirm',{signal_id:id,stake:(scheme==='A'?4:5)*2**attempts.length});if(attempts.length===3)sonidoUltimoIntento();else sonidoConfirmacion();crearImpacto();renderRemote();},mensajeSesion);}
// Add account controls to the existing layout, leaving the cover and original assets intact.
const tools=element('div',undefined,'v16-tools');tools.id='account-tools';tools.hidden=true;
for(const id of ['credit-info','window-info']){const span=element('span');span.id=id;span.className='v16-info-pill';tools.append(span);}
const account=element('button','MI CUENTA','v16-button');account.id='account-button';account.onclick=()=>{$('account-dialog').showModal();};tools.append(account);
const recover=element('button','SINCRONIZAR','v16-button');recover.onclick=()=>task(async()=>{await reconcile();await refresh();renderRemote();});tools.append(recover);
contenidoSesionActiva.prepend(tools);
const docs=element('div');docs.id='legal-docs';const legalStatus=element('p');legalStatus.id='legal-status';legalStatus.setAttribute('role','status');aceptacionInstrucciones.before(docs,legalStatus);
const phone=element('input');phone.id='register-phone';phone.className='v16-phone';phone.type='tel';phone.autocomplete='tel';phone.placeholder='Tu teléfono de contacto';phone.setAttribute('aria-label','Teléfono de contacto');phone.hidden=true;
const phoneLabel=element('label','Teléfono de contacto','register-phone-label');phoneLabel.htmlFor='register-phone';phoneLabel.hidden=true;
const signup=element('button','Crear mi cuenta','v16-button');signup.id='signup';signup.type='button';signup.hidden=true;
const reset=element('button','Olvidé mi contraseña','v16-button button-quiet');reset.id='recover-password';reset.type='button';
const openSignup=element('button','Crear una cuenta','v16-button auth-link');openSignup.id='show-signup';openSignup.type='button';
const backLogin=element('button','Ya tengo cuenta · Iniciar sesión','v16-button auth-link');backLogin.id='show-login';backLogin.type='button';backLogin.hidden=true;
const actions=element('div',undefined,'auth-extra');actions.append(reset,openSignup,backLogin);
function setAuthMode(register){
 loginPanel.classList.toggle('is-registering',register);
 phone.hidden=!register;phoneLabel.hidden=!register;signup.hidden=!register;botonLogin.hidden=register;
 reset.hidden=register;openSignup.hidden=register;backLogin.hidden=!register;
 $('auth-heading').textContent=register?'Crear una cuenta':'Iniciar sesión';
 document.querySelector('.login-descripcion').textContent=register?'Completa tus datos para solicitar acceso a La Rucaleta.':'Accede a tu mesa y continúa donde la dejaste.';
 loginClave.autocomplete=register?'new-password':'current-password';
 mensajeLogin.textContent=register?'La contraseña debe tener al menos 10 caracteres.':'Introduce tus datos para continuar.';
}
openSignup.onclick=()=>setAuthMode(true);backLogin.onclick=()=>setAuthMode(false);
signup.onclick=()=>task(async()=>{
 if(!loginUsuario.value.trim()||!loginUsuario.validity.valid)throw Error('Ingresa un correo electrónico válido.');
 if(loginClave.value.length<10)throw Error('Usa una contraseña de al menos 10 caracteres.');
 if(!/^\+?[0-9 ()-]{7,20}$/.test(phone.value))throw Error('Ingresa un teléfono de contacto válido.');
 await API.signUp(loginUsuario.value.trim(),loginClave.value,phone.value);
 loginClave.value='';setAuthMode(false);mensajeLogin.textContent='Solicitud recibida. Revisa tu correo para confirmar y después inicia sesión.';
},mensajeLogin);
reset.onclick=()=>task(async()=>{if(!loginUsuario.value.trim()||!loginUsuario.validity.valid)throw Error('Escribe tu correo electrónico primero.');await API.requestPasswordReset(loginUsuario.value.trim());mensajeLogin.textContent='Si existe la cuenta, recibirás las instrucciones por correo.';},mensajeLogin);
loginPanel.append(phoneLabel,phone,signup,actions);
$('close-account').onclick=()=>$('account-dialog').close();$('close-admin').onclick=()=>$('admin-dialog').close();
$('logout').onclick=()=>task(async()=>{try{await API.logout();}finally{location.reload();}} ,$('quote-info'));
$('new-session').onclick=()=>task(async()=>{await operate('new_session',{});numerosIniciales=[];actualizarHistorialInicial();$('account-dialog').close();await transicionNormal(pantallaSesionActiva,pantallaSesion);},$('quote-info'));
function quoteText(q){return `${q.discount_pct}% de descuento recurrente · $${(q.monthly_cents/100).toFixed(2)} MXN/mes. ${q.applied_code?'Código vinculado: '+q.applied_code+'. ':''}Cobros desactivados en QA.`;}
$('quote-code').onclick=()=>task(async()=>{$('quote-info').textContent=quoteText(await API.rpc('rucaleta_v16_quote',{p_code:$('creator-code').value}));},$('quote-info'));
$('redeem-code').onclick=()=>task(async()=>{$('quote-info').textContent=quoteText(await API.rpc('rucaleta_v16_redeem',{p_code:$('creator-code').value}));},$('quote-info'));
$('full-history').onclick=()=>task(async()=>{const r=await API.rpc('rucaleta_v16_read');showHistory(r.events);},$('quote-info'));
async function renderAdmin(action='read',payload={offset:adminOffset}){const d=await API.rpc('rucaleta_v16_admin',{p_action:action,p_payload:payload});
 const stats=$('admin-statistics');stats.replaceChildren();for(const [label,value] of [['Usuarios',d.statistics.users],['Premium activo',d.statistics.premium_active],['Grupos de señales',d.statistics.groups],['Créditos consumidos',d.statistics.credits_used],['Cobros confirmados',moneyCents(d.statistics.collected_cents)],['Comisiones',moneyCents(d.statistics.commissions_cents)]]){
 const metric=element('div',undefined,'metric');metric.append(element('span',label),element('strong',String(value??0)));stats.append(metric);
 }
 const table=$('admin-users');table.replaceChildren();const head=element('tr');for(const label of ['Usuario','Correo','Créditos','Premium hasta','Bloqueado'])head.append(element('th',label));table.append(head);
 for(const u of d.users){const row=element('tr');for(const value of [u.id,u.email,u.credits,u.enabled?u.expires_at:'—',u.blocked?'Sí':'No'])row.append(element('td',String(value??'—')));table.append(row);}
 showRecordTable($('admin-codes'),d.codes,[['Código','code'],['Creador','creator_id'],['Descuento','discount_pct',v=>`${v??0}%`],['Comisión','commission_pct',v=>`${v??0}%`],['Activo','active']]);
 showRecordTable($('admin-commissions'),d.commissions,[['Creado','created_at',formatTime],['Código','code'],['Importe','net_cents',moneyCents],['Comisión','commission_cents',moneyCents],['Referencia','provider_reference']]);
 showRecordTable($('admin-audit'),d.audit,[['Fecha','at',formatTime],['Acción','action'],['Responsable','actor']]);
 adminOffset=d.offset;$('admin-prev').disabled=adminOffset===0;$('admin-next').disabled=d.users.length<50;
 $('admin-status').textContent='Datos reales de QA · Los cobros están desactivados.';
}
$('open-admin').onclick=()=>task(async()=>{await renderAdmin();$('account-dialog').close();$('admin-dialog').showModal();},$('quote-info'));
$('admin-prev').onclick=()=>task(()=>renderAdmin('read',{offset:Math.max(0,adminOffset-50)}),$('admin-status'));
$('admin-next').onclick=()=>task(()=>renderAdmin('read',{offset:adminOffset+50}),$('admin-status'));
for(const [id,action] of [['subscription-form','subscription'],['block-form','block'],['code-form','code']])$(id).onsubmit=e=>{e.preventDefault();task(async()=>{const f=e.currentTarget;const data=Object.fromEntries(new FormData(f));for(const c of f.querySelectorAll('input[type=checkbox]'))data[c.name]=c.checked;if(data.expires_at)data.expires_at=new Date(data.expires_at).toISOString();await renderAdmin(action,data);},$('admin-status'));};
prepararEstadoInicial();
try{const recovery=await API.receiveAuthLink();if(recovery){await mostrarPantalla(pantallaLogin);mensajeLogin.textContent='Escribe tu nueva contraseña y pulsa GUARDAR.';botonLogin.hidden=true;signup.hidden=true;reset.hidden=true;phone.hidden=true;phoneLabel.hidden=true;openSignup.hidden=true;backLogin.hidden=true;const save=element('button','GUARDAR CONTRASEÑA','v16-button');save.onclick=()=>task(async()=>{if(loginClave.value.length<10)throw Error('Usa al menos 10 caracteres.');await API.updatePassword(loginClave.value);await API.logout();location.reload();},mensajeLogin);loginPanel.append(save);}
 else if(await API.userInfo()){await loadAccount();await mostrarPantalla(pantallaInstrucciones);}}
catch(e){mensajeLogin.textContent=e.message;}
