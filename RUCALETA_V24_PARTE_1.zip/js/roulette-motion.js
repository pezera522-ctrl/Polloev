// Shared 38-pocket geometry for a decorative intro, never a predicted outcome.
export const POCKETS=Object.freeze(['0','28','9','26','30','11','7','20','32','17','5','22','34','15','3','24','36','13','1','00','27','10','25','29','12','8','19','31','18','6','21','33','16','4','23','35','14','2']);
export function frameAt(t,index=19){
 t=Math.max(0,Math.min(1,t));const end=760,join=.82;
 const rotor=x=>-24+(end+24)*(1-(1-x)**3);
 const ballEnd=((end+index*360/38)%360)-1800;
 const joinBall=ballEnd+rotor(join)-end;
 const u=t/join,travel=joinBall-12,velocity=3*(end+24)*(1-join)**2;
 // Cubic Hermite: approach from the opposite direction, then match rotor speed
 // at capture without the old abrupt velocity change.
 const ball=t<join?(2*u**3-3*u**2+1)*12+(u**3-2*u**2+u)*(travel*3)+(-2*u**3+3*u**2)*joinBall+(u**3-u**2)*velocity*join:ballEnd+rotor(t)-end;
 const drop=Math.max(0,Math.min(1,(t-.62)/.25));
 const radius=.464-(.464-.39)*(drop*drop*(3-2*drop));
 return {wheel:rotor(t),ball,top:(.5-radius)*100};
}
export async function playIntro({wheel,orbit,ball,reduced=false,index=19,duration=3200}){
 const end=frameAt(1,index);const apply=()=>{wheel.style.transform=`rotate(${end.wheel}deg)`;orbit.style.transform=`translate(-50%,-50%) rotate(${end.ball}deg)`;ball.style.top=`${end.top}%`;};
 if(reduced||!wheel.animate){apply();return;}
 const frames=Array.from({length:121},(_,i)=>({...frameAt(i/120,index),offset:i/120}));
 const options={duration,easing:'linear',fill:'forwards'};
 const animations=[wheel.animate(frames.map(f=>({offset:f.offset,transform:`rotate(${f.wheel}deg)`})),options),orbit.animate(frames.map(f=>({offset:f.offset,transform:`translate(-50%,-50%) rotate(${f.ball}deg)`})),options),ball.animate(frames.map(f=>({offset:f.offset,top:`${f.top}%`})),options)];
 let timer;try{await Promise.race([Promise.allSettled(animations.map(a=>a.finished)),new Promise(r=>{timer=setTimeout(r,duration+500);})]);}finally{clearTimeout(timer);apply();for(const a of animations)a.cancel();}
}
