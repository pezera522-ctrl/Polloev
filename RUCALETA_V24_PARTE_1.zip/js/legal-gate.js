// Draft selection is not a persisted legal consent. Only the authenticated RPC can grant access.
export function completeDocuments(docs){return Array.isArray(docs)&&docs.length===3&&docs.every(d=>d&&d.id!=null&&typeof d.title==='string'&&d.title.trim()&&typeof d.content_md==='string'&&d.content_md.trim()&&typeof d.sha256==='string'&&d.sha256.trim())&&new Set(docs.map(d=>String(d.id))).size===3;}
export function documentFingerprint(docs){return completeDocuments(docs)?JSON.stringify(docs.map(d=>[String(d.id),d.sha256]).sort((a,b)=>a[0].localeCompare(b[0]))):null;}
export function draftMatches(draft,docs){return !!draft&&draft===documentFingerprint(docs);}
