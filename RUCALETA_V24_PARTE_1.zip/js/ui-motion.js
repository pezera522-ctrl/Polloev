// Presentation only. No account, monetary or analysis state is stored here.
export function createScreenNavigator({screens, win=window, focus=()=>{}}) {
  const positions = new Map();
  let generation = 0, animation = null;
  const visible = () => screens.find(screen => !screen.hidden);
  function remember() {
    const screen = visible();
    if (screen) positions.set(screen.id, Math.max(0, win.scrollY || 0));
  }
  async function go(target) {
    const current = visible();
    if (current === target) return;
    remember();
    const ticket = ++generation;
    animation?.cancel();
    for (const screen of screens) {
      screen.hidden = screen !== target;
      screen.classList.remove('pantalla-entrando', 'pantalla-entrando-profunda', 'pantalla-saliendo');
    }
    // Focus at the start, never after a delay that could steal typed input.
    focus(target);
    win.scrollTo?.({top: positions.get(target.id) || 0, behavior:'instant'});
    if (!win.matchMedia?.('(prefers-reduced-motion: reduce)').matches && target.animate) {
      const running = target.animate([
        {opacity:0, transform:'translateY(10px)'},
        {opacity:1, transform:'translateY(0)'}
      ], {duration:240, easing:'cubic-bezier(.2,.75,.25,1)'});
      animation = running;
      // Finish listeners are resolved even when a later navigation cancels us.
      let timer;
      try {
        await Promise.race([
          running.finished.catch(()=>{}),
          new Promise(resolve => { timer=win.setTimeout(resolve, 360); })
        ]);
      } finally {
        win.clearTimeout(timer);
        running.cancel();
        if (ticket === generation) animation = null;
      }
    }
  }
  return {go, remember};
}

const openers = new WeakMap();
export function openDialog(dialog) {
  if (dialog.open) return;
  const doc = dialog.ownerDocument, win = doc.defaultView;
  openers.set(dialog, doc.activeElement);
  dialog.showModal();
  dialog.scrollTop = 0;
  if (!win.matchMedia?.('(prefers-reduced-motion: reduce)').matches && dialog.animate) {
    const compact = dialog.dataset.sheet === 'true';
    dialog.animate([
      {opacity:0, transform:compact?'translateY(28px)':'translateY(12px) scale(.985)'},
      {opacity:1, transform:'translateY(0) scale(1)'}
    ], {duration:260, easing:'cubic-bezier(.2,.75,.25,1)'});
  }
}

export function mountDialogAccessibility(doc=document, win=window) {
  for (const dialog of doc.querySelectorAll('dialog')) {
    dialog.addEventListener('close', () => {
      const opener = openers.get(dialog);
      openers.delete(dialog);
      // A dialog may have just opened another dialog. Do not steal its focus.
      win.queueMicrotask(() => {
        const parentDialog = opener?.closest('dialog');
        if (!doc.querySelector('dialog[open]') && opener?.isConnected && !opener.closest('[hidden]') && (!parentDialog || parentDialog.open)) {
          opener.focus({preventScroll:true});
        }
      });
    });
  }
  const updateViewport = () => {
    const viewport = win.visualViewport;
    doc.documentElement.style.setProperty('--visible-height', `${viewport?.height || win.innerHeight}px`);
    doc.documentElement.style.setProperty('--visible-top', `${viewport?.offsetTop || 0}px`);
  };
  updateViewport();
  win.visualViewport?.addEventListener('resize', updateViewport, {passive:true});
  win.visualViewport?.addEventListener('scroll', updateViewport, {passive:true});
  win.addEventListener('resize', updateViewport, {passive:true});
}
