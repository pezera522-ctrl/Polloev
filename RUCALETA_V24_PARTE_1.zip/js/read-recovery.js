// Read-only lifecycle recovery. Never replays an outbox or sends a mutation.
export function createReadRecovery({read, commit, scope, canRead, hasPending=()=>false,
  onState, win=window, doc=document}) {
  let state='unverified', epoch=0, flight=null, timer=null, destroyed=false;
  const online=()=>win.navigator.onLine!==false;
  const visible=()=>doc.visibilityState!=='hidden';
  function publish(next) { state=next; onState(next); }
  function invalidate(reason='stale') {
    epoch++;
    if(timer!==null) { win.clearTimeout(timer); timer=null; }
    publish(online()?reason:'offline');
  }
  function confirmed() {
    epoch++;
    publish(!online()?'offline':!visible()?'stale':hasPending()?'pending':'fresh');
  }
  function schedule() {
    if(destroyed || timer!==null || flight || !online() || !visible() || !canRead()) return;
    if(!['stale','unverified','verifying'].includes(state)) return;
    timer=win.setTimeout(()=>{timer=null;void retry();},80);
  }
  async function retry() {
    if(destroyed) return false;
    if(flight) return flight;
    if(!online()) { publish('offline');return false; }
    if(!visible() || !canRead()) return false;
    const ticket=epoch, owner=scope();
    if(!owner) return false;
    publish('verifying');
    const run=(async()=>{
      try {
        const result=await read();
        if(destroyed || ticket!==epoch || scope()!==owner || !online() || !visible()) return false;
        // A foreground operation owns state until its receipt is reconciled.
        if(!canRead()) { invalidate();return false; }
        if(commit(result)===false) { publish('error');return false; }
        confirmed();return true;
      } catch {
        if(!destroyed && ticket===epoch && scope()===owner) publish(online()?'error':'offline');
        return false;
      }
    })();
    flight=run;
    try { return await run; }
    finally { flight=null;schedule(); }
  }
  const resume=()=>{invalidate();schedule();};
  const visibility=()=>{if(visible()) resume();else invalidate();};
  const offline=()=>invalidate('offline');
  const suspend=()=>invalidate();
  win.addEventListener('online',resume);
  win.addEventListener('offline',offline);
  win.addEventListener('pageshow',resume);
  win.addEventListener('pagehide',suspend);
  doc.addEventListener('visibilitychange',visibility);
  return {retry, confirmed, invalidate, flush:schedule, get state(){return state;},
    destroy(){destroyed=true;epoch++;if(timer!==null)win.clearTimeout(timer);
      win.removeEventListener('online',resume);win.removeEventListener('offline',offline);
      win.removeEventListener('pageshow',resume);win.removeEventListener('pagehide',suspend);
      doc.removeEventListener('visibilitychange',visibility);
    }
  };
}
