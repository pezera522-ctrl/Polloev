export const SUPABASE_URL='https://xpkzzmnwzodikygfsdkp.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY='sb_publishable_DNlmob9npBQocr3ArqyCow_1kqMQzJb';
export const CLOUD_QA_INTEGRATION=true;
