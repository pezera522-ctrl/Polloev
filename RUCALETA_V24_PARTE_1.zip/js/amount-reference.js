/** RUC-006 local-only reference editor. NOT server-synchronized or a wager record.
 * The server currently accepts only legacy A/B stakes; this module never sends stakes.
 */
export function createAmountReferences({getUserId}) {
  const fmt = cents => '$'+(cents/100).toLocaleString('es-MX',{minimumFractionDigits:cents%100?2:0,maximumFractionDigits:2})+' MXN';
  const parse = raw => {
    const v=String(raw).trim();
    if(!/^(?:\d{1,9})(?:\.\d{1,2})?$/.test(v))return null;
    const [whole,dec='']=v.split('.');const cents=Number(whole)*100+Number(dec.padEnd(2,'0'));
    return Number.isSafeInteger(cents)&&cents>0&&cents*8<=Number.MAX_SAFE_INTEGER?cents:null;
  };
  const identity=()=>getUserId()||null;
  const key=()=>`rucaleta-ruc006-local-${identity()}`;
  const visitKey=()=>`rucaleta-ruc006-visit-${identity()}`;
  const load=()=>{if(!identity())return {defaultCents:null,signals:{}};try {const s=JSON.parse(localStorage.getItem(key())||'{}');return {defaultCents:Number.isSafeInteger(s.defaultCents)?s.defaultCents:null,signals:s.signals&&typeof s.signals==='object'?s.signals:{}};}catch{return {defaultCents:null,signals:{}};}};
  const save=s=>localStorage.setItem(key(),JSON.stringify(s));
  const confirmed=()=>{try{return sessionStorage.getItem(visitKey())==='yes';}catch{return false;}};
  let editing=null;
  const dialog=document.createElement('dialog');dialog.className='ruc-amount-dialog';dialog.setAttribute('aria-label','Editar importe de referencia');
  dialog.insertAdjacentHTML('afterbegin','<form method="dialog" class="ruc-amount-form"><h2 id="ruc-amount-title">Importe de referencia</h2><p class="ruc-muted">Esta configuración se guarda únicamente en este navegador. No es una apuesta ni está sincronizada con el servidor.</p><label for="ruc-amount-input">Monto inicial en MXN</label><input id="ruc-amount-input" inputmode="decimal" autocomplete="off" placeholder="5.00" required><p id="ruc-amount-preview" aria-live="polite"></p><p id="ruc-amount-error" role="alert"></p><div class="ruc-actions"><button type="button" id="ruc-amount-cancel">Cancelar</button><button type="submit" id="ruc-amount-save">Confirmar monto</button></div></form>');
  document.body.append(dialog);
  const field=dialog.querySelector('#ruc-amount-input'),preview=dialog.querySelector('#ruc-amount-preview'),error=dialog.querySelector('#ruc-amount-error'),submit=dialog.querySelector('#ruc-amount-save');
  dialog.querySelector('#ruc-amount-cancel').onclick=()=>dialog.close();
  field.addEventListener('input',()=>{const cents=parse(field.value);submit.disabled=!cents;preview.textContent=cents?Array.from({length:4},(_,i)=>`Intento ${i+1}: ${fmt(cents*2**i)}`).join(' · '):'';error.textContent=cents?'':'Introduce un monto positivo, con máximo dos decimales.';});
  dialog.querySelector('form').addEventListener('submit',e=>{
    e.preventDefault();const cents=parse(field.value);if(!cents)return;
    const s=load();const now=new Date().toISOString();
    if(editing?.type==='default'){
      s.defaultCents=cents;try{sessionStorage.setItem(visitKey(),'yes');}catch{}
    }else if(editing?.type==='signal'){
      const id=editing.id;const record=s.signals[id]||{cents:s.defaultCents,history:[],snapshots:{}};
      if(record.cents!==cents){record.history=[...(record.history||[]),{from:record.cents,to:cents,at:now,attempt:editing.attempt}];record.cents=cents;}
      s.signals[id]=record;
    }
    save(s);dialog.close();editing=null;window.dispatchEvent(new Event('ruc006-local-change'));
  });
  const edit=(type,id,attempt)=>{
    if(!identity())return;
    editing={type,id,attempt};const s=load();const cents=type==='default'?s.defaultCents:(s.signals[id]?.cents??s.defaultCents);
    dialog.querySelector('#ruc-amount-title').textContent=type==='default'?'Monto para señales nuevas':'Monto de esta señal';
    field.value=cents?(cents/100).toFixed(2):'';field.dispatchEvent(new Event('input'));dialog.showModal();field.focus();
  };
  const button=(label,handler,cls='ruc-amount-button')=>{const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=label;b.onclick=handler;return b;};
  function mountDefault(host){if(!host||!identity())return;let bar=document.getElementById('ruc-amount-default');if(!bar){bar=document.createElement('section');bar.id='ruc-amount-default';bar.className='ruc-amount-default';host.prepend(bar);}bar.replaceChildren();const s=load();const label=document.createElement('p');label.textContent=confirmed()?`Monto para señales nuevas: ${s.defaultCents?fmt(s.defaultCents):'Sin configurar'}`:'Confirma el monto para señales nuevas para consultar sus referencias.';bar.append(label,button(confirmed()?'Modificar monto':'Confirmar monto',()=>edit('default')));const note=document.createElement('small');note.textContent='Referencias locales en este dispositivo · no sincronizadas entre dispositivos';bar.append(note);}
  function mountSignal(card,sig,attempt){
    if(!identity())return;
    const section=document.createElement('section');section.className='ruc-signal-amount';
    const s=load();if(!confirmed()||!s.defaultCents){section.textContent='Confirma el monto para consultar las referencias.';card.append(section);return;}
    let record=s.signals[sig.id];if(!record){record={cents:s.defaultCents,history:[],snapshots:{}};s.signals[sig.id]=record;save(s);}
    record.snapshots=record.snapshots||{};for(let n=1;n<attempt;n++){if(record.snapshots[n]===undefined)record.snapshots[n]=record.cents*2**(n-1);}save(s);
    const cents=record.cents;const title=document.createElement('p');title.className='ruc-reference-current';title.textContent=`Referencia del intento ${attempt}: ${fmt(cents*2**(attempt-1))}`;section.append(title);
    if(attempt===4){const last=document.createElement('span');last.className='ruc-last-attempt';last.textContent='Último intento';section.append(last);}
    section.append(button('Monto de esta señal',()=>edit('signal',sig.id,attempt)));
    const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Ver cuatro referencias';details.append(summary);
    const grid=document.createElement('div');grid.className='ruc-reference-grid';
    for(let n=1;n<=4;n++){const cell=document.createElement('div');cell.className='ruc-reference-cell'+(n===attempt?' is-current':n<attempt?' is-previous':'');const h=document.createElement('small');h.textContent=`Intento ${n} · ${n===attempt?'Actual':n<attempt?'Anterior':'Pendiente'}`;const v=document.createElement('strong');v.textContent=fmt(n<attempt?(record.snapshots[n]??cents*2**(n-1)):cents*2**(n-1));cell.append(h,v);grid.append(cell);}details.append(grid);
    if(record.history?.length){const history=document.createElement('details');const head=document.createElement('summary');head.textContent='Monto actualizado · ver cambios';history.append(head);const list=document.createElement('ol');for(const change of record.history){const li=document.createElement('li');li.textContent=`${new Date(change.at).toLocaleString('es-MX')}: ${fmt(change.from)} → ${fmt(change.to)} · intento ${change.attempt}`;list.append(li);}history.append(list);details.append(history);}
    section.append(details);const note=document.createElement('small');note.textContent='Referencia ilustrativa local; no representa una apuesta registrada.';section.append(note);card.append(section);
  }
  return {mountDefault,mountSignal,fmt,parse};
}
