> Archivo histórico: diagnóstico realizado antes de implementar V24. Sus siguientes pasos y estados pendientes reflejan aquel momento. El propietario autorizó después continuar sin Codespaces. El informe vigente es INFORME_V24.md.

# RUCALETA V24 — Diagnóstico técnico, fase 1 parcial

Base exclusiva: RUCALETA_V23_LEGAL_MAS_DARK_RUBY_QA(1).zip. Fecha: 20 de octubre de 2026.

No se modificó ningún archivo de la aplicación, ni producción, ni registros remotos. Este documento no certifica fidelidad visual ni cierre de la fase 1. No existen capturas nuevas: el navegador cloud rechazó la conexión local y la descarga oficial de Chromium y Headless Shell devolvió HTML «Site Unavailable» en lugar del ejecutable.

## Arquitectura verificada dentro del ZIP

- 140 entradas en el ZIP. Punto de entrada previsto por `npm run serve`: index.html de la carpeta desde donde se ejecuta python3 -m http.server 8767. No se ha verificado la carpeta real de Codespaces.
- index.html carga app.css?v=23-legal-1, java.js?v=22qa1 y dark-ruby/integration.js?v=23ruby1.
- v22.css no tiene enlace independiente en index.html; sus reglas aparecen también incorporadas en app.css. Editar únicamente v22.css no altera el CSS cargado por este HTML.
- dark-ruby/integration.js obtiene dark-ruby/index.html, extrae #rucaleta y lo monta en Shadow DOM. Allí carga styles.css y app.js propios. Los selectores generales de app.css no atraviesan esa frontera.
- Supabase: adaptador HTTP propio en js/supabase.js. Sesión conservada en localStorage; consulta y aceptación legal mediante RPC autenticada. No se probó el servidor remoto.
- Pagos: js/billing.js llama /api/billing; payments-server contiene servicio independiente con guardas QA. El servidor estático Python no proporciona esos endpoints por sí solo. No se comprobó el proxy de la instalación real.
- Ruleta: SVG y elementos DOM animados con Web Animations API. js/roulette-motion.js conserva 38 casillas y duración predeterminada de 3200 ms; no se modificó.
- No se encontró registro de service worker en los JavaScript revisados. No equivale a inspeccionar un navegador que hubiera instalado uno previamente.

## Hallazgos y acciones propuestas

Todos los archivos corregidos y soluciones implementadas se indican como «ninguno / pendiente»: esta fase es de diagnóstico.

| Problema | Causa o evidencia concreta | Archivo a intervenir | Solución propuesta | Prueba realizada y resultado |
|---|---|---|---|---|
| Comenzar abre acceso y no legal | java.js, bloque de animación alrededor de 490: prepararLogin(); ocultarPantallas(); pantallaLogin.hidden=false | java.js | Reordenar navegación y diseñar carga auténtica de documentos para visitante sin sesión | Inspección estática: confirmado; ejecución pendiente |
| Legal depende de autenticación | js/supabase.js getLegal llama rpc, que exige sessionToken; aceptación remota usa IDs y hashes | java.js / contrato legal existente | Resolver lectura previa y guardar aceptación vinculada a identidad sin falsificar ready ni borrar consentimientos | Inspección: confirmado; acceso remoto pendiente |
| Fondo desaparece en sesión activa | app.css final: .ruby-mounted sustituye background por #08090c | app.css / dark-ruby/styles.css | Integrar fondo correcto en la superficie realmente visible | Regla confirmada; render pendiente |
| Cambiar CSS general no transforma Dark Ruby | Interfaz dentro de Shadow DOM con hoja independiente | dark-ruby/integration.js / styles.css | Consolidar presentación preservando contratos; evitar dos interfaces parcialmente enlazadas | Arquitectura confirmada |
| Controles funcionales pueden quedar inaccesibles | Regla .ruby-mounted > :not(#dark-ruby-host) aplica display:none a toda la interfaz anterior; confirmación original sigue en index.html | integración y estructura de sesión | Inventario y correspondencia uno a uno de controles, errores, sincronización e intentos | Riesgo fundamentado en código; prueba interactiva pendiente |
| Diseño no es el objetivo aprobado | Dark Ruby conserva tabs, paneles y bloque de señal distintos; no contiene el teclado completo de la referencia adjunta | dark-ruby/index.html / styles.css | Reconstruir composición con controles auténticos y estado del motor | Comparación estructural; no comparación de capturas nuevas |
| Pruebas visuales previas omitían la integración | tests/local_visual_v22.py elimina etiquetas de script module e inyecta java.js con API simulada y playIntro vacío | pruebas visuales | Probar HTTP real y todos los scripts activos; separar fixtures de integración remota | Código de prueba inspeccionado: confirmado |
| CSS acumulado | app.css contiene 1251 !important y bloques de versiones diferentes | app.css | Consolidación por componente, sin parches añadidos indefinidamente | Conteo reproducible; no se atribuye todo fallo a esta cifra |
| Música no disponible | No hay archivos mp3/wav/ogg/m4a/aac/flac en el ZIP; java.js genera osciladores Web Audio | Ningún archivo musical identificado | Mantener efectos y solicitar pista original si se esperaba música | Inventario confirmado; audio audible en Safari pendiente |
| Sonido Dark Ruby puede mostrar estado distinto | app.js mantiene booleano sound local; integración pulsa preferencias del sistema principal | dark-ruby/app.js / integration.js | Estado visual derivado de una única preferencia persistida | Divergencia de fuentes confirmada; reproducción pendiente |
| Nombre de fondo no prueba correspondencia | assets/v22 contiene bienvenida/legal/casino/rubi; legal V23 referencia rubi, distinto del archivo legal | app.css | Seleccionar por inspección de contenido y referencia aprobada | Inspeccionados bienvenida, legal y rubi; correspondencia exacta pendiente |
| Posible versión/caché distinta | package.json declara 22 y HTML usa marcadores 22/23; no prueba qué sirve Codespaces | Configuración y marcadores | Registrar raíz, URL, recursos y versión ejecutados antes de empaquetar | No hay evidencia para atribuir el fallo a caché o carpeta real |

## Pruebas ejecutadas en esta sesión

- `node audit-v23/tests/roulette_motion.cjs`: PASS. Geometría, orden y API de animación; no fotogramas de navegador ni Safari.
- `node audit-v23/tests/payments_service.mjs`: PASS. Servicio con proveedor HTTP simulado; ninguna cuenta Mercado Pago contactada.
- `python3 audit-v23/tests/static_checks.py`: PASS. Alcance del script existente: estructura, referencias y comprobaciones estáticas; no certifica seguridad integral ni apariencia.
- dom_integration.cjs, auth_adapter.cjs y auth_concurrency.cjs: bloqueados por dependencia jsdom ausente. No se cuentan como aprobados.
- Capturas Playwright 375/390/393/430: no ejecutadas. Instalación del navegador bloqueada por descarga no válida; ningún archivo de captura generado.
- Supabase, RLS, consentimiento real, créditos reales, Mercado Pago real, permisos administrativos e iPhone Safari: pendientes.

## Referencias y recursos

Adjuntos visibles: legal, cuenta, administración, resultados y captura de carga de archivos en GitHub. Esta última muestra el formulario «Commit changes»: por sí sola no demuestra que el commit haya sido guardado ni qué versión está ejecutándose. Falta identificar la referencia exacta de bienvenida, inicio y Premium para sus fases; no se solicitarán ilustraciones nuevas mientras no se complete el inventario disponible.

Los fondos WebP existentes son utilizables como recursos limpios, pero inspeccionarlos no demuestra que sean idénticos a los PNG de GitHub. No se consultó el repositorio remoto ni se sustituyó la base ZIP.

## Siguiente paso necesario

Abrir la URL de vista previa QA de Codespaces en el navegador disponible, capturar el flujo sin modificar datos y verificar qué recursos sirve. Alternativamente, ejecutar el script capture.cjs preparado en un entorno con Chromium disponible. Ese script separa el recorrido real bienvenida/acceso de la exposición diagnóstica de pantallas sin sesión; no inventa usuario, señales, consentimientos ni saldos.

No se autoriza como resultado de este documento ningún salto a fases posteriores. Se mantiene la aprobación visual por fases solicitada por el propietario.
