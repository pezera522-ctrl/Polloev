# Alcance técnico de UX1

Entrega parcial realizada en copia. No se ejecutaron despliegues, cobros, migraciones ni consultas autenticadas remotas.

## Archivos de aplicación

- java.js: conecta navegación, apertura accesible de diálogos y recuperación de lectura; bloquea envíos nuevos mientras la conexión/lectura no está verificada. La operación pendiente conserva el flujo de conciliación original.
- js/ui-motion.js (nuevo): navegación cancelable, desplazamiento por pantalla en memoria, foco y adaptación de diálogos a Visual Viewport.
- js/read-recovery.js (nuevo): lecturas serializadas por ciclo de recuperación; descarta respuestas fuera de época, ocultas o pertenecientes a una cuenta anterior. No modifica montos, resultados ni señales.
- js/presentation-v24.js: conserva los nodos y eventos existentes, elimina entradas redundantes a Cuenta del panel y mantiene el campo manual dentro de un desplegable.
- app.css e index.html: presentación, accesibilidad, aviso de conexión y etiquetas de diálogos.
- VERSION.json, package.json y package-lock.json: versión parcial explícita y comando de pruebas sin nuevas dependencias.

## Decisiones

1. No se reconstruyó el formulario de presupuesto del video: no pertenece a este ZIP y no implementaría la especificación monetaria solicitada.
2. No se diseñó ni implementó una progresión automática de importes ligada a señales de apuesta. Los componentes relacionados permanecen en la versión recibida. No se presenta esta entrega como RUC-006 completo.
3. No se añadieron bases o migraciones ficticias. La mejora de recuperación utiliza la lectura RPC ya disponible en el adaptador original, cuya disponibilidad remota está pendiente de comprobar.
4. Una recarga conserva el comportamiento de recuperación remota del proyecto base. Las nuevas escuchas de pageshow/visibilitychange no crean mesas ni reinician sesiones.
5. El aviso de conexión desaparece después de una lectura confirmada, salvo que haya una operación pendiente. Una notificación online por sí sola no certifica conexión con el servidor.
6. El editor inferior se aplica a los diálogos existentes de confirmación/corrección; no hay editor de montos nuevos.
7. Se conserva intacto el logotipo y el material gráfico del ZIP. No se generaron imágenes nuevas.
8. La navegación elimina los tiempos de espera artificiales generales; la introducción decorativa de ruleta recibida permanece intacta.

## Pruebas y evidencia

Pruebas de lógica con dobles explícitos: desconexión, restauración, deduplicación de lecturas, respuesta tardía, cuenta distinta, confirmación más reciente, operación en curso, error sin bucle de reintentos, navegación rápida, scroll, foco, movimiento reducido y altura del viewport.

Pruebas heredadas ejecutadas: documentos y flujo legal con dobles, sintaxis/contratos estáticos y preservación de 26 archivos contra las referencias incluidas. Los hashes prueban preservación local, no certifican servidor ni producción.

No se ejecutó la suite antigua npm test dependiente de jsdom; no se declara aprobada. No se ejecutaron pruebas de cálculo RUC-006, autorización entre cuentas en servidor, estados de señales reales, pagos o compatibilidad Safari.

No se suministran capturas nuevas ni un certificado de calidad visual. Es necesario comprobar la integración completa en un navegador con acceso al entorno QA antes de usar esta copia con datos importantes.
