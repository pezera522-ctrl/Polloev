# RUCALETA V19 · cambios y verificación

Base: V18 entregada, derivada de tu V17. PNG originales, identidad, sonidos y reglas V16 conservados. No se modificó GitHub, producción, pagos, Edge Functions ni el esquema QA.

## Cambios implementados

- Corrección de cada número inicial en su posición, con validación 0/00/1–36 y opción explícita de retirar. Etiquetas accesibles identifican posición y valor.
- Recuperación del mismo envío pendiente de números iniciales o giros sin duplicarlo. La sincronización manual y los envíos comparten bloqueo entre pestañas donde Web Locks está disponible.
- Estado visible de guardado, envío pendiente y confirmación. Saldo desconocido se muestra como tal, nunca como cinco créditos inventados. La cuenta actualiza su saldo al registrar resultados.
- Renovación de Auth coordinada entre pestañas con Web Locks: se relee el token después de adquirir el bloqueo. Una rotación de la misma cuenta ya no recarga la página ni descarta lo que estabas escribiendo. Sin Web Locks permanece la coordinación dentro de cada pestaña; no se certifica concurrencia entre pestañas en ese caso.
- Recuperación de contraseña con confirmación, título y campos propios. Teléfono sigue siendo contacto opcional, sin SMS.
- Guía en un diálogo que conserva la mesa y el formulario. Barra accesible con giros restantes reales de la ventana.
- Administración: selección identificada, fechas anteriores limpiadas al cambiar de usuario, validación de vigencia futura al activar, desactivación sin exigir una fecha nueva, búsqueda claramente limitada a la página cargada, numeración de registros y tablas adaptadas a tarjetas en pantallas pequeñas.
- Ruleta: captura de la bola con continuidad de velocidad, destino alineado en las 38 posiciones y salida tolerante a una animación cancelada. Conserva movimiento reducido.

## Pruebas ejecutadas en V19

- DOM con dobles de API: recorridos V18 y nuevas regresiones de edición, rechazo de 37, conservación de orden, reintento de inicio/giro ambiguo sin duplicación, guía sin salir de mesa, selección administrativa, filtro y recuperación de contraseña.
- Adaptador Auth con HTTP controlado y dos contextos con almacenamiento/bloqueo compartido: una sola renovación, reutilización del token renovado, rotación sin cambio de cuenta y cierre de sesión.
- Geometría/animación: 38 destinos, alineación, velocidad continua al capturar la bola, espera de animaciones y movimiento reducido. No son fotogramas de navegador.
- Comprobaciones estáticas: JavaScript, recursos, IDs, CSP, una hoja de estilos y ausencia de secretos evidentes.
- PostgreSQL QA real: señales, crédito por grupo, ventanas, repetición de UUID, aislamiento/RLS, administración, premium, expiración, descuentos, comisiones y consentimiento. Todas las escrituras de prueba se deshicieron mediante ROLLBACK; sin pagos reales.
- ZIP extraído e integridad de archivos comprobados antes de entregar.

## Pendientes que siguen abiertos

No se ejecutó navegador visual: el entorno gestionado no dispone de control-browser y la habilidad Sites exige omitir ese paso en ese caso. Safari/iPhone físico, desbordamientos renderizados, aspecto final y Auth con correo/buzón real siguen sin certificarse. Suite móvil preparada en tests/browser_mobile.cjs.

Faltan dominio/redirecciones definitivas de Auth, proveedor de pagos y webhook de renovación/cancelación, UUID del propietario para administración y aprobación comercial de documentos. Tokens siguen en localStorage; no se afirma protección HttpOnly. Avisos heredados de seguridad registrados en ESTADO_V18.md siguen pendientes. No se repitió el asesor en V19 porque no hubo cambios de esquema.

Los 20 hallazgos originales se conservan relacionados en ESTADO_V18.md. V19 profundiza correcciones y pruebas, pero no convierte las integraciones externas pendientes en funciones terminadas.
