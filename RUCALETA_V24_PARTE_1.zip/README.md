# RUCALETA V24 — UX1 parcial

Versión: `24.0.1-ux.partial`. Base: `RUCALETA_V24_FINAL(2).zip`.

Esta entrega incorpora cambios reales de navegación, accesibilidad y recuperación de lecturas. **No implementa el sistema monetario RUC-006 ni sustituye las secuencias A/B existentes.** No es una certificación de funcionamiento completo ni una entrega lista para producción.

## Cambios incluidos

- Transiciones de pantalla de 240 ms sin las esperas acumuladas anteriores; navegación rápida con cancelación de la animación anterior.
- Conservación de desplazamiento por pantalla dentro de la pestaña mientras la aplicación está abierta; el foco se mueve al principio de la transición, sin robar escritura después.
- Apertura animada de diálogos y retorno del foco al control de origen; confirmaciones compactas inferiores.
- Altura y posición de diálogos ajustadas mediante Visual Viewport; compatibilidad de diseño con teclado móvil pendiente de comprobar en iPhone real.
- Botones de 44 px como objetivo mínimo, campos de 16 px, textos auxiliares más legibles y disposición de la botonera de seis columnas (cinco en pantallas estrechas).
- Una entrada visible a Cuenta en la barra del panel. Entrada manual de resultados dentro de un desplegable nativo; se conservan los manejadores existentes.
- Al perder conexión o suspender la pestaña se ocultan los datos actuales no verificados. La recuperación hace solo una lectura; no reenvía operaciones pendientes automáticamente.
- Protección contra respuesta tardía de otra cuenta, lectura anterior a una confirmación más reciente y lecturas simultáneas redundantes.
- Preferencia de movimiento reducido respetada por las nuevas animaciones.

## Ejecutar en una copia de desarrollo

1. Descomprime el ZIP completo en una carpeta nueva, sin mezclar archivos de versiones distintas.
2. Desde esa carpeta ejecuta:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

3. En el navegador del mismo equipo abre `http://127.0.0.1:8000/?v=24-ux1`.
4. En Codespaces utiliza la opción de abrir el puerto reenviado privado desde su panel de Puertos. No hagas público el puerto para comprobar la interfaz.
5. `VERSION.json` debe indicar `24.0.1-ux.partial`.

El servidor Python sirve la interfaz. Autenticación y datos siguen dependiendo de la configuración QA existente. No se incluye un backend de demostración ni se sustituyen respuestas por datos inventados. El servidor estático no ejecuta `/api/billing`; el servicio de pagos conserva su configuración y limitaciones previas.

No ejecutes `sql/reference_v16/`: son scripts históricos no idempotentes. No se requiere ninguna migración para los cambios incluidos en UX1. No se ha conectado ni modificado una base remota.

## Pruebas reproducibles sin instalar dependencias

Node conforme al requisito original del proyecto (>=24.19) y Python 3:

```bash
npm run test:ux
```

`test:ux` no necesita `npm install`, no llama al servidor remoto y no ejecuta SQL. Combina pruebas de los módulos nuevos, flujo legal con dobles y verificaciones estáticas. `docs/PRUEBAS_UX1.txt` contiene la salida real obtenida.

## Límites de la entrega

- RUC-006 monetario pendiente: no hay montos individuales/predeterminados, cálculo de referencias, regla de visita monetaria, umbral C29, eventos monetarios ni concurrencia monetaria implementados.
- Las secuencias A/B y la lógica de señales recibidas permanecen sin implementar modificaciones. Tampoco se ha aplicado un cambio comercial para quitar créditos.
- Sin pruebas end-to-end contra Supabase, Mercado Pago o Safari real; no se certifican permisos desplegados ni señales simultáneas en servidor.
- No fue posible realizar capturas nuevas: Chromium/WebKit no están instalados y el navegador remoto devuelve conexión rechazada al servidor local. Las imágenes antiguas de `docs/` NO representan esta versión.
- La recuperación automática se limita a lecturas al reconectar o restaurar la pestaña. Los envíos pendientes siguen necesitando Sincronizar; no se borran ni se confirman por suposición.
- El desplazamiento de pantalla se conserva en memoria; no es persistencia de montos ni una definición de visita RUC-006.

Consulta `docs/ENTREGA_UX1.md` para las decisiones y archivos cambiados. La documentación V18–V24 incluida es histórica; este README y VERSION.json describen la entrega actual.
