# RUCALETA V23 — Fase 1 · reconstrucción visual de pantalla legal (QA)

## Alcance exacto
- Base: `RUCALETA_V22_COMPLETA_QA(1).zip`.
- SOLO pantalla `#pantalla-legal`: su composición, iconografía y apariencia.
- Integración añadida al final de `app.css`, con selectores limitados a `#pantalla-legal.v23-legal` para que las otras seis pantallas mantengan sus estilos y funciones V22.
- `index.html`: misma estructura e IDs, se añade clase de alcance, icono de volver en SVG y caracteres de check/avanzar, versión CSS de caché cambiada a `23-legal-1`.
- `java.js`: solamente el renderizador de documentos legales de `loadAccount()` cambia a títulos + descripciones + iconos SVG construidos mediante DOM seguro. No altera sus APIs, contenido legal original, ni condiciones de aceptación.

## Auditoría de conflictos
- En V22 había estilos legales distintos en los bloques de `app.css` alrededor de las líneas 2152–2174 y 2376–2398, además de reglas de check más abajo. El resultado dependía de `!important` y cascada acumulada.
- V23 contiene una capa de estilos de mayor especificidad para esta sola pantalla. Se evitó editar reglas antiguas compartidas con login/tutorial y otros módulos para no romper V22.
- Los antiguos iconos `▤`, `♜` y `♠` se sustituyeron por SVG reales para documento, escudo-candado y ficha/pica.
- Se eliminó *visualmente*, no del DOM, la frase técnica adicional sobre los documentos del servidor.
- Fuente: Georgia como aproximación local a la serif editorial de la foto; NO se identificó la familia exacta de la referencia original.
- Fondo: la imagen aprobada coincide visualmente con `assets/v22/fondo-rubi.webp`, no con `assets/v22/fondo-legal.webp` cuyo contenido tiene columnas y ornamentos laterales. Ambos assets se conservan. V23 usa rubí para fidelidad.
- Logotipo WebP original conservado, RGBA con transparencia.
- `app.css` continúa conteniendo reglas V22 antiguas; no se borraron porque algunas son compartidas con pantallas que están fuera del alcance.

## Comprobaciones ejecutadas
- PASÓ: `python3 tests/static_checks.py` (CSS único, rutas, unicidad de IDs, sintaxis JS, CSP y ausencia de inyección de HTML).
- PASÓ: `node tests/absence_contract_v21.mjs` (contrato offline, NO llamada a Supabase).
- PASÓ: `node tests/roulette_motion.cjs` (geometría y contrato de movimiento, animación no modificada).
- PASÓ: `node tests/payments_service.mjs` (dobles de pruebas de pagos, NO cobros reales).
- PASÓ: Chromium headless de **maqueta aislada** a 375, 390, 393 y 430 px: sin errores de render, sin scroll horizontal; acordeones `<details>` abren; capturas generadas con textos *ficticios de relleno solo en la prueba* (no incluidos en la app).
- La estructura HTML final conserva ambas casillas y un botón inicialmente deshabilitado. La lógica original verifica ambas casillas y disponibilidad de documentos antes de permitir continuar.

## Pendientes antes de considerar terminada la etapa
- La captura V23 incluida es de una **maqueta del HTML/CSS real con documentos de prueba**: no representa una sesión autenticada ni prueba del backend en ejecución.
- Probar con usuarios QA reales en Codespaces/Safari iPhone: carga de docs de Supabase, expansión del contenido completo, aceptación/registro de versiones, devolución, restricciones de edad, compatibilidad Safari y tamaños 375/390/393/430.
- Confirmar tipografía con el propietario: Georgia cercana, pero no demostrablemente idéntica sin fuente original.
- Ajustar los iconos decorativos si el propietario dispone de PNG/SVG exactos de la referencia.
- No se creó rama remota ni modificó GitHub, Codespaces, Cloudflare, Supabase o Mercado Pago. Crear rama `rucaleta-v23-legal` y subir exclusivamente la versión web a un entorno QA privado antes de considerar merge.
- NO fusionar cambios en `main` ni desplegar producción antes de aprobación.

## Archivos modificados respecto a V22
- `index.html` (solo pantalla legal + cache-buster).
- `app.css` (CSS V23 encapsulado al final; otras pantallas no cambiadas).
- `java.js` (render legal enriquecido seguro, sin cambiar comportamiento servidor).
- `VERSION.json` (versión QA), `MANIFEST_SHA256.json` (hashes regenerados), este informe y capturas QA.

## Cómo probarlo sin afectar producción
1. Crear una rama `rucaleta-v23-legal` desde la versión V22 que se ejecute realmente; revisar si Codespaces está sirviendo raíz o `FUENTE_COMPLETA/`.
2. Subir el contenido de `RUCALETA_V23_LEGAL_WEB_QA.zip` a la raíz de un servidor **QA**; no meter `FUENTE_COMPLETA` como carpeta extra al servir el ZIP web.
3. Entrar con cuenta QA, abrir guía y avanzar a `Antes de continuar`.
4. Comprobar los tres documentos obtenidos del servidor y las dos casillas; aceptar y verificar navegación sin introducir datos personales reales.
5. Capturar pantalla en Safari, comparar con la imagen aprobada y afinar solo esta etapa hasta validación.
