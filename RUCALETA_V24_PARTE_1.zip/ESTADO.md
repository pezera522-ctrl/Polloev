# RUCALETA V20 · entrega

## Cambios

- Animación V19 conservada byte por byte. Efectos en un contenedor común: perspectiva, inclinación gradual, canto, sombra y reflejos. Bola y rotor permanecen sobre el mismo plano. Movimiento reducido respetado.
- Administración: accesos a usuarios/creadores/comisiones/actividad; edición de descuentos y comisiones con código y propietario bloqueados; reinicio de formulario para nuevos códigos; confirmaciones que describen el cambio; distinción de premium vencido.
- Servicio Node independiente para pagos QA: Auth Supabase, precio remoto, comprador/vendedor de prueba, creación/consulta/cancelación, almacenamiento persistente de intenciones, protección frente a duplicados y creación incierta, firma de webhooks, validación remota y registro de pagos de prueba. No se desplegó ni se usaron credenciales privadas.

## Verificado en esta versión

Pruebas DOM, Auth, concurrencia controlada, edición administrativa, geometría de rueda, archivos/sintaxis y seguridad del servicio de pagos con transporte simulado exclusivamente dentro de los tests. Pruebas pasadas también desde el ZIP extraído. Ver docs/local_tests_v20.log.

La lógica de señales y SQL permanece igual a V19; sus pruebas QA previas se incluyen con fecha/versiones originales, sin presentarlas como nuevas pruebas de V20. El servidor de pagos no fue conectado a Mercado Pago real ni a cuentas de prueba externas.

## Pendientes exactos

- Pagos: credenciales del vendedor de prueba, correo del comprador de prueba, secreto webhook, hosting Node con disco persistente/proxy HTTPS y UUIDs QA autorizados. Conectar el registro validado de pagos con premium y comisiones en una transacción Supabase, incluidas renovaciones, reembolsos y contracargos. El servicio marca premium_activated=false y entitlement_status=pending_integration; la web no ofrece una compra ficticia. No es una integración comercial completa.
- Administración: UUID Auth verificado del propietario para asignar el rol. No se asignó ningún rol permanente.
- Registro y recuperación por correo: buzón real y redirecciones del dominio final; navegador visual/Safari/iPhone sin certificar porque no está disponible control-browser en este entorno. Sites exige omitir la prueba visual en esas condiciones.
- Revisión comercial de documentos y avisos heredados de seguridad señalados en ESTADO_V18.md.

## Archivos de entrega

RUCALETA_V20_WEB.zip: solo archivos públicos necesarios, listo para cargar manualmente al hosting estático de QA.
RUCALETA_V20_COMPLETA.zip: fuente completa, pruebas, evidencia, SQL de referencia y servicio de pagos separado en payments-server/. No subir configuraciones de servidor con secretos al hosting estático.

No se modificaron GitHub, producción, Mikosmetics, Edge Functions ni datos existentes. No se ejecutaron cobros.
