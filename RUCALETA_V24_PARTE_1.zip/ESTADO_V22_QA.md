# RUCALETA V22 · PRIMERA INTEGRACIÓN VISUAL QA · NO PUBLICADO

## Origen y alcance

Base **exclusiva**: ZIP `RUCALETA_V21_MERCADOPAGO_QA_COMPLETA(4).zip` recibido del usuario; se conserva el motor V21 de Supabase, reglas de señal/ausencia, créditos, autenticación, administración y el servicio Node de Mercado Pago QA sin modificar.

Recursos visuales originales aportados en conversación: cuatro fondos limpios incorporados en `assets/v22/`, optimizados en WebP; logotipo auténtico existente `logo-rucaleta.webp` conservado sin modificar. **No** se han usado mockups completos como pantallas clicables.

## Interfaz creada

1. Bienvenida con fondo de ruleta, logotipo real y CTA «Comenzar» / «Ya tengo cuenta».
2. Documentos legales (contenido del backend) con diseño de referencia, **dos confirmaciones independientes** y un único botón habilitado solo si se marcan ambas; la aceptación de los documentos sigue en Supabase.
3. Nuevo inicio autenticado, resumido y con acciones reales para registrar, tutorial, historial y Mi cuenta. Vistas de plan y créditos tomadas de la respuesta autenticada.
4. Registro inicial de cinco números y mesa con selector real de 38 casillas. Tarjetas de señales y cuatro intentos se pintan **únicamente** desde el motor Supabase: ningún número/mitad inventado en producción.
5. Mi cuenta con estado de plan/créditos y acceso a Premium; fecha de renovación aparece «No confirmada» al no exponerse en el contrato V21.
6. Vista Premium separada con importe base $199 MXN/mes, beneficios y código de creador, consulta/vinculación real por RPC, resumen y checkout **solo cuando el proxy QA anuncia configuración válida**. No hay formulario bancario local.
7. Administración en diálogo móvil con métricas reales de RPC, usuarios/códigos/comisiones/auditoría y mensaje honesto para la lista global de pagos que V21 no proporciona.

## Seguridad y pagos

- No se ha desplegado ni modificado nada en GitHub, Cloudflare, Supabase, QA remoto, producción o Mercado Pago.
- No se activan cobros LIVE ni se garantiza que el entorno Mercado Pago QA esté conectado.
- Los estados de Premium los determina el servidor; los parámetros del navegador no conceden acceso.
- El sitio de prueba (`RUCALETA_V22_WEB_QA.zip`) contiene solo archivos estáticos y **no** contiene el backend Node, SQL, claves privadas ni tests.
- Para pruebas reales con Mercado Pago QA se debe configurar un proxy HTTPS same-origin `/api/billing`, webhooks y migraciones; revisar `payments-server/PASOS_INTEGRACION_V21.md`.

## Validaciones locales

- PASS: `python tests/static_checks.py` (estructura, CSP, activos, JS, IDs).
- PASS: `node tests/absence_contract_v21.mjs` (reglas deterministas SQL offline).
- PASS: `node tests/roulette_motion.cjs` (geometría y animación). 
- PASS: `node tests/payments_service.mjs` (seguridad y flujos con dobles, no cobros reales).
- PASS: `python tests/local_visual_v22.py` en Chromium móvil 375, 390, 430px con **API simulada solo en pruebas**: bienvenida, login, inicio, documentos, dos confirmaciones, cuenta, Premium, administración, registro, señal, 4 intentos y manejo de errores.

## Pendiente antes de publicar

- Comparar cada vista con referencias en un iPhone físico (Safari) y afinar detalles pixel-perfect; fondo adaptativo evita deformaciones y puede recortar márgenes según la altura.
- Ejecución real de las RPC contra Supabase QA: Auth, RLS, roles, historial, créditos, documento legal y descuentos.
- Integración remota QA de Mercado Pago, firma/verificación de webhooks y renovaciones/cancelaciones reales. Revisión legal comercial y autorización del procesador si algún día se habilita LIVE.
- Realizar un despliegue de prueba **en rama/hosting separado** para aprobación visual. Nunca sobrescribir producción por copiar directamente el ZIP completo.

### Cómo probar sin tocar producción

1. Extraer `RUCALETA_V22_WEB_QA.zip` en un sitio QA estático independiente que permita `index.html`, por ejemplo Cloudflare Pages QA (sin usar la dirección de producción). **NO** subir `FUENTE_COMPLETA/` al hosting.
2. Abrir en iPhone Safari; el sistema de prueba debe apuntar únicamente al proyecto QA que ya tiene configurado V21; no compartir cuentas o secretos de producción.
3. Los botones de suscripción permanecen deshabilitados hasta contar con el proxy QA configurado. Nunca realizar pagos reales en este paquete.

### Notas visuales

Las imágenes de `docs/v22-*.png` proceden de Chromium con datos falsos de un **test aislado** y son únicamente evidencia visual, no estados/productos reales. La foto de un ejemplo `19–36` es una respuesta del doble QA, **no** una predicción ni una prueba del servidor. Los componentes de la app no incluyen ese número fijo.
