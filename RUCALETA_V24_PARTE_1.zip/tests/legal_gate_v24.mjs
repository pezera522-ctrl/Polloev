import assert from 'node:assert/strict';
import {completeDocuments,documentFingerprint,draftMatches} from '../js/legal-gate.js';
const docs=[1,2,3].map(id=>({id,title:'Documento '+id,content_md:'Texto oficial de prueba '+id,sha256:'sha-'+id}));
assert.equal(completeDocuments(docs),true);
for(const input of [null,[],[null,null,null],[docs[0],undefined,docs[2]],docs.slice(0,2),[...docs,docs[0]],[docs[0],docs[0],docs[2]],docs.map(d=>({...d,content_md:''})),docs.map(d=>({...d,sha256:''}))])assert.equal(completeDocuments(input),false);
const draft=documentFingerprint(docs);assert.equal(draftMatches(draft,[...docs].reverse()),true);assert.equal(draftMatches(null,docs),false);assert.equal(draftMatches(draft,docs.map(d=>({...d,sha256:'changed'}))),false);assert.equal(draftMatches(draft,[]),false);
console.log('PASS V24 legal gate: 3 unique complete documents; missing body/hash blocked; changed versions rejected; order-independent draft matching. Pure logic, not remote consent.');
