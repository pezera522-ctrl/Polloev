import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {openStore} from '../payments-server/store.mjs';
import {createBilling} from '../payments-server/service.mjs';
import {verifySignature,safeCheckout,createProvider} from '../payments-server/provider.mjs';
import {makeHandler,readConfig} from '../payments-server/server.mjs';
const secret='test-only-webhook-secret',ts=String(Math.floor(Date.now()/1000));
function signed(id){return {signature:'ts='+ts+',v1='+createHmac('sha256',secret).update(`id:${id.toLowerCase()};request-id:test-request;ts:${ts};`).digest('hex'),requestId:'test-request',dataId:id};}
verifySignature({...signed('ABC'),secret});assert.throws(()=>verifySignature({...signed('ABC'),dataId:'other',secret}),/INVALID_SIGNATURE/);assert.throws(()=>verifySignature({...signed('ABC'),secret,now:Date.now()+600000}),/EXPIRED_SIGNATURE/);assert.throws(()=>safeCheckout('https://evil.example/'),/UNEXPECTED/);assert.throws(()=>readConfig({PAYMENTS_MODE:'live'}),/Only/);
const db=openStore(':memory:');let created=0,fail=false,live=false,mismatch=false,state='pending',reference,paymentStatus='approved';
const provider={verifySeller:async()=>({id:'99'}),request:async(path,method,body)=>{
 if(path==='/preapproval'&&method==='POST'){created++;assert.equal(body.auto_recurring.transaction_amount,159.2);assert.equal(body.payer_email,'buyer@testuser.com');reference=body.external_reference;if(fail)throw Error('timeout');return {id:'sub-1',external_reference:reference,init_point:'https://www.mercadopago.com.mx/subscriptions/checkout?preapproval_id=sub-1'};}
 if(path==='/preapproval/sub-1'){if(method==='PUT'){state='cancelled';return {status:state};}return {id:'sub-1',external_reference:reference,collector_id:99,status:state,auto_recurring:{currency_id:'MXN',transaction_amount:159.2}};}
 if(path==='/authorized_payments/invoice-1')return {preapproval_id:'sub-1',payment:{id:123}};
 if(path==='/v1/payments/123')return {id:123,collector_id:99,live_mode:live,status:paymentStatus,date_approved:'2026-10-19T18:00:00.000Z',currency_id:'MXN',transaction_amount:mismatch?199:159.2};
 throw Error('unexpected path '+path);
}};
const options={provider,store:db,authenticate:async t=>({id:t}),quote:async()=>({currency:'MXN',monthly_cents:15920}),testSellerId:'99',testPayerEmail:'buyer@testuser.com',allowedUsers:['user-a','user-b'],returnUrl:'https://qa.example.invalid',webhookSecret:secret,enabled:true};
const service=createBilling(options);
await assert.rejects(()=>createBilling({...options,enabled:false}).checkout('user-a'),/NOT_CONFIGURED/);
await assert.rejects(()=>service.checkout('attacker'),/ACCESS_REQUIRED/);
await service.checkout('user-a');await service.checkout('user-a');assert.equal(created,1);
state='authorized';const status=await service.status('user-a');assert.equal(status.state,'authorized');assert.equal(status.premium_activated,false);
const event={...signed('invoice-1'),body:{type:'subscription_authorized_payment',data:{id:'invoice-1'}}};
await service.webhook(event);await service.webhook(event);assert.equal(db.payments(reference).length,1);assert.equal(db.payments(reference)[0].entitlement_status,'pending_integration');
live=true;await assert.rejects(()=>service.webhook(event),/TEST_PAYMENT_MISMATCH/);live=false;mismatch=true;await assert.rejects(()=>service.webhook(event),/TEST_PAYMENT_MISMATCH/);mismatch=false;
await assert.rejects(()=>service.webhook({...event,body:{...event.body,data:{id:'wrong'}}}),/WEBHOOK_ID_MISMATCH/);
await assert.rejects(()=>service.cancel('user-b'),/NOT_FOUND/);await service.cancel('user-a');assert.equal(db.current('user-a').state,'cancelled');
fail=true;await assert.rejects(()=>service.checkout('user-b'),/timeout/);const count=created;await assert.rejects(()=>service.checkout('user-b'),/UNCERTAIN/);assert.equal(created,count);
const notTest=createProvider({accessToken:'test-placeholder',testSellerId:'99',fetchImpl:async()=>({ok:true,json:async()=>({id:99,site_id:'MLM',tags:[]})})});await assert.rejects(()=>notTest.verifySeller(),/TEST_SELLER_REQUIRED/);
// Exercise HTTP policy without opening ports or contacting external services.
async function request(handler,{url='/api/billing/checkout',method='POST',headers={},body=''}={}){let code,result;const req={url,method,headers,socket:{remoteAddress:'127.0.0.1'},async *[Symbol.asyncIterator](){if(body)yield body;}};await handler(req,{writeHead:s=>{code=s},end:v=>{result=JSON.parse(v)}});return {code,result};}
const handler=makeHandler(service,{origin:'https://qa.example.invalid',enabled:true});assert.equal((await request(handler)).code,401);assert.equal((await request(handler,{headers:{origin:'https://evil.example',authorization:'Bearer user-a'}})).code,403);
const closed=makeHandler(service,{origin:'',enabled:false});assert.equal((await request(closed)).code,503);assert.equal((await request(closed,{url:'/api/billing/capabilities',method:'GET'})).result.premium_activation,false);
// Once the bridge is configured, only provider-confirmed payment state may grant Premium.
let synced=[];fail=false;
// The previous fixture has invoice-1; both share a mocked subscription identifier. Use a new store.
const bridgedStore=openStore(':memory:');
const bridged=createBilling({...options,store:bridgedStore,applyEntitlement:async event=>{synced.push(event);return {premium_active:event.status==='approved'};},premiumStatus:async()=>true});
await bridged.checkout('user-a');
const outcome=await bridged.webhook(event);
assert.equal(outcome.premium_activated,true);assert.equal(synced.length,1);
assert.equal((await bridged.status('user-a')).premium_activated,true);
assert.equal(bridgedStore.payment('123').entitlement_status,'applied_qa');
paymentStatus='refunded';await bridged.webhook({...signed('123'),body:{type:'payment',data:{id:'123'}}});
assert.equal(synced.at(-1).status,'refunded');
await bridged.webhook({...signed('123'),body:{type:'payment',data:{id:'123'}}});
assert.equal(bridgedStore.payments(reference).length,1);
bridgedStore.close();
db.close();console.log('PASS billing: disabled/live guard, account authorization, server price, one intent, ambiguous creation blocked, HMAC/timestamp/ID, test seller, test payment/amount, webhook deduplication, ownership/cancellation, no premium claim, HTTP origin/auth. Provider HTTP is mocked; no Mercado Pago account was contacted.');
