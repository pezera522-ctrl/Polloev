BEGIN;
INSERT INTO auth.users(id,email) VALUES('18000000-0000-4000-8000-000000000004','v18-consent@example.invalid');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','18000000-0000-4000-8000-000000000004',true);
DO $$ DECLARE state jsonb; ids bigint[]; hashes text[]; rejected boolean:=false; BEGIN
 state:=public.get_my_legal_status();
 IF (state->>'ready')::boolean THEN RAISE EXCEPTION 'FAIL pre-consent gate';END IF;
 SELECT array_agg((d->>'id')::bigint),array_agg(d->>'sha256') INTO ids,hashes FROM jsonb_array_elements(state->'required_documents') d;
 IF cardinality(ids)<>3 THEN RAISE EXCEPTION 'FAIL expected current documents';END IF;
 BEGIN PERFORM public.accept_current_legal_documents(ids,ARRAY['stale','stale','stale']);EXCEPTION WHEN OTHERS THEN rejected:=true;END;
 IF NOT rejected THEN RAISE EXCEPTION 'FAIL stale consent accepted';END IF;
 PERFORM public.accept_current_legal_documents(ids,hashes);
 IF NOT (public.get_my_legal_status()->>'ready')::boolean THEN RAISE EXCEPTION 'FAIL consent not persisted';END IF;
 PERFORM public.accept_current_legal_documents(ids,hashes);
END $$;
RESET ROLE;
SELECT 'PASS: current legal versions/hashes, stale rejection, consent persistence and repeated acceptance; rollback' AS result;
ROLLBACK;
