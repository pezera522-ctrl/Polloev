"""Chromium UI layout tests, without network and with deliberately mocked API.
Not evidence of Supabase or iPhone Safari integration.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,base64,json
P=Path(__file__).resolve().parents[1]
html=(P/'index.html').read_text()
css=(P/'app.css').read_text()
for bg in ['fondo-bienvenida.webp','fondo-legal.webp','fondo-casino.webp','fondo-rubi.webp']:
 import base64
 from_file=(P/'assets'/'v22'/bg).read_bytes()
 css=css.replace(f"'assets/v22/{bg}'","'data:image/webp;base64,"+base64.b64encode(from_file).decode()+"'")
js=(P/'java.js').read_text()
js=re.sub(r'^import .*;\s*', '', js, flags=re.M)
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '',html)
html=re.sub(r'<link rel="stylesheet"[^>]*>', '',html)
html=re.sub(r'<script type="module"[^>]*></script>', '',html)
brand_img='data:image/webp;base64,'+base64.b64encode((P/'logo-rucaleta.webp').read_bytes()).decode()
for name in ['logo-rucaleta.webp','INICIAR.webp','AGREGAR.webp','iniciar-sesión.webp','ruleta-americana-premium.svg']:
 ext='svg+xml' if name.endswith('svg') else 'webp'
 data='data:image/'+ext+';base64,'+base64.b64encode((P/name).read_bytes()).decode()
 html=html.replace('"'+name+'"','"'+data+'"')
html=html.replace('</head>',f'<style>{css}</style></head>')
mock="""
const memoryStorage=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>memoryStorage.get(k)??null,setItem:(k,v)=>memoryStorage.set(k,String(v)),removeItem:k=>memoryStorage.delete(k)}});
if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>'qa-'+Math.random()});
const normalizeNumber=value=>{const s=String(value??'').trim();if(s==='00')return s;if(!/^(?:0|[1-9]|[12]\\d|3[0-6])$/.test(s))throw Error('Número inválido');return s;};
const friendly={red:'Rojo',black:'Negro',odd:'Impar',even:'Par',low:'1–18',high:'19–36'};
const playIntro=async()=>{};
window.__signed=false;
window.__revision=0;
window.__state={results:[],seq:0,sessionStartSeq:0,signals:[],attempts:[],window:{endSeq:null},streaks:{red:0,black:0,odd:0,even:0,low:0,high:0}};
window.__events=[];window.__credits=5;
const reds=new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
const updateSpin=(value,seed=false)=>{
 const s=window.__state,prev={...s.streaks};s.seq++;s.results.push({value,seq:s.seq});
 if(value==='0'||value==='00'){s.window.endSeq=s.seq+30;return;}
 const n=Number(value),groups={color:reds.has(n)?'red':'black',parity:n%2===0?'even':'odd',half:n<=18?'low':'high'};
 for(const target of ['red','black','odd','even','low','high'])s.streaks[target]=Object.values(groups).includes(target)?0:s.streaks[target]+1;
 for(const sig of s.signals.filter(x=>x.status==='active')){
  const pending=s.attempts.find(a=>a.signalId===sig.id&&a.status==='pending');if(pending){pending.status=groups[sig.category]===sig.target?'won':'lost';pending.result=value;pending.resolvedSeq=s.seq;
   if(pending.status==='won'){sig.status='won';sig.completedSeq=s.seq;}else if(pending.attemptNumber===4){sig.status='lost';sig.completedSeq=s.seq;}}
 }
 if(seed)return;
 let created=false;
 for(const target of ['red','black','odd','even','low','high'])if(prev[target]===4&&s.streaks[target]===5&&s.window.endSeq!==null&&s.seq<s.window.endSeq&&window.__credits>0&&!s.signals.some(a=>a.status==='active'&&a.target===target)){
  const category=['red','black'].includes(target)?'color':['odd','even'].includes(target)?'parity':'half';s.signals.push({id:'signal-'+s.seq+'-'+target,category,target,triggerSeq:s.seq,status:'active'});created=true;
 }
 if(created)window.__credits--;
};
window.API={receiveAuthLink:async()=>false,signIn:async()=>{window.__signed=true},userInfo:async()=>window.__signed?{id:'browser-qa',email:'visual@example.invalid'}:null,
 signUp:async()=>{},logout:async()=>{window.__signed=false},updatePassword:async()=>{},requestPasswordReset:async()=>{},
 getLegal:async()=>({ready:true,required_documents:[{id:'doc',sha256:'hash',title:'Condiciones QA',content_md:'# Documento de prueba'}]}),
 acceptLegal:async()=>{},rpc:async(name)=>name==='rucaleta_v16_read'?{events:window.__events}:name==='rucaleta_v16_quote'?{discount_pct:0,monthly_cents:19900}:{users:[],codes:[],commissions:[],audit:[],statistics:{},offset:0},
 analysisApi:async(action,payload,id)=>{
  const s=window.__state;if(action){window.__revision++;window.__events.push({action,payload,at:new Date().toISOString(),debit:0});
   if(action==='seed_history'){for(const value of payload.values)updateSpin(value,true)}
   else if(action==='spin'){updateSpin(payload.value)}
   else if(action==='confirm'){const sig=s.signals.find(x=>x.id===payload.signal_id);const a=s.attempts.filter(x=>x.signalId===sig.id);s.attempts.push({id:'a'+(a.length+1),signalId:sig.id,attemptNumber:a.length+1,status:'pending',scheme:a[0]?.scheme||(payload.stake===4?'A':'B'),stake:payload.stake});}
   else if(action==='new_session'){s.sessionStartSeq=s.seq;s.window.endSeq=null;s.streaks={red:0,black:0,odd:0,even:0,low:0,high:0};s.signals.forEach(x=>{if(x.status==='active')x.status='closed_by_new_session'});}}
  return {state:structuredClone(s),revision:window.__revision,premium_active:false,free_credits_remaining:window.__credits,admin:false};
 }};
"""
js=mock+'\n'+js.replace("logo.src='logo-rucaleta.webp'","logo.src='"+brand_img+"'")+'''\nwindow.__test={render:renderRemote,setRemote:v=>{remote=v;renderRemote()},goSeed:()=>{ocultarPantallas();pantallaSesion.hidden=false},goActive:()=>{ocultarPantallas();pantallaSesionActiva.hidden=false;renderRemote()},admin:renderAdmin};'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in (375,390,430):
  ctx=browser.new_context(viewport={'width':width,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True,reduced_motion='reduce')
  page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded')
  page.add_script_tag(content='(async()=>{'+js+'})().catch(e=>{console.error(e);window.__appError=String(e)})')
  page.wait_for_timeout(250)
  assert not errors,(width,errors)
  assert not page.evaluate('window.__appError'),(width,page.evaluate('window.__appError'))
  assert page.locator('.pocket').count()==76,(width,page.locator('.pocket').count())
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),f'cover overflow {width}'
  page.screenshot(path=str(P/f'docs/v22-cover-{width}.png'))
  page.locator('#boton-iniciar').click();page.locator('#pantalla-login').wait_for(state='visible')
  page.screenshot(path=str(P/f'docs/v22-login-{width}.png'))
  assert page.locator('#rucaleta-menu-toggle').is_visible()
  page.locator('#rucaleta-menu-toggle').click();assert page.locator('#rucaleta-menu button:visible').count()>1
  page.locator('#rucaleta-menu-toggle').click()
  page.locator('#login-usuario').fill('visual@example.invalid');page.locator('#login-clave').fill('test-password-123')
  page.locator('#boton-login').click();page.locator('#pantalla-jugador').wait_for(state='visible',timeout=4000)
  page.screenshot(path=str(P/f'docs/v22-home-{width}.png'))
  page.wait_for_timeout(1300)
  page.locator('#v22-home-account').click();page.locator('#account-dialog').wait_for(state='visible')
  assert 'Premium no activo' in page.locator('#v22-premium-badge').inner_text()
  page.screenshot(path=str(P/f'docs/v22-account-{width}.png'))
  page.locator('#v22-open-premium').click();page.locator('#premium-dialog').wait_for(state='visible')
  page.wait_for_timeout(500)
  assert page.locator('#billing-buy').is_hidden(), 'QA billing without proxy must remain disabled'
  page.screenshot(path=str(P/f'docs/v22-premium-{width}.png'))
  page.locator('#v22-close-premium').click()
  page.evaluate('window.__test.admin()');page.wait_for_timeout(400)
  page.evaluate("document.getElementById('admin-dialog').showModal()")
  page.screenshot(path=str(P/f'docs/v22-admin-{width}.png'))
  page.locator('#close-admin').click()
  # Legal UX uses real details from the mocked getLegal, but both consents must be independently checked.
  page.evaluate("document.querySelectorAll('.pantalla').forEach(x=>x.hidden=true);document.getElementById('pantalla-legal').hidden=false")
  page.screenshot(path=str(P/f'docs/v22-legal-{width}.png'))
  assert page.locator('#boton-aceptar-legal').is_disabled()
  page.locator('#aceptacion-instrucciones').click();assert page.locator('#boton-aceptar-legal').is_disabled()
  page.locator('#aceptacion-edad').click();assert page.locator('#boton-aceptar-legal').is_enabled()
  page.evaluate('window.__test.goSeed()')
  page.locator('#pantalla-sesion').wait_for(state='visible',timeout=4000)
  assert page.locator('#initial-picker .pocket:visible').count()==38
  assert not page.evaluate('document.documentElement.scrollWidth>innerWidth'),'seed overflow'
  page.wait_for_timeout(900);page.screenshot(path=str(P/f'docs/v22-seed-{width}.png'))
  for value in ['00','7','5','2','4']:
   page.locator(f'#initial-picker [data-value="{value}"]').click();page.wait_for_timeout(70)
  assert page.locator('#contador-inicial').inner_text()=='5/5'
  page.locator('#boton-iniciar-sesion').click();page.locator('#pantalla-sesion-activa').wait_for(state='visible',timeout=2000)
  assert page.locator('#live-picker .pocket:visible').count()==38
  page.locator('#live-picker [data-value="3"]').click();page.wait_for_timeout(200)
  assert page.locator('.player-signal-card').count()==1, ('signal must activate after 5',page.locator('#mensaje-sesion').inner_text(),page.locator('#primary-signal-feed').inner_text())
  assert '19–36' in page.locator('#primary-signal-feed').inner_text()
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'active overflow'
  page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(120);page.screenshot(path=str(P/f'docs/v22-signal-{width}.png'))
  page.locator('.signal-confirm').click();page.wait_for_timeout(140)
  assert 'Intento 1 de 4' in page.locator('#primary-signal-feed').inner_text()
  page.locator('#live-picker [data-value="7"]').click();page.wait_for_timeout(140)
  assert page.locator('.signal-confirm').count()==1
  page.screenshot(path=str(P/f'docs/v22-next-attempt-{width}.png'))
  page.locator('.signal-confirm').click();page.wait_for_timeout(120)
  page.locator('#live-picker [data-value="5"]').click();page.wait_for_timeout(120)
  page.locator('.signal-confirm').click();page.wait_for_timeout(120)
  page.locator('#live-picker [data-value="2"]').click();page.wait_for_timeout(120)
  assert page.locator('.last-attempt .purple-button').count()==1
  page.screenshot(path=str(P/f'docs/v22-purple-{width}.png'))
  page.locator('.purple-button').click();page.locator('#request-confirm').wait_for(state='visible')
  page.locator('#request-cancel').click();assert page.locator('.purple-button').count()==1
  page.locator('.purple-button').click();page.locator('#request-yes').click();page.wait_for_timeout(100)
  page.locator('#live-picker [data-value="4"]').click();page.wait_for_timeout(120)
  assert 'cuatro intentos finalizados' in page.locator('#primary-signal-feed').inner_text()
  page.locator('#request-correction').click();assert page.locator('#correction-dialog').is_visible();page.locator('#close-correction').click()
  assert not errors,(width,errors)
  print(f'PASS V22 Chromium mock {width}: cover/login/menu/seed/38 pockets/green window/fifth absence/attempt/correction/layout')
  ctx.close()
 browser.close()
