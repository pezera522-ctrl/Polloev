// Deterministic two-context Web Locks test; no live credentials or browser claims.
const {JSDOM}=require('jsdom'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const key='rucaleta-qa-xpkzzmnwzodikygfsdkp-auth-v16',store=new Map();let queue=Promise.resolve(),refreshes=0;
 const expired={user:{id:'same-account'},access_token:'expired',refresh_token:'refresh-one',expires_at:1};store.set(key,JSON.stringify(expired));
 const contexts=[];
 const source=fs.readFileSync(path.join(__dirname,'../js/supabase.js'),'utf8').replace(/^import .*;\n/gm,'').replace(/export /g,'');
 for(let i=0;i<2;i++){
  const dom=new JSDOM('',{url:'https://qa.example.invalid',runScripts:'outside-only'}),w=dom.window;contexts.push(dom);w.AbortController=AbortController;
  Object.defineProperty(w,'localStorage',{value:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)}});
  Object.defineProperty(w.navigator,'locks',{value:{request:(_,fn)=>{const p=queue.then(fn);queue=p.catch(()=>{});return p;}}});
  w.fetch=async(url,opts)=>{if(url.includes('refresh_token')){refreshes++;assert.equal(JSON.parse(opts.body).refresh_token,'refresh-one');await new Promise(r=>setTimeout(r,15));return {ok:true,text:async()=>JSON.stringify({user:{id:'same-account'},access_token:'renewed',refresh_token:'refresh-two',expires_at:Math.floor(Date.now()/1000)+3600})};}return {ok:true,text:async()=>'{}'};};
  w.eval('const BASE="https://qa.example.invalid",KEY="public-test";const projectV15Read=x=>x;'+source+';window.A={sessionToken,currentSession,logout};');
 }
 // Both contexts load stale state before either acquires the refresh lock.
 contexts.forEach(d=>d.window.A.currentSession());
 const tokens=await Promise.all(contexts.map(d=>d.window.A.sessionToken()));assert.deepEqual(tokens,['renewed','renewed']);assert.equal(refreshes,1);
 const w=contexts[0].window,rotated=JSON.stringify({...JSON.parse(store.get(key)),access_token:'latest'});
 w.dispatchEvent(new w.StorageEvent('storage',{key,oldValue:store.get(key),newValue:rotated}));assert.equal(w.A.currentSession().access_token,'latest');
 await w.A.logout();assert.equal(w.A.currentSession(),null);assert.equal(store.has(key),false);
 contexts.forEach(d=>d.window.close());console.log('PASS two Auth contexts: one refresh under shared Web Lock; stored rotated token reused; same-account storage event retains context; logout clears credentials. Test doubles only.');
})().catch(e=>{console.error(e);process.exitCode=1;});
