BEGIN;
INSERT INTO auth.users(id,email) VALUES('16000000-0000-4000-8000-000000000011','v16-ledger-a@example.invalid'),('16000000-0000-4000-8000-000000000012','v16-ledger-b@example.invalid');
INSERT INTO rucaleta_v16.creator_codes VALUES('LEDGER16','16000000-0000-4000-8000-000000000012',20,10,true);
INSERT INTO rucaleta_v16.referrals(user_id,code,discount_pct,commission_pct) VALUES('16000000-0000-4000-8000-000000000011','LEDGER16',20,10);
DO $$ DECLARE a uuid;b uuid;BEGIN
 a:=rucaleta_v16.record_confirmed_month('fixture-month-1','16000000-0000-4000-8000-000000000011',15920);
 b:=rucaleta_v16.record_confirmed_month('fixture-month-1','16000000-0000-4000-8000-000000000011',15920);
 IF a<>b OR (SELECT commission_cents FROM rucaleta_v16.commissions WHERE id=a)<>1592 THEN RAISE EXCEPTION 'FAIL commission/idempotency';END IF;
 PERFORM rucaleta_v16.record_confirmed_month('fixture-month-2','16000000-0000-4000-8000-000000000011',15920);
 IF (SELECT count(*) FROM rucaleta_v16.commissions WHERE user_id='16000000-0000-4000-8000-000000000011')<>2 THEN RAISE EXCEPTION 'FAIL recurring';END IF;
 BEGIN PERFORM rucaleta_v16.record_confirmed_month('fixture-month-3','16000000-0000-4000-8000-000000000011',1);RAISE EXCEPTION 'FAIL_WRONG_AMOUNT_ACCEPTED';EXCEPTION WHEN raise_exception THEN IF SQLERRM<>'SETTLEMENT_AMOUNT_MISMATCH' THEN RAISE;END IF;END;
END $$;
SET LOCAL ROLE authenticated;
DO $$ BEGIN BEGIN PERFORM rucaleta_v16.record_confirmed_month('forged','16000000-0000-4000-8000-000000000011',15920);RAISE EXCEPTION 'FAIL client settlement';EXCEPTION WHEN insufficient_privilege THEN NULL;END;END $$;
RESET ROLE;
SELECT 'PASS: recurring commission 1592 cents, deduplication, amount validation, client denied; no actual payment' result;
ROLLBACK;
