from pathlib import Path
import re, subprocess, hashlib, json
p=Path(__file__).resolve().parents[1]
h=(p/'index.html').read_text();ids=re.findall(r'\bid="([^"]+)"',h)
assert len(ids)==len(set(ids)), 'duplicate ids'
for src in re.findall(r'(?:src|href)="([^"]+)"',h):
 if not re.match(r'https?:|#',src): assert (p/src.split('?')[0]).is_file(),src
assert len(re.findall('data-posicion=',h))==10
assert len(re.findall('rel="stylesheet"',h))==1
for f in [p/'java.js',*(p/'js').glob('*.js')]: subprocess.run(['node','--check',str(f)],check=True)
js='\n'.join(f.read_text() for f in [p/'java.js',*(p/'js').glob('*.js')])
assert not re.search(r'sb_secret_|eyJ[a-zA-Z0-9_-]+\.',js)
assert 'innerHTML' not in js
assert 'CUENTAS_AUTORIZADAS' not in js
assert 'role\',\'tablist' not in js
assert 'Content-Security-Policy' in h
assert 'playIntro' in js and 'await playIntro' in js
assert 'ux-v17.css' not in h
print('PASS static: single stylesheet; unique IDs; all assets; syntax; 10 slots; no private keys or unsafe HTML sinks; CSP; awaited roulette.')
