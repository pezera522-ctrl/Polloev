from pathlib import Path
from html.parser import HTMLParser
import re, json, hashlib, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1];base=p.parent/'audit-v23'
html=(p/'index.html').read_text();js=(p/'java.js').read_text();css=(p/'app.css').read_text()
baseline=json.loads((p/'tests/baseline_v23_sha256.json').read_text())
for file,expected in baseline.items():
 assert hashlib.sha256((p/file).read_bytes()).hexdigest()==expected,file
print(f'PASS SHA256 preservation against original V23: {len(baseline)} engine, motion, billing, backend, SQL, configuration and original graphic files.')
assert 'dark-ruby/integration.js' not in html and 'ruby-mounted' not in css
assert 'attachShadow' not in (p/'js/presentation-v24.js').read_text()
assert '.ui-details:not(.legal-entry)' in css and '.boton-continuar-instrucciones:not(.boton-aceptar-legal)' in css
assert "destination=pantallaLegal" in js and "abrirLoginConRuleta('login')" in js
assert 'checkInstrucciones.checked && checkEdad.checked && completeDocuments' in js
assert "API.acceptLegal(legal.required_documents)" in js and "if(!legal.ready)" in js
for f in [p/'app.css',p/'motion.css']:
 for url in re.findall(r'url\([\'"]?([^\)\'\"]+)',f.read_text()):
  if not url.startswith(('data:','http','#')):assert (f.parent/url.split('?')[0]).is_file(),url
for f in [p/'java.js',*p.glob('js/*.js')]:
 for target in re.findall(r"from\s+['\"]([^'\"]+)",f.read_text()):assert (f.parent/target.split('?')[0]).is_file(),target
ui=(p/'js/presentation-v24.js').read_text();assert "live.prepend(hero,toolbar,controls,sync" in ui and "$('primary-signal-feed')" in ui and "const picker=$('live-picker').parentElement" in ui
if base.exists():
 original_ids=set(re.findall(r'\bid="([^"]+)"',(base/'index.html').read_text()))
 current_ids=set(re.findall(r'\bid="([^"]+)"',html))
 assert original_ids-current_ids<= {'dark-ruby-host'},'original control IDs removed'
 protected=['js/roulette-motion.js','js/engine.js','js/v15-projection.js','js/config.js','js/billing.js']+[str(f.relative_to(base)) for folder in ['payments-server','sql','supabase'] for f in (base/folder).rglob('*') if f.is_file()]
 for f in protected:assert (base/f).read_bytes()==(p/f).read_bytes(),f
 assert (p/'js/supabase.js').read_text().startswith((base/'js/supabase.js').read_text())
 def shapes(file):
  tree=ET.parse(file).getroot();return [(e.tag,{k:v for k,v in e.attrib.items() if k not in ['fill','stroke','stop-color']},e.text) for e in tree if e.tag.split('}')[-1]!='defs']
 assert shapes(base/'ruleta-americana-premium.svg')==shapes(p/'ruleta-americana-premium.svg'),'wheel geometry or labels changed'
 for line in (p/'motion.css').read_text().splitlines()[1:]:assert line in (base/'app.css').read_text(),'motion changed'
 print('PASS byte preservation: engine, motion, billing, SQL, backend; original auth adapter intact; SVG shapes/text preserved; original motion CSS retained.')
print('PASS V24 static contracts: one live DOM, legal destination, independent checks, source asset paths and imports. Not a browser test.')
