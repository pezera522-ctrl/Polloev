QA ya está configurado. No vuelvas a ejecutar reference_v16: son scripts históricos de instalación no idempotentes.
La única migración nueva es 20261018215419_rucaleta_seed_history_five_to_ten, aplicada en QA y registrada por Supabase. No cambia datos.
bootstrap_admin_MANUAL.sql requiere el UUID verificado de la persona propietaria; no se ejecutó.
Las suites de tests SQL utilizan fixtures y ROLLBACK.
