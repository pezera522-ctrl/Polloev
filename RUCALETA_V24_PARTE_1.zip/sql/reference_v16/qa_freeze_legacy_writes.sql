-- Freeze legacy QA writes after the V16 snapshot. Existing rows and read RPCs stay intact.
-- Prevents independent consumption of the old and new credit ledgers.
REVOKE EXECUTE ON FUNCTION public.rucaleta_v15_apply(uuid,bigint,text,jsonb) FROM authenticated,anon,PUBLIC,service_role;
