-- Trusted billing integration, NOT exposed to browser/API roles; no payments executed.
CREATE FUNCTION rucaleta_v16.record_confirmed_month(p_reference text,p_user uuid,p_net_cents integer) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE ref rucaleta_v16.referrals%ROWTYPE;old rucaleta_v16.commissions%ROWTYPE;new_id uuid;
BEGIN
 IF p_reference IS NULL OR length(p_reference) NOT BETWEEN 1 AND 128 OR p_net_cents IS NULL OR p_user IS NULL THEN RAISE EXCEPTION 'INVALID_SETTLEMENT';END IF;
 SELECT * INTO ref FROM rucaleta_v16.referrals WHERE user_id=p_user;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFERRAL_REQUIRED';END IF;
 IF p_net_cents<>19900*(100-ref.discount_pct)/100 THEN RAISE EXCEPTION 'SETTLEMENT_AMOUNT_MISMATCH';END IF;
 INSERT INTO rucaleta_v16.commissions(user_id,code,provider_reference,net_cents,commission_cents)
 VALUES(p_user,ref.code,p_reference,p_net_cents,p_net_cents*ref.commission_pct/100)
 ON CONFLICT(provider_reference) DO NOTHING RETURNING id INTO new_id;
 IF new_id IS NULL THEN
 SELECT * INTO old FROM rucaleta_v16.commissions WHERE provider_reference=p_reference;
 IF old.user_id<>p_user OR old.net_cents<>p_net_cents THEN RAISE EXCEPTION 'SETTLEMENT_IDEMPOTENCY_CONFLICT';END IF;
 new_id:=old.id;
 END IF;
 RETURN new_id;
END $$;
REVOKE ALL ON FUNCTION rucaleta_v16.record_confirmed_month(text,uuid,integer) FROM PUBLIC,anon,authenticated,service_role;
