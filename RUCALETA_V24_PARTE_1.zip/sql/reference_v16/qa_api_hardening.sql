-- New V16 objects only. Private privileged implementations; public invoker wrappers.
DO $$ DECLARE t record;BEGIN FOR t IN SELECT tablename FROM pg_tables WHERE schemaname='rucaleta_v16' LOOP
 EXECUTE format('CREATE POLICY deny_direct_access ON rucaleta_v16.%I FOR ALL TO anon,authenticated USING (false) WITH CHECK (false)',t.tablename);
END LOOP;END $$;
ALTER FUNCTION public.rucaleta_v16_apply(uuid,bigint,text,jsonb) SET SCHEMA rucaleta_v16;
ALTER FUNCTION public.rucaleta_v16_read() SET SCHEMA rucaleta_v16;
ALTER FUNCTION public.rucaleta_v16_verify() SET SCHEMA rucaleta_v16;
ALTER FUNCTION public.rucaleta_v16_quote(text) SET SCHEMA rucaleta_v16;
ALTER FUNCTION public.rucaleta_v16_redeem(text) SET SCHEMA rucaleta_v16;
ALTER FUNCTION public.rucaleta_v16_admin(text,jsonb) SET SCHEMA rucaleta_v16;
CREATE FUNCTION public.rucaleta_v16_apply(p_request_id uuid,p_expected_revision bigint,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_apply(p_request_id,p_expected_revision,p_action,p_payload) $$;
CREATE FUNCTION public.rucaleta_v16_read() RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_read() $$;
CREATE FUNCTION public.rucaleta_v16_verify() RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_verify() $$;
CREATE FUNCTION public.rucaleta_v16_quote(p_code text DEFAULT NULL) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_quote(p_code) $$;
CREATE FUNCTION public.rucaleta_v16_redeem(p_code text) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_redeem(p_code) $$;
CREATE FUNCTION public.rucaleta_v16_admin(p_action text DEFAULT 'read',p_payload jsonb DEFAULT '{}'::jsonb) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path='' AS $$ SELECT rucaleta_v16.rucaleta_v16_admin(p_action,p_payload) $$;
REVOKE ALL ON FUNCTION public.rucaleta_v16_apply(uuid,bigint,text,jsonb),public.rucaleta_v16_read(),public.rucaleta_v16_verify(),public.rucaleta_v16_quote(text),public.rucaleta_v16_redeem(text),public.rucaleta_v16_admin(text,jsonb) FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_apply(uuid,bigint,text,jsonb),public.rucaleta_v16_read(),public.rucaleta_v16_verify(),public.rucaleta_v16_quote(text),public.rucaleta_v16_redeem(text),public.rucaleta_v16_admin(text,jsonb) TO authenticated;
