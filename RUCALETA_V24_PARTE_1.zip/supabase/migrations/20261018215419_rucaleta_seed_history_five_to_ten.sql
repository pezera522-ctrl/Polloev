-- Already applied to QA xpkzzmnwzodikygfsdkp as 20261018215419.
-- Idempotent patch; no existing data is altered.
DO $patch$ DECLARE definition text; BEGIN
 SELECT pg_get_functiondef('rucaleta_v16.rucaleta_v16_apply(uuid,bigint,text,jsonb)'::regprocedure) INTO definition;
 IF position('jsonb_array_length(p_payload->''values'') <>5' in definition)>0 THEN
 definition:=replace(definition,'jsonb_array_length(p_payload->''values'') <>5','jsonb_array_length(p_payload->''values'') NOT BETWEEN 5 AND 10');EXECUTE definition;
 ELSIF position('jsonb_array_length(p_payload->''values'') NOT BETWEEN 5 AND 10' in definition)=0 THEN
 RAISE EXCEPTION 'Unexpected function shape: no changes applied';END IF;
END $patch$;
