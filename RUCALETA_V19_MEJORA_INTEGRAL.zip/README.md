# La Rucaleta · V19 QA

Versión única basada en la V18 entregada, derivada del ZIP V17 adjunto. Conserva logo, cinco PNG originales, sonidos y motor V16. Las imágenes del navegador usan WebP de tamaño adecuado; los originales siguen incluidos.

Descomprime en una carpeta independiente y sirve **esa carpeta** por HTTP/HTTPS. `index.html` está en la raíz. No mezcles sus archivos con otra entrega. No se necesita compilar para abrirla. Los comandos están en `COMANDOS.md`.

QA configurado: `xpkzzmnwzodikygfsdkp`. Solo contiene clave pública. La migración de V18 para 5–10 resultados ya está aplicada en QA; V19 no modifica el esquema; no ejecutes los scripts históricos de instalación.

Pruebas realizadas: integración DOM con API simulada, adaptador Auth con HTTP simulado, geometría y finalización de animación, archivos y suites PostgreSQL reales con rollback. Evidencia en `docs/`. No hay cuentas de demostración, cifras de éxito inventadas ni simulación de compras en la aplicación.

Pendientes externos: correo Auth completo y redirecciones del dominio final; Safari/iPhone y comparación visual; UUID Auth verificado de la persona propietaria para asignar administración; documentos legales aprobados; proveedor de pagos y renovaciones/webhooks. Los pagos están desactivados. No es una certificación de lanzamiento comercial.

`ESTADO.md` describe las mejoras y pruebas V19; `ESTADO_V18.md` conserva la relación de los 20 hallazgos originales. `MANIFEST_SHA256.json` identifica los archivos exactos de esta entrega.
