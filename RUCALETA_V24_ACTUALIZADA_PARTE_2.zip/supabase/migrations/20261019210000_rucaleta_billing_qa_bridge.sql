-- QA only. Apply ONLY to RUCALETA-QA xpkzzmnwzodikygfsdkp.
-- Service-role RPC records payment status and recomputes premium from *verified* payments.
BEGIN;
ALTER TABLE rucaleta_v16.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_source_check;
ALTER TABLE rucaleta_v16.subscriptions ADD CONSTRAINT subscriptions_source_check CHECK (source IN ('manual_qa','mercadopago_qa'));
CREATE TABLE IF NOT EXISTS rucaleta_v16.billing_qa_payments (
 payment_id text PRIMARY KEY CHECK (payment_id ~ '^[0-9]{1,24}$'),
 subscription_id text NOT NULL,
 user_id uuid NOT NULL REFERENCES auth.users(id),
 amount_cents integer NOT NULL CHECK (amount_cents>0 AND amount_cents<=19900),
 payment_status text NOT NULL CHECK (payment_status IN ('approved','pending','in_process','rejected','cancelled','refunded','charged_back')),
 approved_at timestamptz,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS billing_qa_user_idx ON rucaleta_v16.billing_qa_payments(user_id, approved_at DESC);
ALTER TABLE rucaleta_v16.billing_qa_payments ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON rucaleta_v16.billing_qa_payments FROM PUBLIC,anon,authenticated;
CREATE OR REPLACE FUNCTION public.rucaleta_billing_qa_apply_payment(
 p_payment_id text,p_subscription_id text,p_user_id uuid,p_status text,p_amount_cents integer,p_approved_at timestamptz DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_expires timestamptz;v_active boolean;v_old rucaleta_v16.billing_qa_payments%ROWTYPE;
BEGIN
 IF current_setting('request.jwt.claim.role',true) IS DISTINCT FROM 'service_role' THEN
  RAISE EXCEPTION 'BILLING_SERVICE_ROLE_REQUIRED' USING ERRCODE='42501';
 END IF;
 IF p_user_id IS NULL OR p_payment_id !~ '^[0-9]{1,24}$' OR p_subscription_id IS NULL OR length(p_subscription_id)<2 OR length(p_subscription_id)>128
 OR p_amount_cents NOT BETWEEN 1 AND 19900 OR p_status NOT IN ('approved','pending','in_process','rejected','cancelled','refunded','charged_back')
 OR (p_status='approved' AND (p_approved_at IS NULL OR p_approved_at>now()+interval '5 minutes'))
 THEN RAISE EXCEPTION 'BILLING_INVALID_VERIFIED_PAYMENT';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(p_user_id::text,123456));
 SELECT * INTO v_old FROM rucaleta_v16.billing_qa_payments WHERE payment_id=p_payment_id FOR UPDATE;
 IF FOUND AND (v_old.user_id<>p_user_id OR v_old.subscription_id<>p_subscription_id OR v_old.amount_cents<>p_amount_cents OR (v_old.approved_at IS NOT NULL AND p_approved_at IS NOT NULL AND v_old.approved_at<>p_approved_at)) THEN
  RAISE EXCEPTION 'BILLING_IMMUTABLE_PAYMENT_CONFLICT';
 END IF;
 INSERT INTO rucaleta_v16.billing_qa_payments(payment_id,subscription_id,user_id,amount_cents,payment_status,approved_at)
 VALUES(p_payment_id,p_subscription_id,p_user_id,p_amount_cents,p_status,p_approved_at)
 ON CONFLICT(payment_id) DO UPDATE SET payment_status=CASE
 WHEN rucaleta_v16.billing_qa_payments.payment_status IN ('refunded','charged_back','cancelled')
  THEN rucaleta_v16.billing_qa_payments.payment_status
 ELSE excluded.payment_status END,
 approved_at=coalesce(rucaleta_v16.billing_qa_payments.approved_at,excluded.approved_at),updated_at=now();
 SELECT max(approved_at+interval '1 month') INTO v_expires
 FROM rucaleta_v16.billing_qa_payments
 WHERE user_id=p_user_id AND payment_status='approved' AND approved_at IS NOT NULL;
 -- Do not override a manually granted QA subscription.
 IF NOT EXISTS(SELECT 1 FROM rucaleta_v16.subscriptions WHERE user_id=p_user_id AND source='manual_qa') THEN
  IF v_expires IS NOT NULL THEN
   INSERT INTO rucaleta_v16.subscriptions(user_id,expires_at,enabled,source)
   VALUES(p_user_id,v_expires,true,'mercadopago_qa')
   ON CONFLICT(user_id) DO UPDATE SET expires_at=excluded.expires_at,enabled=true,source='mercadopago_qa',updated_at=now()
   WHERE rucaleta_v16.subscriptions.source='mercadopago_qa';
  ELSE
   UPDATE rucaleta_v16.subscriptions SET enabled=false,updated_at=now() WHERE user_id=p_user_id AND source='mercadopago_qa';
  END IF;
 END IF;
 v_active:=rucaleta_v16.is_premium(p_user_id);
 RETURN jsonb_build_object('premium_active',v_active,'premium_expires_at',v_expires,'environment','QA');
END $$;
REVOKE ALL ON FUNCTION public.rucaleta_billing_qa_apply_payment(text,text,uuid,text,integer,timestamptz) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.rucaleta_billing_qa_apply_payment(text,text,uuid,text,integer,timestamptz) TO service_role;
COMMIT;
