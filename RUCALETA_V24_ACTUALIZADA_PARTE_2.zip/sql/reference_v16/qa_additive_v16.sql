-- QA ONLY xpkzzmnwzodikygfsdkp. Additive; no changes to V15 data or functions.
CREATE SCHEMA rucaleta_v16;
REVOKE ALL ON SCHEMA rucaleta_v16 FROM PUBLIC, anon, authenticated, service_role;
GRANT USAGE ON SCHEMA rucaleta_v16 TO authenticated;
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

CREATE TABLE rucaleta_v16.streams (
 user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 revision bigint NOT NULL DEFAULT 0 CHECK(revision>=0),
 seq bigint NOT NULL DEFAULT 0 CHECK(seq>=0),
 session_no bigint NOT NULL DEFAULT 1,
 session_start_seq bigint NOT NULL DEFAULT 0,
 seeded boolean NOT NULL DEFAULT false,
 green_end bigint,
 streaks jsonb NOT NULL DEFAULT '{"red":0,"black":0,"even":0,"odd":0,"low":0,"high":0}'::jsonb,
 head text NOT NULL DEFAULT repeat('0',64),
 credits integer NOT NULL DEFAULT 5 CHECK(credits BETWEEN 0 AND 5)
);
CREATE TABLE rucaleta_v16.events (
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 revision bigint NOT NULL,
 request_id uuid NOT NULL,
 action text NOT NULL CHECK(action IN ('seed_history','spin','confirm','new_session')),
 payload jsonb NOT NULL,
 request_fingerprint text NOT NULL,
 debit smallint NOT NULL CHECK(debit IN (0,1)),
 credits_after integer NOT NULL CHECK(credits_after BETWEEN 0 AND 5),
 previous_hash text NOT NULL,
 event_hash text NOT NULL,
 receipt jsonb NOT NULL,
 at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(user_id,revision), UNIQUE(user_id,request_id)
);
CREATE TABLE rucaleta_v16.signals (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 session_no bigint NOT NULL,
 trigger_seq bigint NOT NULL,
 category text NOT NULL CHECK(category IN ('color','parity','half')),
 target text NOT NULL CHECK(target IN ('red','black','even','odd','low','high')),
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','won','lost','closed_by_window','closed_by_new_session')),
 special boolean NOT NULL DEFAULT false,
 window_end bigint,
 completed_seq bigint,
 UNIQUE(user_id,session_no,trigger_seq,category,target)
);
CREATE TABLE rucaleta_v16.attempts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 signal_id uuid NOT NULL REFERENCES rucaleta_v16.signals(id),
 number integer NOT NULL CHECK(number BETWEEN 1 AND 4),
 scheme text NOT NULL CHECK(scheme IN ('A','B')),
 stake integer NOT NULL CHECK(stake IN (4,5,8,10,16,20,32,40)),
 status text NOT NULL CHECK(status IN ('pending','won','lost','interrupted')),
 result text,
 resolved_seq bigint,
 UNIQUE(signal_id,number)
);
CREATE UNIQUE INDEX one_pending_attempt ON rucaleta_v16.attempts(signal_id) WHERE status='pending';

-- Domain invariants independently enforced by PostgreSQL.
ALTER TABLE rucaleta_v16.signals ADD CONSTRAINT signal_category_target CHECK (
 (category='color' AND target IN ('red','black')) OR
 (category='parity' AND target IN ('even','odd')) OR
 (category='half' AND target IN ('low','high')));
ALTER TABLE rucaleta_v16.attempts ADD CONSTRAINT attempt_scheme_stake CHECK (
 (scheme='A' AND ((number=1 AND stake=4) OR (number=2 AND stake=8) OR (number=3 AND stake=16) OR (number=4 AND stake=32))) OR
 (scheme='B' AND ((number=1 AND stake=5) OR (number=2 AND stake=10) OR (number=3 AND stake=20) OR (number=4 AND stake=40))));
ALTER TABLE rucaleta_v16.attempts ADD CONSTRAINT attempt_result_consistency CHECK (
 (status IN ('pending','interrupted') AND result IS NULL AND resolved_seq IS NULL) OR
 (status IN ('won','lost') AND result ~ '^(00|0|[1-9]|[12][0-9]|3[0-6])$' AND resolved_seq IS NOT NULL));
ALTER TABLE rucaleta_v16.events ADD CONSTRAINT event_hash_shape CHECK (
 request_fingerprint ~ '^[0-9a-f]{64}$' AND previous_hash ~ '^[0-9a-f]{64}$' AND event_hash ~ '^[0-9a-f]{64}$');
ALTER TABLE rucaleta_v16.streams ADD CONSTRAINT stream_hash_shape CHECK (head ~ '^[0-9a-f]{64}$');

ALTER TABLE rucaleta_v16.streams ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_v16.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_v16.signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE rucaleta_v16.attempts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA rucaleta_v16 FROM PUBLIC, anon, authenticated, service_role;

CREATE FUNCTION rucaleta_v16.block_event_change() RETURNS trigger LANGUAGE plpgsql SET search_path='' AS $$
BEGIN RAISE EXCEPTION 'IMMUTABLE_EVENT' USING ERRCODE='42501'; END $$;
CREATE TRIGGER event_immutable BEFORE UPDATE OR DELETE ON rucaleta_v16.events
 FOR EACH ROW EXECUTE FUNCTION rucaleta_v16.block_event_change();



CREATE TABLE rucaleta_v16.entitlements(user_id uuid PRIMARY KEY REFERENCES auth.users(id),free_credits_remaining integer NOT NULL DEFAULT 5 CHECK(free_credits_remaining BETWEEN 0 AND 5));
CREATE TABLE rucaleta_v16.admins(user_id uuid PRIMARY KEY REFERENCES auth.users(id));
CREATE TABLE rucaleta_v16.accounts(user_id uuid PRIMARY KEY REFERENCES auth.users(id), blocked boolean NOT NULL DEFAULT false);
CREATE TABLE rucaleta_v16.subscriptions(user_id uuid PRIMARY KEY REFERENCES auth.users(id), expires_at timestamptz NOT NULL, enabled boolean NOT NULL DEFAULT true, source text NOT NULL CHECK(source='manual_qa'), updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE rucaleta_v16.creator_codes(code text PRIMARY KEY CHECK(code ~ '^[A-Z0-9_-]{3,32}$'), creator_id uuid NOT NULL REFERENCES auth.users(id), discount_pct integer NOT NULL CHECK(discount_pct BETWEEN 0 AND 100), commission_pct integer NOT NULL CHECK(commission_pct BETWEEN 0 AND 100), active boolean NOT NULL DEFAULT true);
CREATE TABLE rucaleta_v16.referrals(user_id uuid PRIMARY KEY REFERENCES auth.users(id), code text NOT NULL REFERENCES rucaleta_v16.creator_codes(code), discount_pct integer NOT NULL, commission_pct integer NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE rucaleta_v16.commissions(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES auth.users(id),code text NOT NULL REFERENCES rucaleta_v16.creator_codes(code),provider_reference text UNIQUE NOT NULL,net_cents integer NOT NULL CHECK(net_cents>=0),commission_cents integer NOT NULL CHECK(commission_cents>=0),created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE rucaleta_v16.audit(id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,actor uuid NOT NULL, action text NOT NULL,payload jsonb NOT NULL,at timestamptz NOT NULL DEFAULT now());
CREATE FUNCTION rucaleta_v16.require_user() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS(SELECT 1 FROM auth.users WHERE id=auth.uid()) THEN RAISE EXCEPTION 'AUTH_REQUIRED' USING ERRCODE='42501'; END IF;
 IF EXISTS(SELECT 1 FROM rucaleta_v16.accounts WHERE user_id=auth.uid() AND blocked) THEN RAISE EXCEPTION 'ACCOUNT_BLOCKED' USING ERRCODE='42501'; END IF;
END $$;
CREATE FUNCTION rucaleta_v16.is_premium(u uuid) RETURNS boolean LANGUAGE sql STABLE SET search_path='' AS $$
 SELECT EXISTS(SELECT 1 FROM rucaleta_v16.subscriptions WHERE user_id=u AND enabled AND expires_at>now())
$$;
CREATE FUNCTION rucaleta_v16.require_admin() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 PERFORM rucaleta_v16.require_user();
 IF NOT EXISTS(SELECT 1 FROM rucaleta_v16.admins WHERE user_id=auth.uid()) THEN RAISE EXCEPTION 'ADMIN_REQUIRED' USING ERRCODE='42501';END IF;
END $$;
CREATE FUNCTION public.rucaleta_v16_quote(p_code text DEFAULT NULL) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE r rucaleta_v16.referrals%ROWTYPE;c rucaleta_v16.creator_codes%ROWTYPE;d integer:=0;
BEGIN
 PERFORM rucaleta_v16.require_user();
 SELECT * INTO r FROM rucaleta_v16.referrals WHERE user_id=auth.uid();
 IF FOUND THEN d:=r.discount_pct;
 ELSIF p_code IS NOT NULL AND trim(p_code)<>'' THEN
 SELECT * INTO c FROM rucaleta_v16.creator_codes WHERE code=upper(trim(p_code)) AND active;
 IF NOT FOUND OR c.creator_id=auth.uid() THEN RAISE EXCEPTION 'INVALID_CREATOR_CODE' USING ERRCODE='22023';END IF;
 d:=c.discount_pct;
 END IF;
 RETURN jsonb_build_object('currency','MXN','base_cents',19900,'discount_pct',d,'recurring',true,'monthly_cents',19900*(100-d)/100,'payments_enabled',false,'applied_code',r.code);
END $$;
CREATE FUNCTION public.rucaleta_v16_redeem(p_code text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE c rucaleta_v16.creator_codes%ROWTYPE;
BEGIN
 PERFORM rucaleta_v16.require_user();
 SELECT * INTO c FROM rucaleta_v16.creator_codes WHERE code=upper(trim(p_code)) AND active FOR SHARE;
 IF NOT FOUND OR c.creator_id=auth.uid() THEN RAISE EXCEPTION 'INVALID_CREATOR_CODE' USING ERRCODE='22023';END IF;
 INSERT INTO rucaleta_v16.referrals(user_id,code,discount_pct,commission_pct) VALUES(auth.uid(),c.code,c.discount_pct,c.commission_pct) ON CONFLICT DO NOTHING;
 RETURN public.rucaleta_v16_quote(NULL);
END $$;
CREATE FUNCTION public.rucaleta_v16_admin(p_action text DEFAULT 'read',p_payload jsonb DEFAULT '{}'::jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE target uuid;until_at timestamptz;result jsonb;off integer; pct integer; cpct integer;
BEGIN
 PERFORM rucaleta_v16.require_admin();
 IF p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' OR octet_length(p_payload::text)>4096 THEN RAISE EXCEPTION 'INVALID_PAYLOAD';END IF;
 IF p_action='subscription' THEN
 target:=(p_payload->>'user_id')::uuid; until_at:=(p_payload->>'expires_at')::timestamptz;
 IF target IS NULL OR until_at IS NULL OR until_at>now()+interval '1 year' THEN RAISE EXCEPTION 'INVALID_SUBSCRIPTION';END IF;
 INSERT INTO rucaleta_v16.subscriptions(user_id,expires_at,enabled,source) VALUES(target,until_at,coalesce((p_payload->>'enabled')::boolean,true),'manual_qa') ON CONFLICT(user_id) DO UPDATE SET expires_at=excluded.expires_at,enabled=excluded.enabled,updated_at=now();
 ELSIF p_action='block' THEN
 target:=(p_payload->>'user_id')::uuid;
 IF target=auth.uid() OR target IS NULL OR NOT p_payload ? 'blocked' THEN RAISE EXCEPTION 'INVALID_TARGET';END IF;
 INSERT INTO rucaleta_v16.accounts(user_id,blocked) VALUES(target,(p_payload->>'blocked')::boolean) ON CONFLICT(user_id) DO UPDATE SET blocked=excluded.blocked;
 ELSIF p_action='code' THEN
 pct:=(p_payload->>'discount_pct')::integer;cpct:=(p_payload->>'commission_pct')::integer;
 INSERT INTO rucaleta_v16.creator_codes(code,creator_id,discount_pct,commission_pct,active) VALUES(upper(trim(p_payload->>'code')),(p_payload->>'creator_id')::uuid,pct,cpct,coalesce((p_payload->>'active')::boolean,true)) ON CONFLICT(code) DO UPDATE SET discount_pct=excluded.discount_pct,commission_pct=excluded.commission_pct,active=excluded.active;
 ELSIF p_action<>'read' OR p_action IS NULL THEN RAISE EXCEPTION 'INVALID_ADMIN_ACTION';END IF;
 IF p_action<>'read' THEN INSERT INTO rucaleta_v16.audit(actor,action,payload) VALUES(auth.uid(),p_action,p_payload);END IF;
 off:=greatest(0,least(coalesce((p_payload->>'offset')::integer,0),1000000));
 SELECT jsonb_build_object(
 'users',coalesce((SELECT jsonb_agg(x) FROM(SELECT u.id,u.email,u.created_at,coalesce(a.blocked,false) blocked,coalesce(e.free_credits_remaining,5) credits,s.expires_at,s.enabled,r.code FROM auth.users u LEFT JOIN rucaleta_v16.accounts a ON a.user_id=u.id LEFT JOIN rucaleta_v16.entitlements e ON e.user_id=u.id LEFT JOIN rucaleta_v16.subscriptions s ON s.user_id=u.id LEFT JOIN rucaleta_v16.referrals r ON r.user_id=u.id ORDER BY u.created_at,u.id LIMIT 50 OFFSET off)x),'[]'::jsonb),
 'codes',coalesce((SELECT jsonb_agg(c) FROM(SELECT * FROM rucaleta_v16.creator_codes ORDER BY code LIMIT 100)c),'[]'::jsonb),
 'statistics',jsonb_build_object('users',(SELECT count(*) FROM auth.users),'premium_active',(SELECT count(*) FROM rucaleta_v16.subscriptions WHERE enabled AND expires_at>now()),'groups',(SELECT count(DISTINCT (user_id,session_no,trigger_seq)) FROM rucaleta_v16.signals),'credits_used',(SELECT coalesce(sum(debit),0) FROM rucaleta_v16.events),'signals_won',(SELECT count(*) FROM rucaleta_v16.signals WHERE status='won'),'commissions_cents',(SELECT coalesce(sum(commission_cents),0) FROM rucaleta_v16.commissions),'collected_cents',(SELECT coalesce(sum(net_cents),0) FROM rucaleta_v16.commissions)),
 'commissions',coalesce((SELECT jsonb_agg(c) FROM(SELECT * FROM rucaleta_v16.commissions ORDER BY created_at DESC LIMIT 100)c),'[]'::jsonb),
 'audit',coalesce((SELECT jsonb_agg(a) FROM(SELECT * FROM rucaleta_v16.audit ORDER BY id DESC LIMIT 50)a),'[]'::jsonb),
 'offset',off,'page_size',50,'payments_enabled',false
 ) INTO result;RETURN result;
END $$;


INSERT INTO rucaleta_v16.entitlements SELECT user_id,free_credits_remaining FROM public.account_entitlements;
INSERT INTO rucaleta_v16.streams SELECT * FROM rucaleta_v15.streams;
INSERT INTO rucaleta_v16.events SELECT * FROM rucaleta_v15.events;
INSERT INTO rucaleta_v16.signals SELECT * FROM rucaleta_v15.signals;
INSERT INTO rucaleta_v16.attempts SELECT * FROM rucaleta_v15.attempts;

CREATE OR REPLACE FUNCTION public.rucaleta_v16_verify()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE v_user uuid:=auth.uid(); v_stream rucaleta_v16.streams%ROWTYPE;
 v_event rucaleta_v16.events%ROWTYPE; v_revision bigint:=0;
 v_head text:=repeat('0',64);v_balance integer:=5;v_hash text;
 v_seq bigint:=0;v_session bigint:=1;v_start bigint:=0;v_seeded boolean:=false;
 v_green_end bigint;v_streaks jsonb:='{"red":0,"black":0,"even":0,"odd":0,"low":0,"high":0}'::jsonb;
 v_value text;v_item jsonb;v_num integer;v_color text;v_parity text;v_half text;v_target text;
BEGIN
 IF v_user IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED' USING ERRCODE='42501';END IF;
 SELECT * INTO v_stream FROM rucaleta_v16.streams WHERE user_id=v_user FOR SHARE;
 IF NOT FOUND THEN RETURN jsonb_build_object('revision',0,'credits',5,'valid',true);END IF;
 FOR v_event IN SELECT * FROM rucaleta_v16.events WHERE user_id=v_user ORDER BY revision LOOP
  IF v_event.revision<>v_revision+1 OR v_event.previous_hash<>v_head
  THEN RAISE EXCEPTION 'EVENT_SEQUENCE_CORRUPT' USING ERRCODE='23514';END IF;
  IF v_event.request_fingerprint<>encode(extensions.digest(convert_to(v_event.action||'|'||v_event.payload::text,'UTF8'),'sha256'),'hex')
  THEN RAISE EXCEPTION 'EVENT_PAYLOAD_CORRUPT' USING ERRCODE='23514';END IF;
  v_balance:=v_balance-v_event.debit;
  IF v_balance<>v_event.credits_after OR v_balance<0 THEN RAISE EXCEPTION 'EVENT_CREDIT_CORRUPT' USING ERRCODE='23514';END IF;
  v_hash:=encode(extensions.digest(convert_to(v_head||'|'||v_user::text||'|'||v_event.revision::text||'|'||v_event.request_id::text||'|'||v_event.request_fingerprint||'|'||v_event.debit::text||'|'||v_balance::text,'UTF8'),'sha256'),'hex');
  IF v_hash<>v_event.event_hash THEN RAISE EXCEPTION 'EVENT_HASH_CORRUPT' USING ERRCODE='23514';END IF;
  IF v_event.action='new_session' THEN
   v_session:=v_session+1;v_start:=v_seq;v_seeded:=false;v_green_end:=NULL;
   v_streaks:='{"red":0,"black":0,"even":0,"odd":0,"low":0,"high":0}'::jsonb;
  ELSE
   IF v_event.action='seed_history' THEN
    IF v_seeded OR v_seq<>v_start THEN RAISE EXCEPTION 'REPLAY_SEED_CONFLICT';END IF;
    v_seeded:=true;
   END IF;
   IF v_event.action IN ('seed_history','spin') THEN
    FOR v_item IN SELECT value FROM jsonb_array_elements(
      CASE WHEN v_event.action='seed_history' THEN v_event.payload->'values' ELSE jsonb_build_array(v_event.payload->'value') END) LOOP
     v_value:=v_item#>>'{}';v_seq:=v_seq+1;
     IF v_value IN ('0','00') THEN v_green_end:=v_seq+30;
     ELSE
      v_num:=v_value::integer;
      v_color:=CASE WHEN v_num=ANY(ARRAY[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]) THEN 'red' ELSE 'black' END;
      v_parity:=CASE WHEN mod(v_num,2)=0 THEN 'even' ELSE 'odd' END;
      v_half:=CASE WHEN v_num<=18 THEN 'low' ELSE 'high' END;
      FOREACH v_target IN ARRAY ARRAY['red','black','even','odd','low','high'] LOOP
       v_streaks:=jsonb_set(v_streaks,ARRAY[v_target],to_jsonb(CASE WHEN v_target IN (v_color,v_parity,v_half) THEN 0 ELSE (v_streaks->>v_target)::integer+1 END));
      END LOOP;
     END IF;
     IF v_green_end IS NOT NULL AND v_seq>=v_green_end THEN v_green_end:=NULL;END IF;
    END LOOP;
   END IF;
  END IF;
  v_revision:=v_event.revision;v_head:=v_hash;
 END LOOP;
 IF v_revision<>v_stream.revision OR v_head<>v_stream.head OR v_balance<>v_stream.credits
 OR v_seq<>v_stream.seq OR v_session<>v_stream.session_no OR v_start<>v_stream.session_start_seq
 OR v_seeded<>v_stream.seeded OR v_streaks<>v_stream.streaks OR v_green_end IS DISTINCT FROM v_stream.green_end OR
 (SELECT free_credits_remaining FROM rucaleta_v16.entitlements WHERE user_id=v_user) IS DISTINCT FROM v_balance
 THEN RAISE EXCEPTION 'STREAM_PROJECTION_CORRUPT' USING ERRCODE='23514';END IF;
 RETURN jsonb_build_object('revision',v_revision,'credits',v_balance,'valid',true);
END $function$
;
CREATE OR REPLACE FUNCTION public.rucaleta_v16_apply(p_request_id uuid, p_expected_revision bigint, p_action text, p_payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE
 u uuid:=auth.uid(); st rucaleta_v16.streams%ROWTYPE; old_event rucaleta_v16.events%ROWTYPE;
 fp text; val text; n integer; col text; parity text; half text; v_absence text; streak jsonb;
 previous integer; next_count integer; created boolean:=false; debit integer:=0;
 sid uuid; sig rucaleta_v16.signals%ROWTYPE; attempt_no integer; scheme text; stake integer; expected_stake integer;
 item jsonb; legal_count integer; rev bigint; digest text; receipt jsonb; balance integer; premium boolean;
BEGIN
 IF u IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED' USING ERRCODE='42501'; END IF;
 IF p_request_id IS NULL OR p_expected_revision IS NULL OR p_expected_revision<0 OR
 p_action NOT IN ('seed_history','spin','confirm','new_session') OR p_action IS NULL OR
 p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' OR octet_length(p_payload::text)>4096
 THEN RAISE EXCEPTION 'INVALID_OPERATION' USING ERRCODE='22023'; END IF;
 PERFORM rucaleta_v16.require_user();
 premium:=rucaleta_v16.is_premium(u);
 INSERT INTO rucaleta_v16.entitlements(user_id) VALUES(u) ON CONFLICT DO NOTHING;
 fp:=encode(extensions.digest(convert_to(p_action||'|'||p_payload::text,'UTF8'),'sha256'),'hex');
 SELECT count(*) INTO legal_count FROM public.legal_documents d JOIN public.legal_consents c
 ON c.legal_document_id=d.id AND c.user_id=u AND c.document_sha256=d.content_sha256
 WHERE d.status='active' AND d.effective_at<=now();
 IF legal_count<>3 THEN RAISE EXCEPTION 'CURRENT_LEGAL_CONSENT_REQUIRED' USING ERRCODE='42501'; END IF;
 INSERT INTO rucaleta_v16.streams(user_id) VALUES(u) ON CONFLICT DO NOTHING;
 SELECT * INTO st FROM rucaleta_v16.streams WHERE user_id=u FOR UPDATE;
 SELECT free_credits_remaining INTO balance FROM rucaleta_v16.entitlements WHERE user_id=u FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'ENTITLEMENT_MISSING' USING ERRCODE='23514'; END IF;
 SELECT * INTO old_event FROM rucaleta_v16.events WHERE user_id=u AND request_id=p_request_id;
 IF FOUND THEN
  IF old_event.request_fingerprint<>fp THEN RAISE EXCEPTION 'IDEMPOTENCY_CONFLICT' USING ERRCODE='22023'; END IF;
  RETURN old_event.receipt||jsonb_build_object('replayed',true);
 END IF;
 PERFORM public.rucaleta_v16_verify();
 IF st.revision<>p_expected_revision THEN RAISE EXCEPTION 'ANALYSIS_REVISION_CONFLICT' USING ERRCODE='40001'; END IF;
 IF balance IS DISTINCT FROM st.credits THEN RAISE EXCEPTION 'CREDIT_BALANCE_DRIFT' USING ERRCODE='23514'; END IF;
 streak:=st.streaks;
 IF st.green_end IS NULL THEN
 UPDATE rucaleta_v16.attempts SET status='interrupted' WHERE user_id=u AND status='pending';
 UPDATE rucaleta_v16.signals SET status='closed_by_window',completed_seq=st.seq WHERE user_id=u AND status='active';
 END IF;
 IF p_action='seed_history' THEN
  IF st.seeded OR st.seq<>st.session_start_seq OR
   p_payload<>jsonb_build_object('values',p_payload->'values') OR
   jsonb_typeof(p_payload->'values')<>'array'
  THEN RAISE EXCEPTION 'INVALID_INITIAL_HISTORY' USING ERRCODE='22023'; END IF;
  IF jsonb_array_length(p_payload->'values') <>5 THEN
   RAISE EXCEPTION 'INITIAL_HISTORY_RANGE' USING ERRCODE='22023'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(p_payload->'values') LOOP
   IF jsonb_typeof(item)<>'string' OR (item#>>'{}') !~ '^(00|0|[1-9]|[12][0-9]|3[0-6])$'
   THEN RAISE EXCEPTION 'INVALID_SEED_NUMBER' USING ERRCODE='22023'; END IF;
   val:=item#>>'{}'; st.seq:=st.seq+1;
   IF val IN ('0','00') THEN st.green_end:=st.seq+30;
   ELSE
    n:=val::integer;
    col:=CASE WHEN n=ANY(ARRAY[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]) THEN 'red' ELSE 'black' END;
    parity:=CASE WHEN n%2=0 THEN 'even' ELSE 'odd' END;
    half:=CASE WHEN n<=18 THEN 'low' ELSE 'high' END;
    FOREACH v_absence IN ARRAY ARRAY['red','black','even','odd','low','high'] LOOP
     streak:=jsonb_set(streak,ARRAY[v_absence],to_jsonb(CASE WHEN v_absence IN (col,parity,half) THEN 0 ELSE (streak->>v_absence)::integer+1 END));
    END LOOP;
   END IF;
   IF st.green_end IS NOT NULL AND st.seq>=st.green_end THEN st.green_end:=NULL; END IF;
  END LOOP;
  st.seeded:=true;
 ELSIF p_action='spin' THEN
  IF NOT st.seeded OR p_payload<>jsonb_build_object('value',p_payload->'value') OR
   jsonb_typeof(p_payload->'value')<>'string' OR
   (p_payload->>'value') !~ '^(00|0|[1-9]|[12][0-9]|3[0-6])$'
  THEN RAISE EXCEPTION 'INVALID_SPIN_PAYLOAD' USING ERRCODE='22023'; END IF;
  val:=p_payload->>'value'; st.seq:=st.seq+1;
  IF val IN ('0','00') THEN
   st.green_end:=st.seq+30;
   UPDATE rucaleta_v16.signals SET window_end=st.green_end WHERE user_id=u AND status='active' ;
  ELSE
   n:=val::integer;
   col:=CASE WHEN n=ANY(ARRAY[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]) THEN 'red' ELSE 'black' END;
   parity:=CASE WHEN n%2=0 THEN 'even' ELSE 'odd' END;
   half:=CASE WHEN n<=18 THEN 'low' ELSE 'high' END;
  END IF;
  FOR sig IN SELECT s.* FROM rucaleta_v16.signals s
    JOIN rucaleta_v16.attempts a ON a.signal_id=s.id
    WHERE s.user_id=u AND s.status='active' AND a.status='pending' LOOP
   UPDATE rucaleta_v16.attempts SET
    status=CASE WHEN val NOT IN ('0','00') AND
      ((sig.category='color' AND sig.target=col) OR
       (sig.category='parity' AND sig.target=parity) OR
       (sig.category='half' AND sig.target=half)) THEN 'won' ELSE 'lost' END,
    result=val,resolved_seq=st.seq WHERE signal_id=sig.id AND status='pending';
   IF val NOT IN ('0','00') AND
    ((sig.category='color' AND sig.target=col) OR
     (sig.category='parity' AND sig.target=parity) OR
     (sig.category='half' AND sig.target=half)) THEN
    UPDATE rucaleta_v16.signals SET status='won',completed_seq=st.seq WHERE id=sig.id;
   ELSIF EXISTS(SELECT 1 FROM rucaleta_v16.attempts WHERE signal_id=sig.id AND number=4 AND resolved_seq=st.seq) THEN
    UPDATE rucaleta_v16.signals SET status='lost',completed_seq=st.seq WHERE id=sig.id;
   END IF;
  END LOOP;
  IF val NOT IN ('0','00') THEN
   FOREACH v_absence IN ARRAY ARRAY['red','black','even','odd','low','high'] LOOP
    previous:=(streak->>v_absence)::integer;
    next_count:=CASE WHEN v_absence IN (col,parity,half) THEN 0 ELSE previous+1 END;
    streak:=jsonb_set(streak,ARRAY[v_absence],to_jsonb(next_count));
    IF previous=4 AND next_count=5 AND NOT EXISTS(
     SELECT 1 FROM rucaleta_v16.signals WHERE user_id=u AND status='active' AND
      category=CASE WHEN v_absence IN ('red','black') THEN 'color' WHEN v_absence IN ('even','odd') THEN 'parity' ELSE 'half' END
      AND rucaleta_v16.signals.target=v_absence
    ) AND (st.credits>0 OR premium) AND st.green_end IS NOT NULL AND st.seq<st.green_end THEN
     created:=true;
     INSERT INTO rucaleta_v16.signals(user_id,session_no,trigger_seq,category,target,special,window_end)
     VALUES(u,st.session_no,st.seq,
      CASE WHEN v_absence IN ('red','black') THEN 'color' WHEN v_absence IN ('even','odd') THEN 'parity' ELSE 'half' END,v_absence,st.green_end IS NOT NULL AND st.seq<=st.green_end,
      CASE WHEN st.green_end IS NOT NULL AND st.seq<=st.green_end THEN st.green_end ELSE NULL END);
    END IF;
   END LOOP;
  END IF;
  IF created AND NOT premium THEN debit:=1; END IF;
  IF st.green_end IS NOT NULL AND st.seq>=st.green_end THEN
   UPDATE rucaleta_v16.signals SET status='closed_by_window',completed_seq=st.seq
    WHERE user_id=u AND status='active' ;
   UPDATE rucaleta_v16.attempts SET status='interrupted' WHERE user_id=u AND status='pending';
   st.green_end:=NULL;
  END IF;
 ELSIF p_action='confirm' THEN
  IF p_payload<>jsonb_build_object('signal_id',p_payload->'signal_id','stake',p_payload->'stake') OR
   jsonb_typeof(p_payload->'signal_id')<>'string' OR jsonb_typeof(p_payload->'stake')<>'number' OR
   (p_payload->>'stake') !~ '^(4|5|8|10|16|20|32|40)$'
  THEN RAISE EXCEPTION 'INVALID_CONFIRM_PAYLOAD' USING ERRCODE='22023'; END IF;
  BEGIN sid:=(p_payload->>'signal_id')::uuid;
  EXCEPTION WHEN invalid_text_representation THEN RAISE EXCEPTION 'INVALID_SIGNAL_ID' USING ERRCODE='22023'; END;
  SELECT * INTO sig FROM rucaleta_v16.signals WHERE id=sid AND user_id=u AND status='active';
  IF NOT FOUND THEN RAISE EXCEPTION 'SIGNAL_NOT_ACTIVE' USING ERRCODE='22023'; END IF;
  IF EXISTS(SELECT 1 FROM rucaleta_v16.attempts WHERE signal_id=sid AND status='pending') THEN
   RAISE EXCEPTION 'ATTEMPT_ALREADY_PENDING' USING ERRCODE='22023'; END IF;
  SELECT coalesce(max(number),0)+1 INTO attempt_no FROM rucaleta_v16.attempts WHERE signal_id=sid;
  IF attempt_no>4 THEN RAISE EXCEPTION 'ATTEMPTS_EXHAUSTED' USING ERRCODE='22023'; END IF;
  SELECT a.scheme INTO scheme FROM rucaleta_v16.attempts a WHERE a.signal_id=sid ORDER BY a.number LIMIT 1;
  stake:=(p_payload->>'stake')::integer;
  IF attempt_no=1 THEN scheme:=CASE WHEN stake=4 THEN 'A' WHEN stake=5 THEN 'B' ELSE NULL END; END IF;
  expected_stake:=CASE WHEN scheme='A' THEN (4*power(2,attempt_no-1))::integer
   WHEN scheme='B' THEN (5*power(2,attempt_no-1))::integer ELSE -1 END;
  IF stake<>expected_stake THEN RAISE EXCEPTION 'INVALID_STAKE_PROGRESSION' USING ERRCODE='22023'; END IF;
  INSERT INTO rucaleta_v16.attempts(user_id,signal_id,number,scheme,stake,status)
  VALUES(u,sid,attempt_no,scheme,stake,'pending');
 ELSIF p_action='new_session' THEN
  IF p_payload<>'{}'::jsonb THEN RAISE EXCEPTION 'INVALID_SESSION_PAYLOAD' USING ERRCODE='22023'; END IF;
  UPDATE rucaleta_v16.signals SET status='closed_by_new_session',completed_seq=st.seq
   WHERE user_id=u AND status='active';
  UPDATE rucaleta_v16.attempts SET status='interrupted' WHERE user_id=u AND status='pending';
  st.session_no:=st.session_no+1; st.session_start_seq:=st.seq; st.seeded:=false;
  streak:='{"red":0,"black":0,"even":0,"odd":0,"low":0,"high":0}'::jsonb; st.green_end:=NULL;
 END IF;
 rev:=st.revision+1;st.credits:=st.credits-debit;
 UPDATE rucaleta_v16.entitlements SET free_credits_remaining=st.credits WHERE user_id=u;
 receipt:=jsonb_build_object('revision',rev,'seq',st.seq,'session_no',st.session_no,
 'free_credits_remaining',st.credits,'debited',debit,'request_id',p_request_id,
 'created_signals',CASE WHEN p_action='spin' AND created THEN (SELECT coalesce(jsonb_agg(jsonb_build_object('id',s.id,'category',s.category,'target',s.target,'trigger_seq',s.trigger_seq)),'[]'::jsonb)
 FROM rucaleta_v16.signals s WHERE s.user_id=u AND s.trigger_seq=st.seq AND s.session_no=st.session_no) ELSE '[]'::jsonb END,
 'replayed',false);
 digest:=encode(extensions.digest(convert_to(st.head||'|'||u::text||'|'||rev::text||'|'||p_request_id::text||'|'||fp||'|'||debit::text||'|'||st.credits::text,'UTF8'),'sha256'),'hex');
 INSERT INTO rucaleta_v16.events(user_id,revision,request_id,action,payload,request_fingerprint,debit,credits_after,previous_hash,event_hash,receipt)
 VALUES(u,rev,p_request_id,p_action,p_payload,fp,debit,st.credits,st.head,digest,receipt);
 UPDATE rucaleta_v16.streams SET revision=rev,seq=st.seq,session_no=st.session_no,seeded=st.seeded,
 session_start_seq=st.session_start_seq,green_end=st.green_end,streaks=streak,head=digest,credits=st.credits
 WHERE user_id=u;
 RETURN receipt;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.rucaleta_v16_read()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE v_user uuid:=auth.uid();v_result jsonb;
BEGIN
 IF v_user IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED' USING ERRCODE='42501';END IF;
 PERFORM rucaleta_v16.require_user();
 PERFORM public.rucaleta_v16_verify();
 SELECT jsonb_build_object(
 'premium_active',rucaleta_v16.is_premium(v_user),
 'admin',exists(select 1 from rucaleta_v16.admins where user_id=v_user),
 'price_mxn',199,
 'free_credits_remaining',coalesce((SELECT free_credits_remaining FROM rucaleta_v16.entitlements WHERE user_id=v_user),5),
 'stream',(SELECT to_jsonb(s) - 'user_id' FROM rucaleta_v16.streams s WHERE s.user_id=v_user),
 'events',(SELECT coalesce(jsonb_agg(to_jsonb(e)-'user_id' ORDER BY e.revision),'[]'::jsonb) FROM rucaleta_v16.events e WHERE e.user_id=v_user),
 'signals',(SELECT coalesce(jsonb_agg(to_jsonb(s)-'user_id' ORDER BY s.trigger_seq,s.id),'[]'::jsonb) FROM rucaleta_v16.signals s WHERE s.user_id=v_user),
 'attempts',(SELECT coalesce(jsonb_agg(to_jsonb(a)-'user_id' ORDER BY a.number,a.id),'[]'::jsonb) FROM rucaleta_v16.attempts a WHERE a.user_id=v_user)
 ) INTO v_result;
 RETURN v_result;
END $function$
;

DO $$ DECLARE t record;BEGIN FOR t IN SELECT tablename FROM pg_tables WHERE schemaname='rucaleta_v16' LOOP
 EXECUTE format('ALTER TABLE rucaleta_v16.%I ENABLE ROW LEVEL SECURITY',t.tablename);
END LOOP;END $$;
REVOKE ALL ON ALL TABLES IN SCHEMA rucaleta_v16 FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA rucaleta_v16 FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON FUNCTION public.rucaleta_v16_apply(uuid,bigint,text,jsonb) FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_apply(uuid,bigint,text,jsonb) TO authenticated;
REVOKE ALL ON FUNCTION public.rucaleta_v16_read() FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_read() TO authenticated;
REVOKE ALL ON FUNCTION public.rucaleta_v16_verify() FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_verify() TO authenticated;
REVOKE ALL ON FUNCTION public.rucaleta_v16_quote(text) FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_quote(text) TO authenticated;
REVOKE ALL ON FUNCTION public.rucaleta_v16_redeem(text) FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_redeem(text) TO authenticated;
REVOKE ALL ON FUNCTION public.rucaleta_v16_admin(text,jsonb) FROM PUBLIC,anon,service_role;
GRANT EXECUTE ON FUNCTION public.rucaleta_v16_admin(text,jsonb) TO authenticated;
