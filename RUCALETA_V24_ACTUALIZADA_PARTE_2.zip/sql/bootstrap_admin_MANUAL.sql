-- Run only on RUCALETA-QA xpkzzmnwzodikygfsdkp from SQL Editor as database owner.
-- Choose the exact Auth user UUID of the owner; do not assign by email or browser metadata.
-- This file is a template. It was NOT executed. It does not modify auth.users.
INSERT INTO rucaleta_v16.admins(user_id)
VALUES ('REPLACE_WITH_VERIFIED_OWNER_AUTH_UUID'::uuid)
ON CONFLICT DO NOTHING;
