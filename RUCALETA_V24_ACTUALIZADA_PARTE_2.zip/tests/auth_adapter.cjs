const assert=require('node:assert/strict');const path=require('node:path');const fs=require('node:fs');const {JSDOM}=require('jsdom');
(async()=>{
 const dom=new JSDOM('',{url:'https://qa.example.invalid/app/',runScripts:'outside-only'}),w=dom.window;w.AbortController=AbortController;
 let mode='signin',refreshes=0,seen=[];
 const expiry=Math.floor(Date.now()/1000)+3600;
 w.fetch=async(url,o)=>{seen.push([url,o]);if(mode==='offline')throw Error('Failed to fetch');if(url.includes('grant_type=refresh_token')){refreshes++;await new Promise(r=>setTimeout(r,10));return {ok:true,text:async()=>JSON.stringify({access_token:'renewed-test-token',refresh_token:'renewed-test-refresh',expires_at:expiry})};}if(mode==='bad'){return {ok:false,status:401,text:async()=>'{"message":"Invalid login credentials"}'};}if(url.includes('/user'))return {ok:true,text:async()=>'{"id":"user-test"}'};return {ok:true,text:async()=>JSON.stringify({access_token:'test-token',refresh_token:'test-refresh',expires_at:expiry})};};
 let code=fs.readFileSync(path.join(__dirname,'../js/supabase.js'),'utf8').replace(/^import .*;\n/gm,'').replace(/export /g,'');code='const BASE="https://qa.supabase.co",KEY="public-test-key";const projectV15Read=x=>x;\n'+code+'\nwindow.A={signIn,sessionToken,userInfo,currentSession,requestPasswordReset,receiveAuthLink,logout,updatePassword};';w.eval(code);const a=w.A;
 await a.signIn('qa@example.invalid','test-only');assert.equal(a.currentSession().access_token,'test-token');a.currentSession().expires_at=1;const values=await Promise.all([a.sessionToken(),a.sessionToken(),a.sessionToken()]);assert.equal(refreshes,1);assert.equal(values[0],'renewed-test-token');
 a.currentSession().expires_at=1;mode='offline';await assert.rejects(()=>a.sessionToken(),/Failed to fetch/);assert.equal(a.currentSession().refresh_token,'renewed-test-refresh');mode='signin';await a.sessionToken();
 await a.requestPasswordReset('qa@example.invalid');assert.ok(seen.at(-1)[0].includes('redirect_to=https%3A%2F%2Fqa.example.invalid%2Fapp%2F'));
 w.location.hash='access_token=link-test-token&refresh_token=link-test-refresh&type=recovery&expires_in=3600';assert.equal(await a.receiveAuthLink(),true);assert.equal(w.location.hash,'');assert.equal(a.currentSession().access_token,'link-test-token');
 await a.updatePassword('new-test-password');assert.equal(seen.at(-1)[1].method,'PUT');
 mode='bad';await assert.rejects(()=>a.signIn('wrong@example.invalid','wrong'),/Invalid login/);mode='signin';await a.logout();assert.equal(a.currentSession(),null);
 console.log('PASS Auth adapter (mock HTTP): sign-in; one refresh for simultaneous requests; preserve session on network failure; recovery redirect; validate/clear URL fragment; password update; reject invalid login; logout.');dom.window.close();
})().catch(e=>{console.error(e);process.exitCode=1;});
