# Fotografías objetivo

Son las referencias originales aportadas por el propietario. No son capturas de RUCALETA V24 ejecutada y no se cargan como interfaz. La comparación con capturas reales sigue pendiente. Las barras de Safari/iOS incluidas en algunas imágenes pertenecen al dispositivo, no a la aplicación.
