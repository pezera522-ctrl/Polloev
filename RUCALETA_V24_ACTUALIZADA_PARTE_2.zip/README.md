# RUCALETA V24 · reconstrucción visual QA

Base: RUCALETA_V23_LEGAL_MAS_DARK_RUBY_QA(1).zip. Producción y base de datos sin cambios.

La presentación ahora utiliza el DOM original, el logo auténtico, cuatro fondos existentes y una hoja visual consolidada. Dark Ruby permanece como archivo histórico; index.html ya no carga su integración ni oculta controles del motor.

No se declara coincidencia exacta ni validación en Safari: no se pudieron ejecutar capturas del navegador. El propietario autorizó continuar la implementación con los archivos disponibles. Consulta INFORME_V24.md para pruebas y límites.

## Abrir desde Codespaces en iPhone

1. Conserva tu carpeta actual como respaldo. Descomprime `RUCALETA_V24_FINAL.zip` en una carpeta nueva `rucaleta-v24`. No mezcles archivos individuales sobre otra versión.
2. En la terminal, entra a la carpeta que contiene este index.html. Ejecuta `pwd` y `ls` para confirmar que están index.html, app.css, motion.css, java.js, js y assets.
3. Ejecuta `python3 -m http.server 8000`. Si otro servidor ocupa el puerto, detenlo con Ctrl+C en su terminal o usa 8001 para la nueva copia.
4. En Puertos, abre el puerto elegido. No cambies su visibilidad para probar desde tu cuenta.
5. Añade `?v=24-final` al enlace de la página. Si ves el diseño anterior, verifica primero que el puerto corresponde a la nueva carpeta.
6. Para identificar el paquete sin iniciar sesión, abre VERSION.json en esa misma raíz: debe decir `24.0.0-qa.final`.

El servidor Python es solo estático: no ejecuta /api/billing. Conserva el servidor y proxy de Mercado Pago existentes en el entorno QA para probar pagos; no se activan con este ZIP.

## Comprobación manual necesaria

- Visitante: Comenzar → animación original → Antes de continuar.
- Si la consulta pública de documentos está permitida: tres documentos oficiales, dos casillas independientes, Aceptar y continuar → acceso/registro. El borrador no es un consentimiento remoto: la cuenta autenticada guarda las versiones exactas mediante la RPC existente. Si cambian los documentos, vuelve a solicitar aceptación.
- Si la consulta pública no está permitida: aparece la pantalla legal con aviso de carga y «Acceder para cargar documentos». Tras el login se muestran los documentos oficiales y se exige la aceptación antes de entrar a la mesa. No se inventan textos legales completos, permisos ni consentimientos.
- Usuario con consentimiento válido: no vuelve a aceptar obligatoriamente.
- En mesa: registrar 0, 00 y 1–36; comprobar sincronización, historial, señales reales e intentos. Confirmar que el servidor controla créditos.
- Revisar 375, 390, 393 y 430 px, Safari, scroll, modales, sonido y controles.

## Pruebas locales reproducibles

`npm run test:v24`

Son pruebas de lógica y contratos estáticos. No sustituyen pruebas de navegador o Supabase. Los tests V18–V22 se conservan como históricos; algunos describen el flujo anterior y no certifican V24.
